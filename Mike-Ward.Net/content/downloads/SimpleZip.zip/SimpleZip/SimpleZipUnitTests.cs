﻿// Copyright (c) 2008 Blue Onion Software
// All rights reserved

using NUnit.Framework;
using System;
using System.IO;

namespace BlueOnionSoftware.SimpleZip
{
    [TestFixture]
    public class SimpleZipUnitTests
    {
        [Test]
        public void ZipTo()
        {
            using (var fileStream = File.Create("test.zip"))
            {
                SimpleZip.ZipTo(new string[] { @"TextFile1.txt", @"TextFile2.txt", @"TextFile3.txt" }, fileStream);
            }

            Assert.IsTrue(File.Exists("test.zip"));
            System.IO.FileInfo fileInfo = new FileInfo("test.zip");
            Assert.AreEqual(8950, fileInfo.Length);
        }

        [Test]
        public void ZipTo2()
        {
            // Test with paths...
            FileInfo textFile1 = new FileInfo("textFile1.txt");
            FileInfo textFile2 = new FileInfo("textFile2.txt");
            FileInfo textFile3 = new FileInfo("textFile3.txt");

            using (var fileStream = File.Create("test2.zip"))
            {
                SimpleZip.ZipTo(new string[] { textFile1.FullName, textFile2.FullName, textFile3.FullName }, fileStream);
            }

            Assert.IsTrue(System.IO.File.Exists("test2.zip"));
            System.IO.FileInfo fileInfo = new System.IO.FileInfo("test2.zip");
            Assert.Greater(fileInfo.Length, 8950);
        }

        [Test]
        public void ZipTo3()
        {
            // Test with paths and flatten...
            FileInfo textFile1 = new FileInfo("textFile1.txt");
            FileInfo textFile2 = new FileInfo("textFile2.txt");
            FileInfo textFile3 = new FileInfo("textFile3.txt");

            using (var fileStream = File.Create("test3.zip"))
            {
                SimpleZip.ZipTo(new string[] { textFile1.FullName, textFile2.FullName, textFile3.FullName }, fileStream, true);
            }

            Assert.IsTrue(System.IO.File.Exists("test3.zip"));
            System.IO.FileInfo fileInfo = new System.IO.FileInfo("test3.zip");
            Assert.AreEqual(fileInfo.Length, 8950);
        }
    }
}
