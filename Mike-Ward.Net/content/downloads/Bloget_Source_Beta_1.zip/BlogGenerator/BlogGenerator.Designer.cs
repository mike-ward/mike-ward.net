// Copyright (C) 2007 Blue Onion Software
// All rights reserved

namespace BlogGenerator
{
    partial class BlogGenerator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startDate = new System.Windows.Forms.DateTimePicker();
            this.endDate = new System.Windows.Forms.DateTimePicker();
            this.minPosts = new System.Windows.Forms.NumericUpDown();
            this.maxPosts = new System.Windows.Forms.NumericUpDown();
            this.generateButton = new System.Windows.Forms.Button();
            this.folderTextbox = new System.Windows.Forms.TextBox();
            this.browseButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.minPosts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxPosts)).BeginInit();
            this.SuspendLayout();
            // 
            // startDate
            // 
            this.startDate.Location = new System.Drawing.Point(12, 36);
            this.startDate.Name = "startDate";
            this.startDate.Size = new System.Drawing.Size(200, 20);
            this.startDate.TabIndex = 0;
            // 
            // endDate
            // 
            this.endDate.Location = new System.Drawing.Point(12, 85);
            this.endDate.Name = "endDate";
            this.endDate.Size = new System.Drawing.Size(200, 20);
            this.endDate.TabIndex = 1;
            // 
            // minPosts
            // 
            this.minPosts.Location = new System.Drawing.Point(12, 130);
            this.minPosts.Name = "minPosts";
            this.minPosts.Size = new System.Drawing.Size(63, 20);
            this.minPosts.TabIndex = 2;
            // 
            // maxPosts
            // 
            this.maxPosts.Location = new System.Drawing.Point(149, 130);
            this.maxPosts.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.maxPosts.Name = "maxPosts";
            this.maxPosts.Size = new System.Drawing.Size(63, 20);
            this.maxPosts.TabIndex = 3;
            this.maxPosts.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // generateButton
            // 
            this.generateButton.Location = new System.Drawing.Point(75, 235);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(102, 23);
            this.generateButton.TabIndex = 4;
            this.generateButton.Text = "Generate";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.GenerateClick);
            // 
            // folderTextbox
            // 
            this.folderTextbox.Location = new System.Drawing.Point(12, 198);
            this.folderTextbox.Name = "folderTextbox";
            this.folderTextbox.Size = new System.Drawing.Size(228, 20);
            this.folderTextbox.TabIndex = 5;
            this.folderTextbox.Validating += new System.ComponentModel.CancelEventHandler(this.FolderTextboxValidating);
            // 
            // browseButton
            // 
            this.browseButton.Location = new System.Drawing.Point(12, 168);
            this.browseButton.Name = "browseButton";
            this.browseButton.Size = new System.Drawing.Size(113, 23);
            this.browseButton.TabIndex = 6;
            this.browseButton.Text = "Blog File";
            this.browseButton.UseVisualStyleBackColor = true;
            this.browseButton.Click += new System.EventHandler(this.BrowseButtonClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Start Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "End Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Min Posts/Month";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(149, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Max Posts/Month";
            // 
            // BlogGenerator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(253, 270);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.browseButton);
            this.Controls.Add(this.folderTextbox);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.maxPosts);
            this.Controls.Add(this.minPosts);
            this.Controls.Add(this.endDate);
            this.Controls.Add(this.startDate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "BlogGenerator";
            this.Text = "Bloget Blog Generator";
            ((System.ComponentModel.ISupportInitialize)(this.minPosts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxPosts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker startDate;
        private System.Windows.Forms.DateTimePicker endDate;
        private System.Windows.Forms.NumericUpDown minPosts;
        private System.Windows.Forms.NumericUpDown maxPosts;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.TextBox folderTextbox;
        private System.Windows.Forms.Button browseButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

