The default admin account/password is:
------------------------------
admin
admin

Documentation for Bloget can be found at:
-----------------------------------------
http://blueonionsoftware.com/BlogetUserGuide.html

Manual Setup:
-------------
Copy the files in the distribution to your web folder. You may have to add file
permissions to get things working. Generally, the ASP.NET account will need read access 
to the web folder. The ASP.NET and Network Service accounts also will need read/write 
access to the App_Data folder.

History:
--------
February 14, 2008 - Beta One

Membership Providers
Blog Provider
Email configuration
Contact Form
Documentation Updates


July 29, 2007 - Alpha Nine

Default theme (finally)
Numerious unit tests added
Added access to blog variables (like blog title) outside of control context
Added navigation menu to admin pages
Documentation updates


June 3, 2007 - Alpha Eight

Added search control
Added related posts
Condensed RSS and RPC and blog to single page
Added RSS templating
Strong named assembly
Documentation updates


April 30, 2007 - Alpha Seven

Added Archive control
Added Blog Roll control
Added Blog Title control
Specify log directory in web.config
Documentation Updates
Improved Sample Blog Examples


March 5, 2007 - Alpha Six

Replaced FreeTextBox with OpenWysiwyg
Single Binary Distribution
Documentation Updates


February 26, 2007 - Alpha Five

BlogML support added
Removed Zip backup
Timezones added
Useability changes to Admin screen
Documentation Updates


January 21, 2007 - Alpha Four

Log Viewer
Enclosures
Upload images
Upload attachements
Namespace added to file XML
RSS image channel
RSS footer
RSS source element
Additional template methods
RSD
Bug fixes
Documentation updated
Notify on pingback
SMTP Authorization


December 22, 2006 - Alpha Three

MetaWebLog support including image upload
Improved and documented logging
Usability changes
Backup saves images folder if designated
Improvements to RSS format


November 19, 2006 - Alpha Two

Usability changes
Added Logging
Formalized Model-View-Controler architecture
Added Pingback, both client and server
All page transfers are now redirects
Date times are UTC
Removed password requirement from posting dialog
Added more data protection to serializations
Add author to RSS feeds / Admin page
Fixed drafts
Fixed href building

October 22, 2006 - Alpha One