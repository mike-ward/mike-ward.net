// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using NUnit.Framework;
using NUnit.Extensions.Asp;
using NUnit.Extensions.Asp.AspTester;
using System.Globalization;

namespace BlogetTests
{
    [TestFixture]
    [Category("ASP")]
    public class LoginTests : WebFormTestCase
    {
        readonly string testPage = Program.Host + "BlogetExamples/Example3.aspx?m=edit";
        UserControlTester userControl;
        TextBoxTester user;
        TextBoxTester password;
        ButtonTester submit;

        const string controlId = "bloget2";
        const string userId = "login_UserName";
        const string passwordId = "login_Password";
        const string submitId = "login_LoginButton";

        protected override void SetUp()
        {
            userControl = new UserControlTester(controlId, CurrentWebForm);
            user = new TextBoxTester(userId, userControl);
            password = new TextBoxTester(passwordId, userControl);
            submit = new ButtonTester(submitId, userControl);
            Browser.GetPage(testPage);
        }

        [Test]
        public void TestLayout()
        {
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());
            WebAssert.Visible(user);
            WebAssert.Visible(password);
            WebAssert.Visible(submit);
        }

        [Test]
        public void TestFailedPassword()
        {
            string userText = System.IO.Path.GetRandomFileName();
            user.Text = userText;
            password.Text = System.IO.Path.GetRandomFileName();
            submit.Click();
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());
            Assert.AreEqual(userText, user.Text, userId);
            Assert.AreEqual(string.Empty, password.Text, passwordId);
        }

        [Test]
        public void TestPassword()
        {
            user.Text = Program.User;
            password.Text = Program.Password;
            submit.Click();
            WebAssert.CurrentUrlEndsWith(BlueOnionSoftware.Bloget.Mode.Edit.ToString().ToLowerInvariant());
            WebAssert.NotVisible(user);
            WebAssert.NotVisible(password);
        }

        [Test]
        public void TestEmptyPassword()
        {
            user.Text = Program.User;
            password.Text = string.Empty;
            submit.Click();
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());
            Assert.AreEqual(Program.User, user.Text, userId);
            Assert.AreEqual(string.Empty, password.Text, passwordId);
        }

        [Test]
        public void TestEmptyUser()
        {
            user.Text = string.Empty;
            password.Text = Program.Password;
            submit.Click();
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());
            Assert.AreEqual(string.Empty, user.Text, userId);
            Assert.AreEqual(string.Empty, password.Text, passwordId);
        }
    }
}
