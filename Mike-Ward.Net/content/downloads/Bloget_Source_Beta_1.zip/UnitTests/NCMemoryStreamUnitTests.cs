﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.IO;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;

namespace BlogetTests
{
    [TestFixture]
    public class NCMemoryStreamUnitTests
    {
        byte[] buffer;
        NonContiguousMemoryStream memoryStream;

        [TestFixtureSetUp]
        public void Setup()
        {
            Random random = new Random();
            buffer = new byte[1024 * 1024 * 2];
            random.NextBytes(buffer);
            memoryStream = new NonContiguousMemoryStream();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            memoryStream.Dispose();
        }

        [Test]
        public void CanWriteTest()
        {
            Assert.IsTrue(memoryStream.CanWrite);
        }

        [Test]
        public void CanReadTest()
        {
            Assert.IsTrue(memoryStream.CanRead);
        }

        [Test]
        public void CanSeekTest()
        {
        
            Assert.IsTrue(memoryStream.CanSeek);
        }

        [Test]
        public void WriteTest()
        {
            memoryStream.Position = 0;
            memoryStream.Write(buffer, 0, buffer.Length);
            Assert.AreEqual(buffer.Length, memoryStream.Length);
        }

        [Test]
        public void ReadTest()
        {
            memoryStream.Position = 0;
            memoryStream.Write(buffer, 0, buffer.Length);
            byte[] readBuffer = new byte[buffer.Length];
            memoryStream.Position = 0;
            int count = memoryStream.Read(readBuffer, 0, readBuffer.Length);
            Assert.AreEqual(buffer.Length, count);
            
            for (int i = 0; i < count; ++i)
            {
                Assert.AreEqual(buffer[i], readBuffer[i]);
            }
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void WriteParameter1Test()
        {
            memoryStream.Write(null, 0, buffer.Length);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void WriteParameter2Test()
        {
            memoryStream.Write(buffer, -1, buffer.Length);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void WriteParameter3Test()
        {
            memoryStream.Write(buffer, 0, buffer.Length + 1);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void WriteParameter4Test()
        {
            memoryStream.Write(buffer, 0, -1);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void WriteParameter5Test()
        {
            memoryStream.Write(buffer, 100, buffer.Length);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReadParameter1Test()
        {
            memoryStream.Read(null, 0, 100);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ReadParameter2Test()
        {
            byte[] readBuffer = new byte[100];
            memoryStream.Read(readBuffer, -1, readBuffer.Length);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ReadParameter3Test()
        {
            byte[] readBuffer = new byte[100];
            memoryStream.Read(readBuffer, 0, readBuffer.Length + 1);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ReadParameter4Test()
        {
            byte[] readBuffer = new byte[100];
            memoryStream.Read(readBuffer, 0, -1);
        }

        [Test]
        public void ReadParameter5Test()
        {
            byte[] readBuffer = new byte[100];
            int count = memoryStream.Read(readBuffer, 50, readBuffer.Length);
            Assert.AreEqual(readBuffer.Length - 100, count);
        }

        [Test]
        [ExpectedException(typeof(NotImplementedException))]
        public void LengthTest()
        {
            memoryStream.SetLength(100);
        }

        [Test]
        public void SeekBeginTest()
        {
            memoryStream.Seek(0, SeekOrigin.Begin);
            Assert.AreEqual(0, memoryStream.Position);
        }

        [Test]
        public void SeekEndTest()
        {
            memoryStream.Seek(0, SeekOrigin.End);
            Assert.AreEqual(buffer.Length - 1, memoryStream.Position);
        }

        [Test]
        public void SeekCurrentTest()
        {
            memoryStream.Position = 0;
            memoryStream.Seek(100, SeekOrigin.Current);
            memoryStream.Seek(100, SeekOrigin.Current);
            Assert.AreEqual(200, memoryStream.Position);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void SeekOutOfRange1Test()
        {
            memoryStream.Seek(-100, SeekOrigin.Begin);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void SeekOutOfRange2Test()
        {
            memoryStream.Seek(100, SeekOrigin.End);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void SeekArgumentExceptionTest()
        {
            memoryStream.Seek(0, SeekOrigin.Begin - 1);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void PositionOutOfRangeTest()
        {
            memoryStream.Position = -1;
        }

        [Test]
        public void FlushTest()
        {
            memoryStream.Flush();
            Assert.IsTrue(true);
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose1Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            stream.Dispose(); // check reentrancy
            bool can = stream.CanRead;
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose2Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            bool can = stream.CanSeek;
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose3Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            bool can = stream.CanWrite;
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose5Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            long l = stream.Length;
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose6Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            stream.Position = 0;
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose7Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            long p = stream.Position;
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose8Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            stream.Read(null, 0, 0);
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose9Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            stream.Seek(0, SeekOrigin.Begin);
        }

        [Test]
        [ExpectedException(typeof(ObjectDisposedException))]
        public void Dispose11Test()
        {
            Stream stream = new NonContiguousMemoryStream();
            stream.Dispose();
            stream.Write(null, 0, 0);
        }
    }
}
