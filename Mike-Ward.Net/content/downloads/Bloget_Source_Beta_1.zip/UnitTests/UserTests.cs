// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    //[TestFixture]
    //[Description("Tests for the User and UserCollection classes")]
    //[SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    //public class UserTests
    //{
    //    [Test]
    //    public void NewUser()
    //    {
    //        User user = new User();
    //        Assert.AreNotEqual(Guid.Empty, user.Id);
    //        Assert.IsEmpty(user.Name);
    //        Assert.IsEmpty(user.Password);
    //        Assert.IsEmpty(user.Salt);
    //        Assert.IsEmpty(user.Email);
    //        Assert.GreaterOrEqual(DateTime.UtcNow, user.LastLogOn);
    //        Assert.AreEqual(Role.None, user.UserRole);
    //    }

    //    [Test]
    //    public void Id()
    //    {
    //        User user = new User();
    //        Guid id = new Guid(user.Id.ToString()); // throws if bad
    //        Assert.AreNotEqual(Guid.Empty, id);
    //    }

    //    [Test]
    //    public void Name()
    //    {
    //        const string value = "My Name here...";
    //        User user = new User();
    //        user.Name = value;
    //        Assert.AreEqual(value, user.Name);
    //    }

    //    [Test]
    //    [ExpectedException(typeof(ArgumentException))]
    //    public void NullName()
    //    {
    //        User user = new User();
    //        user.Name = null;
    //    }

    //    [Test]
    //    [ExpectedException(typeof(ArgumentException))]
    //    public void EmptyName()
    //    {
    //        User user = new User();
    //        user.Name = "  ";
    //    }

    //    [Test]
    //    public void Password()
    //    {
    //        const string value = "My password here...";
    //        User user = new User();
    //        user.Password = value;
    //        Assert.AreEqual(value, user.Password);
    //    }

    //    [Test]
    //    [ExpectedException(typeof(ArgumentException))]
    //    public void NullPassword()
    //    {
    //        User user = new User();
    //        user.Password = null;
    //    }

    //    [Test]
    //    [ExpectedException(typeof(ArgumentException))]
    //    public void EmptyPassword()
    //    {
    //        User user = new User();
    //        user.Password = "  ";
    //    }

    //    [Test]
    //    public void NullSalt()
    //    {
    //        User user = new User();
    //        user.Salt = null;
    //        Assert.IsEmpty(user.Salt);
    //    }

    //    [Test]
    //    public void Salt()
    //    {
    //        const string value = "My salt value here...";
    //        User user = new User();
    //        user.Salt = value;
    //        Assert.AreEqual(value, user.Salt);
    //    }

    //    [Test]
    //    public void Email()
    //    {
    //        const string value = "My email here...";
    //        User user = new User();
    //        user.Email = value;
    //        Assert.AreEqual(value, user.Email);
    //    }

    //    [Test]
    //    public void LastLogOn()
    //    {
    //        User user = new User();
    //        DateTime now = DateTime.Now;
    //        user.LastLogOn = now;
    //        Assert.AreEqual(now, user.LastLogOn);
    //    }

    //    [Test]
    //    public void UserEquality()
    //    {
    //        User user1 = new User();
    //        User user2 = new User();
    //        Assert.AreNotEqual(user1, user2);
    //        User user3 = new User(user1);
    //        Assert.AreEqual(user1, user3);
    //    }

    //    [Test]
    //    public void ValidateString()
    //    {
    //        Assert.IsFalse(User.ValidateString(null));
    //        Assert.IsFalse(User.ValidateString(string.Empty));
    //        Assert.IsFalse(User.ValidateString("   "));
    //        Assert.IsTrue(User.ValidateString("Frank"));
    //    }

    //    [Test]
    //    public void UserCollectionAdd()
    //    {
    //        UserCollection users = new UserCollection();            
    //        User user = new User();
    //        user.Name = "me";
    //        user.Password = "my";
    //        users.Add(user);
    //        Assert.IsNotNull(users[user.Id]);
    //    }

    //    [Test]
    //    [ExpectedException(typeof(InvalidOperationException))]
    //    public void UserCollectionDuplicateUserName()
    //    {
    //        UserCollection users = new UserCollection();
    //        User user = new User();
    //        user.Name = "me";
    //        user.Password = "my";
    //        users.Add(user);
    //        Assert.AreEqual(1, users.Count);

    //        user = new User();
    //        user.Name = "me";
    //        user.Password = "my";

    //        Assert.IsTrue(users.ContainsName(user.Name));
    //        users.Add(user);
    //    }

    //    [Test]
    //    public void UserCollectionCaseSensitivity()
    //    {
    //        UserCollection users = new UserCollection();
    //        User user = User.CreateAdmin();
    //        users.Add(user);
    //        Assert.IsTrue(users.ContainsName(user.Name));
    //        Assert.IsTrue(users.ContainsName(user.Name.ToUpperInvariant()));
    //        Assert.IsTrue(users.ContainsName(user.Name.ToLowerInvariant()));
    //        Assert.IsFalse(users.ContainsName(System.IO.Path.GetRandomFileName()));
    //    }
    //}
}
