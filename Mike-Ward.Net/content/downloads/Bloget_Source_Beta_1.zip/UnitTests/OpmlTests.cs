// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.IO;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class OpmlTests
    {
        [Test]
        public void OpmlBlogRoll()
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.BlogRoll))
            {
                Opml opml = Opml.Parse(stream);
                Assert.IsNotNull(opml);
                Assert.AreEqual("Bloglines Subscriptions", opml.Title);
                Assert.AreEqual("blueonionsoftware", opml.OwnerName);
                Assert.AreEqual(new DateTime(2007, 3, 27, 22, 42, 46, DateTimeKind.Utc), opml.DateCreated.ToUniversalTime());
                Assert.AreEqual(72, opml.Outlines.Count);
                Assert.AreEqual(".NET slave", opml.Outlines[0].Title);
                Assert.AreEqual(".NET slave", opml.Outlines[0].Text);
                Assert.AreEqual("http://www.madskristensen.dk/blog/", opml.Outlines[0].HtmlUrl.ToString());
                Assert.AreEqual("http://feeds.feedburner.com/netslave", opml.Outlines[0].XmlUrl.ToString());
                Assert.AreEqual("rss", opml.Outlines[0].Type);
            }
        }

        [Test]
        public void OpmlFeedList()
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.FeedList))
            {
                Opml opml = Opml.Parse(stream);
                Assert.IsNotNull(opml);
                Assert.AreEqual("ourFavoriteFeedsData.top100", opml.Title);
                Assert.AreEqual("Dave Winer", opml.OwnerName);
                Assert.AreEqual("dave@userland.com", opml.OwnerEmail);
                Assert.AreEqual(new DateTime(2004, 1, 2, 12, 59, 58, DateTimeKind.Utc), opml.DateCreated.ToUniversalTime());
                Assert.AreEqual(100, opml.Outlines.Count);
                Assert.AreEqual( "Scripting News", opml.Outlines[0].Text);
                Assert.AreEqual("http://www.scripting.com/rss.xml", opml.Outlines[0].XmlUrl.ToString());
            }
        }

        [Test]
        public void Opml20()
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.Opml20))
            {
                Opml opml = Opml.Parse(stream);
                Assert.IsNotNull(opml);
            }
        }

        [Test]
        public void States()
        {
            using (MemoryStream stream = new MemoryStream(Properties.Resources.States))
            {
                Opml opml = Opml.Parse(stream);
                Assert.IsNotNull(opml);
            }
        }

        [Test]
        public void ReadWriteStates()
        {
            Opml opml;

            using (MemoryStream read = new MemoryStream(Properties.Resources.States))
            {
                opml = Opml.Parse(read);
                Assert.IsNotNull(opml);
            }

            using (MemoryStream readWrite = new MemoryStream())
            {
                opml.Save(readWrite);
                readWrite.Flush();
                readWrite.Seek(0, SeekOrigin.Begin);

                opml = Opml.Parse(readWrite);
                Assert.IsNotNull(opml);

                Assert.IsEmpty(opml.Outlines[0].Outlines[7].Title);
                Assert.AreEqual(opml.Outlines[0].Outlines[7].Text, "Southwest");
                Assert.AreEqual(opml.Outlines[0].Outlines[7].Outlines[2].Text, "Texas");
            }
        }
    }
}
