// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.IO;
using System.Xml;
using System.Text;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class BlogMLTests
    {
        [Test]
        public void BlogMLImportExport()
        {
            Blog blog = new Blog();
            blog.DataContext = Path.Combine(Path.GetTempPath(), "UnitTest.xml");

            if (File.Exists(blog.DataContext))
            {
                File.Delete(blog.DataContext);
            }

            using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(Properties.Resources.BlogetML)))
            {
                ImportBlog.Import(blog, stream);
            }

            Assert.IsTrue(File.Exists(blog.DataContext), string.Format("'{0}' does not exist", blog.DataContext));
            blog = Blog.Load(blog.DataContext);
            Assert.IsNotNull(blog);
            Assert.IsTrue(blog.Title == "Onion Peels", "blog.Title did not match");
            Assert.IsTrue(blog.Webmaster == "mike@blueonionsoftware.com", "blog.Webmaster did not match");
            Assert.AreEqual(blog.Posts.Count, 128);

            using (StringWriter stringWriter = new StringWriter())
            using (XmlTextWriter stream = new XmlTextWriter(stringWriter))
            {
                ExportBlog.Export(blog, stream);
                stream.Flush();
                Assert.Greater(stringWriter.ToString().Length, (300 * 1024));
            }
        }

        [Test]
        public void BlogMLWordPress()
        {
            Blog blog = new Blog();
            blog.DataContext = Path.Combine(Path.GetTempPath(), "BlogMLWordPress.xml");

            if (File.Exists(blog.DataContext))
            {
                File.Delete(blog.DataContext);
            }

            // This particular BlogML file broke the importer in several places. Good find.

            using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(Properties.Resources.WordPress)))
            {
                ImportBlog.Import(blog, stream);
            }

            blog = Blog.Load(blog.DataContext);
            Assert.AreEqual(198, blog.Posts.Count);
        }
    }
}
