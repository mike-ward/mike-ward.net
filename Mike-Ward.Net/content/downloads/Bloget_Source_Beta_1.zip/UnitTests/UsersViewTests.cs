﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using NUnit.Framework;
using NUnit.Extensions.Asp;
using NUnit.Extensions.Asp.AspTester;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [Category("ASP")]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class UsersViewTests : WebFormTestCase
    {
        readonly string testPage = Program.Host + "BlogetExamples/Example3.aspx?m=users";
        UserControlTester userControl;

        const string userId = "login_UserName";
        const string passwordId = "login_Password";
        const string submitId = "login_LoginButton";

        const string controlId = "bloget2";

        protected override void SetUp()
        {
            userControl = new UserControlTester(controlId, CurrentWebForm);
            TextBoxTester userSetup = new TextBoxTester(userId, userControl);
            TextBoxTester passwordSetup = new TextBoxTester(passwordId, userControl);
            ButtonTester submit = new ButtonTester(submitId, userControl);
            Browser.GetPage(testPage);
            userSetup.Text = Program.User;
            passwordSetup.Text = Program.Password;
            submit.Click(); // Login
            Browser.GetPage(testPage);

            userControl = new UserControlTester(controlId, CurrentWebForm);
        }

        [Test]
        public void TestLayout()
        {
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());
        }
    }
}
