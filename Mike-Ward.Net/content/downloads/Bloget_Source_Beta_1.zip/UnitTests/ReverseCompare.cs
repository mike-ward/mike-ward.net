// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.Collections;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class ReverseCompareTests
    {
        [Test]
        public void ReverseCompareTest()
        {
            ReverseCompare reverseCompare = new ReverseCompare();            
            Assert.Greater(((IComparer)reverseCompare).Compare("Left", "Right"), 0);
        }
    }
}
