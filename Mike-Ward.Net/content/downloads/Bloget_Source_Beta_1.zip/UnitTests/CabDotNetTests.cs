﻿// Copyright (C) 2008 Blue Onion Software
// All rights reserved

using BlueOnionSoftware.Bloget;
using NUnit.Framework;
using System.IO;

namespace BlogetTests
{
    [TestFixture]
    public class CabDotNetTests
    {
        [Test]
        public void CompressFile()
        {
            const string cabinetFile = "Bloget.CAB";

            if (File.Exists(cabinetFile))
            {
                File.Delete(cabinetFile);
            }

            using (CabCompressorHelper compressor = new CabCompressorHelper())
            {
                foreach (string file in Directory.GetFiles(@"..\..", "*.cs"))
                {
                    compressor.AddFile(file);
                }
            }

            Assert.IsTrue(File.Exists(cabinetFile));
        }
    }
}
