// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using NUnit.Framework;
using NUnit.Extensions.Asp;
using NUnit.Extensions.Asp.AspTester;

namespace BlogetTests
{
    [TestFixture]
    [Category("ASP")]
    public class AdminTests : WebFormTestCase
    {
        readonly string testPage = Program.Host + "BlogetExamples/Example3.aspx?m=admin";
        UserControlTester userControl;
        TextBoxTester title;
        TextBoxTester description;
        TextBoxTester link;
        //TextBoxTester firstName;
        //TextBoxTester lastName;

        TextBoxTester language;
        TextBoxTester copyright;
        TextBoxTester webMaster;
        //TextBoxTester author;
        TextBoxTester rssChannelImage;
        TextBoxTester rssFooter;
        TextBoxTester rssEntriesPerFeed;

        TextBoxTester itemsPerPage;
        DropDownListTester timeZone;
        TextBoxTester editorWidth;
        TextBoxTester editorHeight;

        CheckBoxTester allowComments;
        TextBoxTester expireComments;
        TextBoxTester maximumComments;
        TextBoxTester maximumPingBacks;

        CheckBoxTester emailComments;
        CheckBoxTester emailPingbacks;
        TextBoxTester emailTo;
        ButtonTester testEmail;

        CheckBoxTester enableRealSimpleDiscovery;
        CheckBoxTester enableMetaWebLogApi;
        TextBoxTester expirePingBacks;
        CheckBoxTester enableAutoPingBack;
        CheckBoxTester enablePingBackService;

        TextBoxTester imageFolder;
        TextBoxTester imageUrl;

        ButtonTester save;

        protected override void SetUp()
        {
            userControl = new UserControlTester("bloget2", CurrentWebForm);
            TextBoxTester userSetup = new TextBoxTester("login_UserName", userControl);
            TextBoxTester passwordSetup = new TextBoxTester("login_Password", userControl);
            ButtonTester submit = new ButtonTester("login_LoginButton", userControl);
            Browser.GetPage(testPage);
            userSetup.Text = Program.User;
            passwordSetup.Text = Program.Password;
            submit.Click(); // Login
            Browser.GetPage(testPage);

            userControl = new UserControlTester("bloget2", CurrentWebForm);
            title = new TextBoxTester("title", userControl);
            description = new TextBoxTester("description", userControl);
            link = new TextBoxTester("link", userControl);
            //firstName = new TextBoxTester("firstName", userControl);
            //lastName = new TextBoxTester("lastName", userControl);

            language = new TextBoxTester("language", userControl);
            copyright = new TextBoxTester("copyright", userControl);
            webMaster = new TextBoxTester("webMaster", userControl);
            //author = new TextBoxTester("author", userControl);
            rssChannelImage = new TextBoxTester("rssChannelImage", userControl);
            rssFooter = new TextBoxTester("rssFooter", userControl);
            rssEntriesPerFeed = new TextBoxTester("rssEntriesPerFeed", userControl);

            itemsPerPage = new TextBoxTester("itemsPerPage", userControl);
            timeZone = new DropDownListTester("timeZone", userControl);
            editorWidth = new TextBoxTester("editorWidth", userControl);
            editorHeight = new TextBoxTester("editorHeight", userControl);

            allowComments = new CheckBoxTester("allowComments", userControl);
            expireComments = new TextBoxTester("expireComments", userControl);
            maximumComments = new TextBoxTester("maximumComments", userControl);
            maximumPingBacks = new TextBoxTester("maximumPingBacks", userControl);

            emailComments = new CheckBoxTester("emailComments", userControl);
            emailPingbacks = new CheckBoxTester("emailPingbacks", userControl);
            emailTo = new TextBoxTester("emailTo", userControl);
            testEmail = new ButtonTester("testEmail", userControl);

            enableRealSimpleDiscovery = new CheckBoxTester("enableRSD", userControl);
            enableMetaWebLogApi = new CheckBoxTester("enableMetaWebLogApi", userControl);
            expirePingBacks = new TextBoxTester("expirePingBacks", userControl);
            enableAutoPingBack = new CheckBoxTester("enableAutoPingBack", userControl);
            enablePingBackService = new CheckBoxTester("enablePingBackService", userControl);

            imageFolder = new TextBoxTester("imageFolder", userControl);
            imageUrl = new TextBoxTester("imageUrl", userControl);

            save = new ButtonTester("saveButton", userControl);

            base.SetUp();
        }

        [Test]
        public void TestLayout()
        {
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());
            WebAssert.Visible(title);
            WebAssert.Visible(description);
            WebAssert.Visible(link);
            //WebAssert.Visible(firstName);
            //WebAssert.Visible(lastName);

            WebAssert.Visible(language);
            WebAssert.Visible(copyright);
            WebAssert.Visible(webMaster);
            //WebAssert.Visible(author);
            WebAssert.Visible(rssChannelImage);
            WebAssert.Visible(rssFooter);
            WebAssert.Visible(rssEntriesPerFeed);

            WebAssert.Visible(itemsPerPage);
            WebAssert.Visible(timeZone);
            WebAssert.Visible(editorWidth);
            WebAssert.Visible(editorHeight);

            WebAssert.Visible(allowComments);
            WebAssert.Visible(expireComments);
            WebAssert.Visible(maximumComments);
            WebAssert.Visible(maximumPingBacks);

            WebAssert.Visible(emailComments);
            WebAssert.Visible(emailPingbacks);
            WebAssert.Visible(emailTo);
            WebAssert.Visible(testEmail);

            WebAssert.Visible(enableRealSimpleDiscovery);
            WebAssert.Visible(enableMetaWebLogApi);
            WebAssert.Visible(expirePingBacks);
            WebAssert.Visible(enableAutoPingBack);
            WebAssert.Visible(enablePingBackService);

            WebAssert.Visible(imageFolder);
            WebAssert.Visible(imageUrl);
        }
    }
}
