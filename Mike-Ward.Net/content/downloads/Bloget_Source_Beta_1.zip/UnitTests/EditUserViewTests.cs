﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using NUnit.Framework;
using NUnit.Extensions.Asp;
using NUnit.Extensions.Asp.AspTester;
using System.Diagnostics.CodeAnalysis;
using BlueOnionSoftware.Bloget;

namespace BlogetTests
{
    [TestFixture]
    [Category("ASP")]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class EditUserViewTests : WebFormTestCase
    {
        readonly string testPage = Program.Host + "BlogetExamples/Example3.aspx?m=edituser&u=admin";
        UserControlTester userControl;
        TextBoxTester name;
        TextBoxTester password;
        TextBoxTester password1;
        TextBoxTester password2;
        TextBoxTester email;
        ButtonTester editUser;
        ButtonTester removeUser;

        LabelTester nameLabel;
        LabelTester passwordLabel;
        LabelTester password1Label;
        LabelTester password2Label;
        LabelTester emailLabel;

        const string controlId = "bloget2";
        const string userId = "login_UserName";
        const string passwordId = "login_Password";
        const string submitId = "login_LoginButton";

        protected override void SetUp()
        {
            const string label = "label";

            userControl = new UserControlTester(controlId, CurrentWebForm);
            TextBoxTester userSetup = new TextBoxTester(userId, userControl);
            TextBoxTester passwordSetup = new TextBoxTester(passwordId, userControl);
            ButtonTester submit = new ButtonTester(submitId, userControl);
            Browser.GetPage(testPage);
            userSetup.Text = Program.User;
            passwordSetup.Text = Program.Password;
            submit.Click(); // Login
            Browser.GetPage(testPage);

            userControl = new UserControlTester(controlId, CurrentWebForm);
            name = new TextBoxTester("name", userControl);
            password = new TextBoxTester("password", userControl);
            password1 = new TextBoxTester("password1", userControl);
            password2 = new TextBoxTester("password2", userControl);
            email = new TextBoxTester("email", userControl);
            editUser = new ButtonTester("edit_user", userControl);
            removeUser = new ButtonTester("remove_user", userControl);

            nameLabel = new LabelTester(label + name.AspId, userControl);
            passwordLabel = new LabelTester(label + password.AspId, userControl);
            password1Label = new LabelTester(label + password1.AspId, userControl);
            password2Label = new LabelTester(label + password2.AspId, userControl);
            emailLabel = new LabelTester(label + email.AspId, userControl);
        }

        [Test]
        public void TestLayout()
        {
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());

            WebAssert.Visible(name);
            WebAssert.Visible(password);
            WebAssert.Visible(password1);
            WebAssert.Visible(password2);
            WebAssert.Visible(email);
            WebAssert.Visible(editUser);
            WebAssert.NotVisible(removeUser);

            WebAssert.Visible(nameLabel);
            WebAssert.Visible(passwordLabel);
            WebAssert.Visible(password1Label);
            WebAssert.Visible(password2Label);
            WebAssert.Visible(emailLabel);
        }

        [Test]
        public void TestLabels()
        {
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());

            NUnit.Framework.Assert.IsNotEmpty(nameLabel.Text);
            NUnit.Framework.Assert.IsNotEmpty(password1Label.Text);
            NUnit.Framework.Assert.IsNotEmpty(password2Label.Text);
            NUnit.Framework.Assert.IsNotEmpty(emailLabel.Text);
        }
    }
}