// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class TimeInformationTests
    {
        [Test]
        public void ToLocalTime()
        {
            DateTime now = DateTime.UtcNow;
            Assert.AreEqual(now.AddHours(12), Time.LocalTime(12, now));
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ToLocalTimePositiveRangeCheck()
        {
            Time.LocalTime(15, DateTime.UtcNow);
        }

        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ToLocalTimeNegativeRangeCheck()
        {
            Time.LocalTime(-13, DateTime.UtcNow);
        }

        [Test]
        public void TimeRange()
        {
            int[] times = Time.TimeOffsets();
            Assert.AreEqual(25, times.Length);
        }
    }
}
