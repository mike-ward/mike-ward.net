// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;

namespace BlogetTests
{
    /// <summary>
    /// Unit tests are designed to run with TestDriven.Net 2.0
    /// </summary>
    internal sealed class Program
    {
        static void Main()
        {
            Console.WriteLine("Run unit tests with TestDriven.Net 2.0");
        }

        static internal string Host
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["host"]; }
        }

        static internal string Password
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["password"]; }
        }

        static internal string User
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["user"]; }
        }
    }
}
