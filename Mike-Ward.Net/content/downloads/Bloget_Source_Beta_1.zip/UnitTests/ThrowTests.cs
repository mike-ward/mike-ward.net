﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Diagnostics.CodeAnalysis;
using BlueOnionSoftware.Bloget;
using NUnit.Framework;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class ThrowTests
    {
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ObjectNullTest()
        {
            Throw.IfNull(null, null);
        }

        [Test]
        public void ObjectOkTest()
        {
            Throw.IfNull(this, "this");
            Assert.IsTrue(true);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void StringNullTest()
        {
            Throw.IfNullOrEmpty(null, null);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void StringEmptyTest()
        {
            Throw.IfNullOrEmpty(string.Empty, string.Empty);
        }

        [Test]
        public void StringOkTest()
        {
            Throw.IfNullOrEmpty("test", "test");
            Assert.IsTrue(true);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void GuidEmptyTest()
        {
            Throw.IfEmpty(Guid.Empty, null);
        }

        [Test]
        public void GuidOkTest()
        {
            Throw.IfEmpty(Guid.NewGuid(), "newGuid");
            Assert.IsTrue(true);
        }
    }
}
