﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.Diagnostics.CodeAnalysis;
using System.IO;
using BlueOnionSoftware.Bloget;
using NUnit.Framework;

namespace BlogetTests
{
    [TestFixture]
    [SetUpFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class BlogTests
    {
        [SetUp]
        public void GlobalSetup()
        {
            BlueOnionSoftware.Bloget.Providers.BlogProvider.LoadProviderForUnitTests();   
        }

        [Test]
        public void CreateBlog()
        {
            string path = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());

            try
            {
                Blog blog = Blog.Load(path);
                Assert.IsTrue(File.Exists(path));
            }

            finally
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
        }
    }
}
