using System.Diagnostics.CodeAnalysis;
using BlueOnionSoftware.Bloget.Properties;
using NUnit.Framework;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class PropertyTests
    {
        [Test]
        public void AdminViewAllowComments()
        {
            Assert.IsNotNull(Resources.AdminViewAllowComments);
            Assert.IsNotEmpty(Resources.AdminViewAllowComments);
        }

        [Test]
        public void AdminViewAllowCommentsTip()
        {
            Assert.IsNotNull(Resources.AdminViewAllowCommentsTip);
            Assert.IsNotEmpty(Resources.AdminViewAllowCommentsTip);
        }

        [Test]
        public void AdminViewAppearanceSection()
        {
            Assert.IsNotNull(Resources.AdminViewAppearanceSection);
            Assert.IsNotEmpty(Resources.AdminViewAppearanceSection);
        }

        [Test]
        public void AdminViewBasicInformationSection()
        {
            Assert.IsNotNull(Resources.AdminViewBasicInformationSection);
            Assert.IsNotEmpty(Resources.AdminViewBasicInformationSection);
        }

        [Test]
        public void AdminViewBlogLink()
        {
            Assert.IsNotNull(Resources.AdminViewBlogLink);
            Assert.IsNotEmpty(Resources.AdminViewBlogLink);
        }

        [Test]
        public void AdminViewBlogLinkTip()
        {
            Assert.IsNotNull(Resources.AdminViewBlogLinkTip);
            Assert.IsNotEmpty(Resources.AdminViewBlogLinkTip);
        }

        [Test]
        public void AdminViewCommentsPerPost()
        {
            Assert.IsNotNull(Resources.AdminViewCommentsPerPost);
            Assert.IsNotEmpty(Resources.AdminViewCommentsPerPost);
        }

        [Test]
        public void AdminViewCommentsPerPostTip()
        {
            Assert.IsNotNull(Resources.AdminViewCommentsPerPostTip);
            Assert.IsNotEmpty(Resources.AdminViewCommentsPerPostTip);
        }

        [Test]
        public void AdminViewCommentsSection()
        {
            Assert.IsNotNull(Resources.AdminViewCommentsSection);
            Assert.IsNotEmpty(Resources.AdminViewCommentsSection);
        }

        [Test]
        public void AdminViewConfirmNewPassword()
        {
            Assert.IsNotNull(Resources.AdminViewConfirmNewPassword);
            Assert.IsNotEmpty(Resources.AdminViewConfirmNewPassword);
        }

        [Test]
        public void AdminViewConfirmNewPasswordTip()
        {
            Assert.IsNotNull(Resources.AdminViewConfirmNewPasswordTip);
            Assert.IsNotEmpty(Resources.AdminViewConfirmNewPasswordTip);
        }

        [Test]
        public void AdminViewCopyright()
        {
            Assert.IsNotNull(Resources.AdminViewCopyright);
            Assert.IsNotEmpty(Resources.AdminViewCopyright);
        }

        [Test]
        public void AdminViewCopyrightTip()
        {
            Assert.IsNotNull(Resources.AdminViewCopyrightTip);
            Assert.IsNotEmpty(Resources.AdminViewCopyrightTip);
        }

        [Test]
        public void AdminViewDoneButton()
        {
            Assert.IsNotNull(Resources.AdminViewDoneButton);
            Assert.IsNotEmpty(Resources.AdminViewDoneButton);
        }

        [Test]
        public void AdminViewEditorHeight()
        {
            Assert.IsNotNull(Resources.AdminViewEditorHeight);
            Assert.IsNotEmpty(Resources.AdminViewEditorHeight);
        }

        [Test]
        public void AdminViewEditorHeightTip()
        {
            Assert.IsNotNull(Resources.AdminViewEditorHeightTip);
            Assert.IsNotEmpty(Resources.AdminViewEditorHeightTip);
        }

        [Test]
        public void AdminViewEditorWidth()
        {
            Assert.IsNotNull(Resources.AdminViewEditorWidth);
            Assert.IsNotEmpty(Resources.AdminViewEditorWidth);
        }

        [Test]
        public void AdminViewEditorWidthTip()
        {
            Assert.IsNotNull(Resources.AdminViewEditorWidthTip);
            Assert.IsNotEmpty(Resources.AdminViewEditorWidthTip);
        }

        [Test]
        public void AdminViewExpireComments()
        {
            Assert.IsNotNull(Resources.AdminViewExpireComments);
            Assert.IsNotEmpty(Resources.AdminViewExpireComments);
        }

        [Test]
        public void AdminViewExpireCommentsTip()
        {
            Assert.IsNotNull(Resources.AdminViewExpireCommentsTip);
            Assert.IsNotEmpty(Resources.AdminViewExpireCommentsTip);
        }

        [Test]
        public void AdminViewImageFolder()
        {
            Assert.IsNotNull(Resources.AdminViewImageFolder);
            Assert.IsNotEmpty(Resources.AdminViewImageFolder);
        }

        [Test]
        public void AdminViewImageFolderTip()
        {
            Assert.IsNotNull(Resources.AdminViewImageFolderTip);
            Assert.IsNotEmpty(Resources.AdminViewImageFolderTip);
        }

        [Test]
        public void AdminViewImagesSection()
        {
            Assert.IsNotNull(Resources.AdminViewImagesSection);
            Assert.IsNotEmpty(Resources.AdminViewImagesSection);
        }

        [Test]
        public void AdminViewImageUrl()
        {
            Assert.IsNotNull(Resources.AdminViewImageUrl);
            Assert.IsNotEmpty(Resources.AdminViewImageUrl);
        }

        [Test]
        public void AdminViewImageUrlTip()
        {
            Assert.IsNotNull(Resources.AdminViewImageUrlTip);
            Assert.IsNotEmpty(Resources.AdminViewImageUrlTip);
        }

        [Test]
        public void AdminViewImportExportDownloadButton()
        {
            Assert.IsNotNull(Resources.AdminViewImportExportDownloadButton);
            Assert.IsNotEmpty(Resources.AdminViewImportExportDownloadButton);
        }

        [Test]
        public void AdminViewImportExportDownloadButtonTip()
        {
            Assert.IsNotNull(Resources.AdminViewImportExportDownloadButtonTip);
            Assert.IsNotEmpty(Resources.AdminViewImportExportDownloadButtonTip);
        }

        [Test]
        public void AdminViewImportExportExportLabel()
        {
            Assert.IsNotNull(Resources.AdminViewImportExportExportLabel);
            Assert.IsNotEmpty(Resources.AdminViewImportExportExportLabel);
        }

        [Test]
        public void AdminViewImportExportImportButton()
        {
            Assert.IsNotNull(Resources.AdminViewImportExportImportButton);
            Assert.IsNotEmpty(Resources.AdminViewImportExportImportButton);
        }

        [Test]
        public void AdminViewImportExportImportButtonTip()
        {
            Assert.IsNotNull(Resources.AdminViewImportExportImportButtonTip);
            Assert.IsNotEmpty(Resources.AdminViewImportExportImportButtonTip);
        }

        [Test]
        public void AdminViewImportExportImportLabel()
        {
            Assert.IsNotNull(Resources.AdminViewImportExportImportLabel);
            Assert.IsNotEmpty(Resources.AdminViewImportExportImportLabel);
        }

        [Test]
        public void AdminViewImportExportSection()
        {
            Assert.IsNotNull(Resources.AdminViewImportExportSection);
            Assert.IsNotEmpty(Resources.AdminViewImportExportSection);
        }

        [Test]
        public void AdminViewItemsPerPage()
        {
            Assert.IsNotNull(Resources.AdminViewItemsPerPage);
            Assert.IsNotEmpty(Resources.AdminViewItemsPerPage);
        }

        [Test]
        public void AdminViewItemsPerPageTip()
        {
            Assert.IsNotNull(Resources.AdminViewItemsPerPageTip);
            Assert.IsNotEmpty(Resources.AdminViewItemsPerPageTip);
        }

        [Test]
        public void AdminViewLanguage()
        {
            Assert.IsNotNull(Resources.AdminViewLanguage);
            Assert.IsNotEmpty(Resources.AdminViewLanguage);
        }

        [Test]
        public void AdminViewLanguageTip()
        {
            Assert.IsNotNull(Resources.AdminViewLanguageTip);
            Assert.IsNotEmpty(Resources.AdminViewLanguageTip);
        }

        [Test]
        public void AdminViewNewPassword()
        {
            Assert.IsNotNull(Resources.AdminViewNewPassword);
            Assert.IsNotEmpty(Resources.AdminViewNewPassword);
        }

        [Test]
        public void AdminViewNewPasswordTip()
        {
            Assert.IsNotNull(Resources.AdminViewNewPasswordTip);
            Assert.IsNotEmpty(Resources.AdminViewNewPasswordTip);
        }

        [Test]
        public void AdminViewNotificationsSection()
        {
            Assert.IsNotNull(Resources.AdminViewNotificationsSection);
            Assert.IsNotEmpty(Resources.AdminViewNotificationsSection);
        }

        [Test]
        public void AdminViewNotifyComments()
        {
            Assert.IsNotNull(Resources.AdminViewNotifyComments);
            Assert.IsNotEmpty(Resources.AdminViewNotifyComments);
        }

        [Test]
        public void AdminViewNotifyCommentsTip()
        {
            Assert.IsNotNull(Resources.AdminViewNotifyCommentsTip);
            Assert.IsNotEmpty(Resources.AdminViewNotifyCommentsTip);
        }

        [Test]
        public void AdminViewNotifyPingbacks()
        {
            Assert.IsNotNull(Resources.AdminViewNotifyPingBacks);
            Assert.IsNotEmpty(Resources.AdminViewNotifyPingBacks);
        }

        [Test]
        public void AdminViewNotifyPingbacksTip()
        {
            Assert.IsNotNull(Resources.AdminViewNotifyPingBacksTip);
            Assert.IsNotEmpty(Resources.AdminViewNotifyPingBacksTip);
        }

        [Test]
        public void AdminViewNotifyTestMessageButton()
        {
            Assert.IsNotNull(Resources.AdminViewNotifyTestMessageButton);
            Assert.IsNotEmpty(Resources.AdminViewNotifyTestMessageButton);
        }

        [Test]
        public void AdminViewNotifyToAddress()
        {
            Assert.IsNotNull(Resources.AdminViewNotifyToAddress);
            Assert.IsNotEmpty(Resources.AdminViewNotifyToAddress);
        }

        [Test]
        public void AdminViewNotifyToAddressTip()
        {
            Assert.IsNotNull(Resources.AdminViewNotifyToAddressTip);
            Assert.IsNotEmpty(Resources.AdminViewNotifyToAddressTip);
        }

        [Test]
        public void AdminViewOldPassword()
        {
            Assert.IsNotNull(Resources.AdminViewOldPassword);
            Assert.IsNotEmpty(Resources.AdminViewOldPassword);
        }

        [Test]
        public void AdminViewOldPasswordTip()
        {
            Assert.IsNotNull(Resources.AdminViewOldPasswordTip);
            Assert.IsNotEmpty(Resources.AdminViewOldPasswordTip);
        }

        [Test]
        public void AdminViewPasswordSection()
        {
            Assert.IsNotNull(Resources.AdminViewPasswordSection);
            Assert.IsNotEmpty(Resources.AdminViewPasswordSection);
        }

        [Test]
        public void AdminViewPostsPerFeed()
        {
            Assert.IsNotNull(Resources.AdminViewPostsPerFeed);
            Assert.IsNotEmpty(Resources.AdminViewPostsPerFeed);
        }

        [Test]
        public void AdminViewPostsPerFeedTip()
        {
            Assert.IsNotNull(Resources.AdminViewPostsPerFeedTip);
            Assert.IsNotEmpty(Resources.AdminViewPostsPerFeedTip);
        }

        [Test]
        public void AdminViewRssChannelImage()
        {
            Assert.IsNotNull(Resources.AdminViewRssChannelImage);
            Assert.IsNotEmpty(Resources.AdminViewRssChannelImage);
        }

        [Test]
        public void AdminViewRssChannelImageTip()
        {
            Assert.IsNotNull(Resources.AdminViewRssChannelImageTip);
            Assert.IsNotEmpty(Resources.AdminViewRssChannelImageTip);
        }

        [Test]
        public void AdminViewRssFooter()
        {
            Assert.IsNotNull(Resources.AdminViewRssFooter);
            Assert.IsNotEmpty(Resources.AdminViewRssFooter);
        }

        [Test]
        public void AdminViewRssFooterTip()
        {
            Assert.IsNotNull(Resources.AdminViewRssFooterTip);
            Assert.IsNotEmpty(Resources.AdminViewRssFooterTip);
        }

        [Test]
        public void AdminViewSaveButton()
        {
            Assert.IsNotNull(Resources.AdminViewSaveButton);
            Assert.IsNotEmpty(Resources.AdminViewSaveButton);
        }

        [Test]
        public void AdminViewServerTime()
        {
            Assert.IsNotNull(Resources.AdminViewServerTime);
            Assert.IsNotEmpty(Resources.AdminViewServerTime);
        }

        [Test]
        public void AdminViewServicesAcceptPingbacks()
        {
            Assert.IsNotNull(Resources.AdminViewServicesAcceptPingBacks);
            Assert.IsNotEmpty(Resources.AdminViewServicesAcceptPingBacks);
        }

        [Test]
        public void AdminViewServicesAcceptPingbacksTip()
        {
            Assert.IsNotNull(Resources.AdminViewServicesAcceptPingBacksTip);
            Assert.IsNotEmpty(Resources.AdminViewServicesAcceptPingBacksTip);
        }

        [Test]
        public void AdminViewServicesExpirePingbacks()
        {
            Assert.IsNotNull(Resources.AdminViewServicesExpirePingBacks);
            Assert.IsNotEmpty(Resources.AdminViewServicesExpirePingBacks);
        }

        [Test]
        public void AdminViewServicesExpirePingbacksTip()
        {
            Assert.IsNotNull(Resources.AdminViewServicesExpirePingBacksTip);
            Assert.IsNotEmpty(Resources.AdminViewServicesExpirePingBacksTip);
        }

        [Test]
        public void AdminViewServicesMaximumPingbacks()
        {
            Assert.IsNotNull(Resources.AdminViewServicesMaximumPingBacks);
            Assert.IsNotEmpty(Resources.AdminViewServicesMaximumPingBacks);
        }

        [Test]
        public void AdminViewServicesMaximumPingbacksTip()
        {
            Assert.IsNotNull(Resources.AdminViewServicesMaximumPingBacksTip);
            Assert.IsNotEmpty(Resources.AdminViewServicesMaximumPingBacksTip);
        }

        [Test]
        public void AdminViewServicesMetaWeblogApi()
        {
            Assert.IsNotNull(Resources.AdminViewServicesMetaWeblogApi);
            Assert.IsNotEmpty(Resources.AdminViewServicesMetaWeblogApi);
        }

        [Test]
        public void AdminViewServicesMetaWeblogApiTip()
        {
            Assert.IsNotNull(Resources.AdminViewServicesMetaWeblogApiTip);
            Assert.IsNotEmpty(Resources.AdminViewServicesMetaWeblogApiTip);
        }

        [Test]
        public void AdminViewServicesRsd()
        {
            Assert.IsNotNull(Resources.AdminViewServicesRsd);
            Assert.IsNotEmpty(Resources.AdminViewServicesRsd);
        }

        [Test]
        public void AdminViewServicesRsdTip()
        {
            Assert.IsNotNull(Resources.AdminViewServicesRsdTip);
            Assert.IsNotEmpty(Resources.AdminViewServicesRsdTip);
        }

        [Test]
        public void AdminViewServicesSection()
        {
            Assert.IsNotNull(Resources.AdminViewServicesSection);
            Assert.IsNotEmpty(Resources.AdminViewServicesSection);
        }

        [Test]
        public void AdminViewServicesSendPingbacks()
        {
            Assert.IsNotNull(Resources.AdminViewServicesSendPingbacks);
            Assert.IsNotEmpty(Resources.AdminViewServicesSendPingbacks);
        }

        [Test]
        public void AdminViewServicesSendPingbacksTips()
        {
            Assert.IsNotNull(Resources.AdminViewServicesSendPingbacksTips);
            Assert.IsNotEmpty(Resources.AdminViewServicesSendPingbacksTips);
        }

        [Test]
        public void AdminViewSubtitle()
        {
            Assert.IsNotNull(Resources.AdminViewSubtitle);
            Assert.IsNotEmpty(Resources.AdminViewSubtitle);
        }

        [Test]
        public void AdminViewSummaryValidation()
        {
            Assert.IsNotNull(Resources.AdminViewSummaryValidation);
            Assert.IsNotEmpty(Resources.AdminViewSummaryValidation);
        }

        [Test]
        public void AdminViewSyndicationSection()
        {
            Assert.IsNotNull(Resources.AdminViewSyndicationSection);
            Assert.IsNotEmpty(Resources.AdminViewSyndicationSection);
        }

        [Test]
        public void AdminViewTestEmailMessage()
        {
            Assert.IsNotNull(Resources.AdminViewTestEmailMessage);
            Assert.IsNotEmpty(Resources.AdminViewTestEmailMessage);
        }

        [Test]
        public void AdminViewTestEmailSubject()
        {
            Assert.IsNotNull(Resources.AdminViewTestEmailSubject);
            Assert.IsNotEmpty(Resources.AdminViewTestEmailSubject);
        }

        [Test]
        public void AdminViewTimeZone()
        {
            Assert.IsNotNull(Resources.AdminViewTimeZone);
            Assert.IsNotEmpty(Resources.AdminViewTimeZone);
        }

        [Test]
        public void AdminViewTitle()
        {
            Assert.IsNotNull(Resources.AdminViewTitle);
            Assert.IsNotEmpty(Resources.AdminViewTitle);
        }

        [Test]
        public void AdminViewVirtualPathValidator()
        {
            Assert.IsNotNull(Resources.AdminViewVirtualPathValidator);
            Assert.IsNotEmpty(Resources.AdminViewVirtualPathValidator);
        }

        [Test]
        public void AdminViewVirtualPathValidatorTip()
        {
            Assert.IsNotNull(Resources.AdminViewVirtualPathValidatorTip);
            Assert.IsNotEmpty(Resources.AdminViewVirtualPathValidatorTip);
        }

        [Test]
        public void AdminViewWebMaster()
        {
            Assert.IsNotNull(Resources.AdminViewWebMaster);
            Assert.IsNotEmpty(Resources.AdminViewWebMaster);
        }

        [Test]
        public void AdminViewWebMasterTip()
        {
            Assert.IsNotNull(Resources.AdminViewWebMasterTip);
            Assert.IsNotEmpty(Resources.AdminViewWebMasterTip);
        }

        [Test]
        public void ArchiveViewDesignTimeHtml()
        {
            Assert.IsNotNull(Resources.ArchiveViewDesignTimeHtml);
            Assert.IsNotEmpty(Resources.ArchiveViewDesignTimeHtml);
        }

        [Test]
        public void BlogCopyright()
        {
            Assert.IsNotNull(Resources.BlogCopyright);
            Assert.IsNotEmpty(Resources.BlogCopyright);
        }

        [Test]
        public void BlogDescription()
        {
            Assert.IsNotNull(Resources.BlogDescription);
            Assert.IsNotEmpty(Resources.BlogDescription);
        }

        [Test]
        public void BlogetTitle()
        {
            Assert.IsNotNull(Resources.BlogetTitle);
            Assert.IsNotEmpty(Resources.BlogetTitle);
        }

        [Test]
        public void BlogFirstPostTitle()
        {
            Assert.IsNotNull(Resources.BlogFirstPostTitle);
            Assert.IsNotEmpty(Resources.BlogFirstPostTitle);
        }

        [Test]
        public void BlogLanguage()
        {
            Assert.IsNotNull(Resources.BlogLanguage);
            Assert.IsNotEmpty(Resources.BlogLanguage);
        }

        [Test]
        public void BlogLink()
        {
            Assert.IsNotNull(Resources.BlogLink);
            Assert.IsNotEmpty(Resources.BlogLink);
        }

        [Test]
        public void BlogRssFooter()
        {
            Assert.IsNotNull(Resources.BlogRssFooter);
            Assert.IsNotEmpty(Resources.BlogRssFooter);
        }

        [Test]
        public void BlogTitle()
        {
            Assert.IsNotNull(Resources.BlogTitle);
            Assert.IsNotEmpty(Resources.BlogTitle);
        }

        [Test]
        public void BlogWebmaster()
        {
            Assert.IsNotNull(Resources.BlogWebmaster);
            Assert.IsNotEmpty(Resources.BlogWebmaster);
        }

        [Test]
        public void CategoriesAdd()
        {
            Assert.IsNotNull(Resources.CategoriesAdd);
            Assert.IsNotEmpty(Resources.CategoriesAdd);
        }

        [Test]
        public void CategoriesConfirmDelete()
        {
            Assert.IsNotNull(Resources.CategoriesConfirmDelete);
            Assert.IsNotEmpty(Resources.CategoriesConfirmDelete);
        }

        [Test]
        public void CategoriesDelete()
        {
            Assert.IsNotNull(Resources.CategoriesDelete);
            Assert.IsNotEmpty(Resources.CategoriesDelete);
        }

        [Test]
        public void CategoriesEdit()
        {
            Assert.IsNotNull(Resources.CategoriesEdit);
            Assert.IsNotEmpty(Resources.CategoriesEdit);
        }

        [Test]
        public void ContactFormDesignTimeHtml()
        {
            Assert.IsNotNull(Resources.ContactFormDesignTimeHtml);
            Assert.IsNotEmpty(Resources.ContactFormDesignTimeHtml);
        }

        [Test]
        public void ContactFormNameLabel()
        {
            Assert.IsNotNull(Resources.ContactFormNameLabel);
            Assert.IsNotEmpty(Resources.ContactFormNameLabel);
        }

        [Test]
        public void ContactFormEmailLabel()
        {
            Assert.IsNotNull(Resources.ContactFormEmailLabel);
            Assert.IsNotEmpty(Resources.ContactFormEmailLabel);
        }

        [Test]
        public void ContactFormMessageLabel()
        {
            Assert.IsNotNull(Resources.ContactFormMessageLabel);
            Assert.IsNotEmpty(Resources.ContactFormMessageLabel);
        }

        [Test]
        public void ContactFormSubmitLabel()
        {
            Assert.IsNotNull(Resources.ContactFormSubmitLabel);
            Assert.IsNotEmpty(Resources.ContactFormSubmitLabel);
        }

        [Test]
        public void ContactFormMessageForm()
        {
            Assert.IsNotNull(Resources.ContactFormMessageFormat);
            Assert.IsNotEmpty(Resources.ContactFormMessageFormat);
        }

        [Test]
        public void ContactFormMessageSubject()
        {
            Assert.IsNotNull(Resources.ContactFormMessageSubject);
            Assert.IsNotEmpty(Resources.ContactFormMessageSubject);
        }

        [Test]
        public void EditAllowCommentsButton()
        {
            Assert.IsNotNull(Resources.EditAllowCommentsButton);
            Assert.IsNotEmpty(Resources.EditAllowCommentsButton);
        }

        [Test]
        public void EditViewAddFile()
        {
            Assert.IsNotNull(Resources.EditViewAddFile);
            Assert.IsNotEmpty(Resources.EditViewAddFile);
        }

        [Test]
        public void EditViewAddImage()
        {
            Assert.IsNotNull(Resources.EditViewAddImage);
            Assert.IsNotEmpty(Resources.EditViewAddImage);
        }

        [Test]
        public void EditViewCancel()
        {
            Assert.IsNotNull(Resources.EditViewCancel);
            Assert.IsNotEmpty(Resources.EditViewCancel);
        }

        [Test]
        public void EditViewConfirmCancel()
        {
            Assert.IsNotNull(Resources.EditViewConfirmCancel);
            Assert.IsNotEmpty(Resources.EditViewConfirmCancel);
        }

        [Test]
        public void EditViewConfirmRemove()
        {
            Assert.IsNotNull(Resources.EditViewConfirmRemove);
            Assert.IsNotEmpty(Resources.EditViewConfirmRemove);
        }

        [Test]
        public void EditViewDraft()
        {
            Assert.IsNotNull(Resources.EditViewDraft);
            Assert.IsNotEmpty(Resources.EditViewDraft);
        }

        [Test]
        public void EditViewInvalidPostParameter()
        {
            Assert.IsNotNull(Resources.EditViewInvalidPostParameter);
            Assert.IsNotEmpty(Resources.EditViewInvalidPostParameter);
        }

        [Test]
        public void EditViewKilobyte()
        {
            Assert.IsNotNull(Resources.EditViewKilobyte);
            Assert.IsNotEmpty(Resources.EditViewKilobyte);
        }

        [Test]
        public void EditViewMegabyte()
        {
            Assert.IsNotNull(Resources.EditViewMegabyte);
            Assert.IsNotEmpty(Resources.EditViewMegabyte);
        }

        [Test]
        public void EditViewNewCategory()
        {
            Assert.IsNotNull(Resources.EditViewNewCategory);
            Assert.IsNotEmpty(Resources.EditViewNewCategory);
        }

        [Test]
        public void EditViewPost()
        {
            Assert.IsNotNull(Resources.EditViewPost);
            Assert.IsNotEmpty(Resources.EditViewPost);
        }

        [Test]
        public void EditViewRemove()
        {
            Assert.IsNotNull(Resources.EditViewRemove);
            Assert.IsNotEmpty(Resources.EditViewRemove);
        }

        [Test]
        public void EditViewRemovePostError()
        {
            Assert.IsNotNull(Resources.EditViewRemovePostError);
            Assert.IsNotEmpty(Resources.EditViewRemovePostError);
        }

        [Test]
        public void EditViewRssEnclosure()
        {
            Assert.IsNotNull(Resources.EditViewRssEnclosure);
            Assert.IsNotEmpty(Resources.EditViewRssEnclosure);
        }

        [Test]
        public void EditViewSyndicate()
        {
            Assert.IsNotNull(Resources.EditViewSyndicate);
            Assert.IsNotEmpty(Resources.EditViewSyndicate);
        }

        [Test]
        public void EditViewTitle()
        {
            Assert.IsNotNull(Resources.EditViewTitle);
            Assert.IsNotEmpty(Resources.EditViewTitle);
        }

        [Test]
        public void EditUserViewHeader()
        {
            Assert.IsNotNull(Resources.EditUserViewHeader);
            Assert.IsNotEmpty(Resources.EditUserViewHeader);
        }

        [Test]
        public void EditUserViewSubmit()
        {
            Assert.IsNotNull(Resources.EditUserViewSubmit);
            Assert.IsNotEmpty(Resources.EditUserViewSubmit);
        }

        [Test]
        public void EditUserViewNoUserSpecified()
        {
            Assert.IsNotNull(Resources.EditUserViewNoUserSpecified);
            Assert.IsNotEmpty(Resources.EditUserViewNoUserSpecified);
        }

        [Test]
        public void EditUserViewRoleNone()
        {
            Assert.IsNotNull(Resources.EditUserViewRoleNone);
            Assert.IsNotEmpty(Resources.EditUserViewRoleNone);
        }

        [Test]
        public void EditUserViewRoleAuthor()
        {
            Assert.IsNotNull(Resources.EditUserViewRoleAuthor);
            Assert.IsNotEmpty(Resources.EditUserViewRoleAuthor);
        }

        [Test]
        public void EditUserViewConfirmRemove()
        {
            Assert.IsNotNull(Resources.EditUserViewConfirmRemove);
            Assert.IsNotEmpty(Resources.EditUserViewConfirmRemove);
        }

        [Test]
        public void EditUserViewDisplayName()
        {
            Assert.IsNotNull(Resources.EditUserViewDisplayName);
            Assert.IsNotEmpty(Resources.EditUserViewDisplayName);
        }

        [Test]
        public void EditUserViewRemoveUserButton()
        {
            Assert.IsNotNull(Resources.EditUserViewRemoveUserButton);
            Assert.IsNotEmpty(Resources.EditUserViewRemoveUserButton);
        }

        [Test]
        public void EditUserViewRoleAdministrator()
        {
            Assert.IsNotNull(Resources.EditUserViewRoleAdministrator);
            Assert.IsNotEmpty(Resources.EditUserViewRoleAdministrator);
        }

        [Test]
        public void IndexViewNoEntriesFound()
        {
            Assert.IsNotNull(Resources.IndexViewNoEntriesFound);
            Assert.IsNotEmpty(Resources.IndexViewNoEntriesFound);
        }

        [Test]
        public void LicenseAgreement()
        {
            Assert.IsNotNull(Resources.LicenseAgreement);
            Assert.IsNotEmpty(Resources.LicenseAgreement);
        }

        [Test]
        public void LicenseViewAccept()
        {
            Assert.IsNotNull(Resources.LicenseViewAccept);
            Assert.IsNotEmpty(Resources.LicenseViewAccept);
        }

        [Test]
        public void MainMenuAdmin()
        {
            Assert.IsNotNull(Resources.MainMenuAdmin);
            Assert.IsNotEmpty(Resources.MainMenuAdmin);
        }

        [Test]
        public void MainMenuCategories()
        {
            Assert.IsNotNull(Resources.MainMenuCategories);
            Assert.IsNotEmpty(Resources.MainMenuCategories);
        }

        [Test]
        public void MainMenuDrafts()
        {
            Assert.IsNotNull(Resources.MainMenuDrafts);
            Assert.IsNotEmpty(Resources.MainMenuDrafts);
        }

        [Test]
        public void MainMenuEventLog()
        {
            Assert.IsNotNull(Resources.MainMenuEventLog);
            Assert.IsNotEmpty(Resources.MainMenuEventLog);
        }

        [Test]
        public void MainMenuLogout()
        {
            Assert.IsNotNull(Resources.MainMenuLogout);
            Assert.IsNotEmpty(Resources.MainMenuLogout);
        }

        [Test]
        public void MainMenuUsers()
        {
            Assert.IsNotNull(Resources.MainMenuUsers);
            Assert.IsNotEmpty(Resources.MainMenuUsers);
        }

        [Test]
        public void MainMenuViewBlog()
        {
            Assert.IsNotNull(Resources.MainMenuViewBlog);
            Assert.IsNotEmpty(Resources.MainMenuViewBlog);
        }

        [Test]
        public void MainMenuWrite()
        {
            Assert.IsNotNull(Resources.MainMenuWrite);
            Assert.IsNotEmpty(Resources.MainMenuWrite);
        }

        [Test]
        public void PasswordViewPassword()
        {
            Assert.IsNotNull(Resources.PasswordViewPassword);
            Assert.IsNotEmpty(Resources.PasswordViewPassword);
        }

        [Test]
        public void PasswordViewSubmit()
        {
            Assert.IsNotNull(Resources.PasswordViewSubmit);
            Assert.IsNotEmpty(Resources.PasswordViewSubmit);
        }

        [Test]
        public void PasswordViewUser()
        {
            Assert.IsNotNull(Resources.PasswordViewUser);
            Assert.IsNotEmpty(Resources.PasswordViewUser);
        }

        [Test]
        public void PasswordViewValidatorText()
        {
            Assert.IsNotNull(Resources.PasswordViewValidatorText);
            Assert.IsNotEmpty(Resources.PasswordViewValidatorText);
        }

        [Test]
        public void PoweredBy()
        {
            Assert.IsNotNull(Resources.PoweredBy);
            Assert.IsNotEmpty(Resources.PoweredBy);
        }

        [Test]
        public void SearchFindButton()
        {
            Assert.IsNotNull(Resources.SearchFindButton);
            Assert.IsNotEmpty(Resources.SearchFindButton);
        }

        [Test]
        public void SearchResults()
        {
            Assert.IsNotNull(Resources.SearchResults);
            Assert.IsNotEmpty(Resources.SearchResults);
        }

        [Test]
        public void StopWords()
        {
            Assert.IsNotNull(Resources.StopWords);
            Assert.IsNotEmpty(Resources.StopWords);
        }

        [Test]
        public void UserViewColumnEmail()
        {
            Assert.IsNotNull(Resources.UserViewColumnEmail);
            Assert.IsNotEmpty(Resources.UserViewColumnEmail);
        }

        [Test]
        public void UserViewColumnLastLogin()
        {
            Assert.IsNotNull(Resources.UserViewColumnLastLogin);
            Assert.IsNotEmpty(Resources.UserViewColumnLastLogin);
        }

        [Test]
        public void UserViewColumnName()
        {
            Assert.IsNotNull(Resources.UserViewColumnName);
            Assert.IsNotEmpty(Resources.UserViewColumnName);
        }

        [Test]
        public void UserViewCreatePasswordHeader()
        {
            Assert.IsNotNull(Resources.UserViewCreateUserHeader);
            Assert.IsNotEmpty(Resources.UserViewCreateUserHeader);
        }

        [Test]
        public void UserViewNewUserConfirmPassword()
        {
            Assert.IsNotNull(Resources.UserViewNewUserConfirmPassword);
            Assert.IsNotEmpty(Resources.UserViewNewUserConfirmPassword);
        }

        [Test]
        public void UserViewNewUserEmail()
        {
            Assert.IsNotNull(Resources.UsersViewNewUserEmail);
            Assert.IsNotEmpty(Resources.UsersViewNewUserEmail);
        }

        [Test]
        public void UserViewNewUserName()
        {
            Assert.IsNotNull(Resources.UsersViewNewUserName);
            Assert.IsNotEmpty(Resources.UsersViewNewUserName);
        }

        [Test]
        public void UserViewNewUserPassword()
        {
            Assert.IsNotNull(Resources.UsersViewNewUserPassword);
            Assert.IsNotEmpty(Resources.UsersViewNewUserPassword);
        }

        [Test]
        public void UserViewNewUserSubmit()
        {
            Assert.IsNotNull(Resources.UsersViewNewUserSubmit);
            Assert.IsNotEmpty(Resources.UsersViewNewUserSubmit);
        }

        [Test]
        public void UsersViewColumnRole()
        {
            Assert.IsNotNull(Resources.UsersViewColumnRole);
            Assert.IsNotEmpty(Resources.UsersViewColumnRole);
        }
    }
}