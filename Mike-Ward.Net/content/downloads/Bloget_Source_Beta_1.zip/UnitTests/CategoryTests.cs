// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.IO;
using System.Text;
using System.Diagnostics.CodeAnalysis;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class CategoryTests
    {
        Blog blog;

        [SetUp]
        public void CreateBlog()
        {
            blog = new Blog();
            blog.DataContext = Path.Combine(Path.GetTempPath(), "UnitTest.xml");

            if (File.Exists(blog.DataContext))
            {
                File.Delete(blog.DataContext);
            }

            using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(Properties.Resources.BlogetML)))
            {
                ImportBlog.Import(blog, stream);
            }

            blog = Blog.Load(blog.DataContext);
        }

        [TearDown]
        public void DeleteBlogFile()
        {
            if (blog != null && File.Exists(blog.DataContext))
            {
                File.Delete(blog.DataContext);
            }

            blog = null;
        }

        [Test]
        public void AddCategory()
        {
            Category category = blog.Categories.CreateCategory("My Favorite Category");
            Assert.IsNotNull(blog.Categories.GetCategoryByName(category.Name));
            Assert.IsNull(blog.Categories.GetCategoryByName(category.Name + "2"));
        }

        [Test]
        public void MergeCategory()
        {
            Category to = blog.Categories.GetCategoryByName("Bloget");
            Category from = blog.Categories.GetCategoryByName("Browsers");

            blog.Categories.Merge(blog, to, from);

            Assert.IsNull(blog.Categories.GetCategoryByName("Browsers"));
            Assert.IsNotNull(blog.Categories.GetCategoryByName("Bloget"));
        }

        [Test]
        public void Deleted()
        {
            Assert.IsFalse(blog.Categories[0].Deleted);
            blog.Categories[0].Deleted = true;
            Assert.IsTrue(blog.Categories[0].Deleted);
        }
    }
}
