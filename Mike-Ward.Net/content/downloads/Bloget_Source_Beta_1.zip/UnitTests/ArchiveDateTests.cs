﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class ArchiveDateTests
    {
        [Test]
        public void ArchiveDateConstructor()
        {
            DateTime now = DateTime.UtcNow;
            const int count = 20;
            ArchiveDate archiveDate = new ArchiveDate(now, count);
            Assert.AreEqual(now, archiveDate.Date);
            Assert.AreEqual(count, archiveDate.Count);
        }

        [Test]
        public void ArchiveDateComparisons()
        {
            ArchiveDate a = new ArchiveDate(DateTime.UtcNow, 100);
            ArchiveDate b = new ArchiveDate(DateTime.UtcNow + TimeSpan.FromDays(1), 100);
            Assert.IsTrue(a.GetHashCode() != b.GetHashCode());
            Assert.AreNotEqual(a, b);
            Assert.IsFalse(a == b);
            Assert.IsTrue(a != b);
            Assert.IsFalse(a > b);
            Assert.IsTrue(a < b);
        }

        [Test]
        public void ArhiveDateCollection()
        {
            ArchiveDate a = new ArchiveDate(DateTime.UtcNow, 100);
            ArchiveDate b = new ArchiveDate(DateTime.UtcNow + TimeSpan.FromDays(1), 100);
            ArchiveDateCollection dates = new ArchiveDateCollection();
            dates.Add(a);
            dates.Add(b);
            Assert.AreEqual(2, dates.Count);
            Assert.IsTrue(a == dates[a.Date]);
            Assert.IsTrue(b == dates[b.Date]);
            Assert.AreSame(a, dates[a.Date]);
            Assert.AreSame(b, dates[b.Date]);
        }
    }
}
