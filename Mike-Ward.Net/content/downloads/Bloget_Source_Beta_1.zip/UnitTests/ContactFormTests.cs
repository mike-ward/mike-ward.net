﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.Diagnostics.CodeAnalysis;
using BlueOnionSoftware.Bloget;
using NUnit.Extensions.Asp;
using NUnit.Extensions.Asp.AspTester;
using NUnit.Framework;

namespace BlogetTests
{
    [TestFixture]
    [Category("ASP")]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class ContactFormTests : WebFormTestCase
    {
        readonly string testPage = Program.Host + "BlogetExamples/ContactForm.aspx";
        UserControlTester userControl;
        TextBoxTester name;
        TextBoxTester email;
        TextBoxTester message;
        ButtonTester submit;

        LabelTester nameLabel;
        LabelTester emailLabel;
        LabelTester messageLabel;

        const string controlId = "bloget2";

        protected override void SetUp()
        {
            const string label = "label";

            Browser.GetPage(testPage);
            
            userControl = new UserControlTester(controlId, CurrentWebForm);
            name = new TextBoxTester("name", userControl);
            email = new TextBoxTester("email", userControl);
            message = new TextBoxTester("message", userControl);
            submit = new ButtonTester("submit", userControl);

            nameLabel = new LabelTester(label + name.AspId, userControl);
            emailLabel = new LabelTester(label + email.AspId, userControl);
            messageLabel = new LabelTester(label + message.AspId, userControl);
        }

        [Test]
        public void TestLayout()
        {
            Assert.AreEqual(testPage, Browser.CurrentUrl.ToString());

            WebAssert.Visible(name);
            WebAssert.Visible(email);
            WebAssert.Visible(message);
            WebAssert.Visible(submit);

            WebAssert.Visible(nameLabel);
            WebAssert.Visible(emailLabel);
            WebAssert.Visible(messageLabel);
        }
    }
}
