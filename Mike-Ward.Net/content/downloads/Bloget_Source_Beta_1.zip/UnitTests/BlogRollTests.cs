// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.IO;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [Category("ASP")]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class BlogRollTests
    {
        [Test]
        public void ReadLocalOpml()
        {
            string tempPath = Path.GetTempFileName();
            File.WriteAllBytes(tempPath, Properties.Resources.BlogRoll);
            Opml blogRoll = BlogetBlogRoll.GetOpml(new Uri("file://" + tempPath));
            File.Delete(tempPath);
            Assert.IsNotNull(blogRoll);
            Assert.AreEqual("Bloglines Subscriptions", blogRoll.Title);
            Assert.AreEqual("blueonionsoftware", blogRoll.OwnerName);
            Assert.AreEqual(new DateTime(2007, 3, 27, 22, 42, 46, DateTimeKind.Utc), blogRoll.DateCreated.ToUniversalTime());
            Assert.AreEqual(72, blogRoll.Outlines.Count);
            Assert.AreEqual(".NET slave", blogRoll.Outlines[0].Title);
            Assert.AreEqual(".NET slave", blogRoll.Outlines[0].Text);
            Assert.AreEqual("http://www.madskristensen.dk/blog/", blogRoll.Outlines[0].HtmlUrl.ToString());
            Assert.AreEqual("http://feeds.feedburner.com/netslave", blogRoll.Outlines[0].XmlUrl.ToString());
            Assert.AreEqual("rss", blogRoll.Outlines[0].Type);
        }

        [Test]
        public void ReadRemoteOpml()
        {
            Opml blogRoll = BlogetBlogRoll.GetOpml(new Uri("http://www.bloglines.com/export?id=blueonionsoftware"), 15000);
            Assert.IsNotNull(blogRoll);
            Assert.AreEqual("Bloglines Subscriptions", blogRoll.Title);
            Assert.AreEqual("blueonionsoftware", blogRoll.OwnerName);
        }
    }
}
