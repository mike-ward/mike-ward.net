// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.IO;
using System.Text;
using NUnit.Framework;
using BlueOnionSoftware.Bloget;
using System.Diagnostics.CodeAnalysis;

namespace BlogetTests
{
    [TestFixture]
    [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
    public class PingBackTests
    {
        [Test]
        public void DoPingBackRequest()
        {
            using (MemoryStream memoryStream = new MemoryStream())
            {
                PingBackClient.PingBackRequest(memoryStream, new Uri("http://localhost/source"), new Uri("http://localhost/target"));
                memoryStream.Flush();
                string result = Encoding.UTF8.GetString(memoryStream.ToArray());
                result = result.Substring(1); // Remove BOM
                XmlRpcMethodCall methodCall = MetaWeblogTests.ParseMethodCall(result);
                Assert.AreEqual("pingback.ping", methodCall.Name); 
            }
        }
    }
}
