﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System;
using System.Web.UI;
using System.Resources;
using System.Security;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Bloget")]
[assembly: AssemblyDescription("An ASP.NET Blogging Control")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Blue Onion Software")]
[assembly: AssemblyProduct("Bloget")]
[assembly: AssemblyCopyright("Copyright © Blue Onion Software 2006-2007")]
[assembly: AssemblyTrademark("Bloget is a trademark of Blue Onion Software")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguageAttribute("en-US")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: AllowPartiallyTrustedCallers]
[assembly: InternalsVisibleTo("UnitTests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c74d2198290c55a845953455b48bf0ffe97560c413549c89724e4bf711ed64ab871620405a9f5b797d972afd0844c4ba6b80a2cda92c4e1b4d476ecc6039f120f1f4a079a45c807b1e7b987ff69ef22178e98ebfda0f29f02408246eb6809457b9f3f2fc5cbf54f89ff03f2e0aeb46c6c4fae8b52f98e3ce785198779fcfd9de")]
[assembly: InternalsVisibleTo("BlogGenerator, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c74d2198290c55a845953455b48bf0ffe97560c413549c89724e4bf711ed64ab871620405a9f5b797d972afd0844c4ba6b80a2cda92c4e1b4d476ecc6039f120f1f4a079a45c807b1e7b987ff69ef22178e98ebfda0f29f02408246eb6809457b9f3f2fc5cbf54f89ff03f2e0aeb46c6c4fae8b52f98e3ce785198779fcfd9de")]
[assembly: InternalsVisibleTo("UnitTestsMs, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c74d2198290c55a845953455b48bf0ffe97560c413549c89724e4bf711ed64ab871620405a9f5b797d972afd0844c4ba6b80a2cda92c4e1b4d476ecc6039f120f1f4a079a45c807b1e7b987ff69ef22178e98ebfda0f29f02408246eb6809457b9f3f2fc5cbf54f89ff03f2e0aeb46c6c4fae8b52f98e3ce785198779fcfd9de")]

// The following GUID is for the Id of the typelib if this project is exposed to COM
[assembly: GuidAttribute("55198707-CCA3-4142-A8B1-8683BC49ED9C")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("0.9.0.0")]
[assembly: AssemblyFileVersion("0.9.0.0")]

// OpenWysiwyg Resources
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.wysiwyg.js", "text/javascript", PerformSubstitution=true)]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.styles.styles.css", "text/css", PerformSubstitution = true)]

[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.popups.about.html", "text/html", PerformSubstitution = true)]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.popups.about_license.html", "text/html", PerformSubstitution = true)]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.popups.create_table.html", "text/html", PerformSubstitution = true)]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.popups.insert_hyperlink.html", "text/html")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.popups.insert_image.html", "text/html")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.popups.license.html", "text/html")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.popups.select_color.html", "text/html")]

[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.backcolor.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.backcolor_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.background_silver.jpg", "image/jpg")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.bold.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.bold_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.copy.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.copy_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.cut.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.cut_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.forecolor.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.forecolor_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.help.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.help_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.indent_left.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.indent_left_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.indent_right.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.indent_right_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.insert_hyperlink.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.insert_hyperlink_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.insert_picture.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.insert_picture_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.insert_table.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.insert_table_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.italics.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.italics_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.justify_center.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.justify_center_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.justify_left.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.justify_left_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.justify_right.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.justify_right_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.list_ordered.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.list_ordered_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.list_unordered.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.list_unordered_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.logo.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.paste.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.paste_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.redo.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.redo_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.select_font.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.select_font_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.select_size.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.select_size_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.seperator.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.seperator2.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.strikethrough.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.strikethrough_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.subscript.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.subscript_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.superscript.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.superscript_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.underline.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.underline_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.undo.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.undo_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.view_source.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.view_source_on.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.view_text.gif", "image/gif")]
[assembly: WebResource("BlueOnionSoftware.Bloget.Resources.Openwysiwyg.icons.view_text_on.gif", "image/gif")]
