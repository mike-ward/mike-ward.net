// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Text;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace BlueOnionSoftware.Bloget
{
    internal class BlogView : View
    {
        bool disposed;
        readonly TextBox commentName = new TextBox();
        readonly TextBox commentEmail = new TextBox();
        readonly TextBox commentTitle = new TextBox();
        readonly TextBox commentText = new TextBox();

        const string commentThrottle = "bloget_commentThrottle";

        internal BlogView(BlogetBlog blogetBlog)
            : base(blogetBlog)
        {
            commentName.ID = "commentName";
            commentEmail.ID = "commentEmail";
            commentTitle.ID = "commentTitle";
            commentText.ID = "commentText";

            if (bloget.Page.Header != null && bloget.Blog.EnableRealSimpleDiscovery)
            {
                HtmlLink link = new HtmlLink();
                link.Attributes.Add("rel", "EditURI");
                link.Attributes.Add("type", "application/rsd+xml");
                link.Attributes.Add("title", "RSD");
                link.Attributes.Add("href", bloget.RpcServiceUrl());
                bloget.Page.Header.Controls.Add(link);
            }
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        commentName.Dispose();
                        commentEmail.Dispose();
                        commentTitle.Dispose();
                        commentText.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }

        protected override string RootClassId()
        {
            return "blog-view";
        }

        protected override void ShowView()
        {
            ShowPostsByCategory();
        }

        private void ShowPostsByCategory()
        {
            int start = bloget.QueryStart;
            Category category = bloget.QueryCategory;

            ShowHeader(bloget);

            // Ask for one more than we need. If we get it, we're not at the end of the list.
            int count = bloget.Blog.PostsPerPage + 1;

            foreach (Post post in bloget.Blog.EnumeratePosts(start, count, category, false, false))
            {
                if (--count == 0)
                {
                    break;
                }

                ShowPost(post);
                ShowPostSeparator(post);
            }

            // Previous/Next Navigators
            string previousLink = string.Empty;

            if (start > 0)
            {
                int previousStart = Math.Max(start - bloget.Blog.PostsPerPage, 0);
                previousLink = bloget.BuildQueryString(Mode.Blog, null, previousStart, category, null, DateTime.MinValue, null);
            }

            string nextLink = string.Empty;

            if (count == 0)
            {
                int nextStart = Math.Min(start + bloget.Blog.PostsPerPage, bloget.Blog.Posts.Count - 1);
                nextLink = bloget.BuildQueryString(Mode.Blog, null, nextStart, category, null, DateTime.MinValue, null);
            }

            ShowNavigators(bloget, previousLink, nextLink);
            ShowFooter(bloget);
            bloget.PoweredByBloget();
        }

        internal void ShowPostsByMonth()
        {
            int start = bloget.QueryStart;
            DateTime monthYear = bloget.QueryDate;

            ShowHeader(bloget);

            // Ask for one more than we need. If we get it, we're not at the end of the list.
            int count = bloget.Blog.PostsPerPage + 1;

            foreach (Post post in bloget.Blog.EnumeratePostsByMonth(start, count, monthYear))
            {
                if (--count == 0)
                {
                    break;
                }

                ShowPost(post);
                ShowPostSeparator(post);
            }

            string previousLink = string.Empty;

            if (start > 0)
            {
                int previousStart = Math.Max(start - bloget.Blog.PostsPerPage, 0);
                previousLink = bloget.BuildQueryString(Mode.Blog, null, previousStart, null, null, monthYear, null);
            }

            string nextLink = string.Empty;

            if (count == 0)
            {
                int nextStart = Math.Min(start + bloget.Blog.PostsPerPage, bloget.Blog.Posts.Count - 1);
                nextLink = bloget.BuildQueryString(Mode.Blog, null, nextStart, null, null, monthYear, null);
            }

            ShowNavigators(bloget, previousLink, nextLink);
            ShowFooter(bloget);
            bloget.PoweredByBloget();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        internal void ShowPost()
        {
            if (bloget.Blog.EnableAutoPingBack)
            {
                bloget.Page.Response.AddHeader("X-Pingback", bloget.RpcServiceUrl());
            }

            Post post;
            string postId = bloget.QueryPost;

            if (string.IsNullOrEmpty(postId) == false)
            {
                try
                {
                    Guid id = new Guid(postId);
                    post = bloget.Blog.Posts[id];
                }

                catch (Exception)
                {
                    bloget.WriteLine("<p>Identifier \"" + postId + "\" invalid</p>");
                    return;
                }
            }

            else
            {
                bloget.WriteLine("<p>Missing post identifier</p>");
                return;
            }

            bloget.Page.Title += " - " + post.Title;

            ShowHeader(bloget);
            ShowPostNavigators(post);
            ShowPost(post);
            ShowPostSeparator(post);
            ShowCommentHeader(post);
            ShowComments(post);
            ShowPingBackHeader(post);
            ShowPingBacks(post);
            ShowCommentRequest(post);
            ShowFooter(bloget);

            bloget.PoweredByBloget();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private void AddCommentClick(object sender, EventArgs ea)
        {
            if (bloget.Page.IsValid == false)
            {
                return;
            }

            if (bloget.Blog.AllowComments == false)
            {
                return;
            }

            if (bloget.Page.Session[commentThrottle] != null)
            {
                DateTime throttle = (DateTime)bloget.Page.Session[commentThrottle];
                TimeSpan elapsed = DateTime.Now - throttle;

                if (elapsed.TotalSeconds < 30)
                {
                    return;
                }
            }

            Guid id = new Guid(bloget.Page.Request[bloget.BlogPostParameter]);
            Post post = bloget.Blog.Posts[id];
            Comment comment = new Comment();

            comment.Title = bloget.Page.Server.HtmlEncode(commentTitle.Text);
            comment.Author = bloget.Page.Server.HtmlEncode(commentName.Text);
            comment.Email = bloget.Page.Server.HtmlEncode(commentEmail.Text);
            comment.Text = bloget.Page.Server.HtmlEncode(commentText.Text);

            Content content = bloget.Blog.LoadContent(id);
            content = new Content(content); // Clone to protect readers

            if (content.Comments.Count < bloget.Blog.MaximumCommentsPerPost)
            {
                bool verified = comment.VerifyComment();

                if (verified)
                {
                    content.Comments.Add(comment);
                    bloget.Blog.SaveContent(post.Id, content);
                    Log.NewComment(bloget, post.Title, comment.Id);
                }

                else
                {
                    Log.RejectComment(bloget, post.Title, comment.Text);
                }

                try
                {
                    if (bloget.Blog.EmailComments)
                    {
                        string subject = string.Format(CultureInfo.CurrentCulture,
                            "Bloget Comment Alert - Posting {0} {1}", id, post.Title);

                        string status = verified ? "Posted" : "***** Not Posted (possible spam detected) *****";

                        string message = string.Format(CultureInfo.CurrentCulture,
                            "Blog: {0}{5}Title: {1}{5}Link: {2}{5}Status: {3}{5}{5}---------{5}{5}{4}",
                            bloget.Blog.Title, post.Title, bloget.Page.Request.Url, status, comment, Environment.NewLine);

                        bloget.SendEmail(bloget.Blog.EmailTo, subject, message);
                    }
                }

                catch (Exception ex)
                {
                    Log.Exception(bloget, "AddCommentClick", ex);
                }

                bloget.Page.Session[commentThrottle] = DateTime.Now;
                bloget.Redirect(bloget.Page.Request.RawUrl);
            }
        }

        static internal void ShowHeader(Bloget bloget)
        {
            if (bloget.TitleTemplate != null)
            {
                BlogContainerControl blogContainer = new BlogContainerControl(bloget, bloget.Blog);
                bloget.TitleTemplate.InstantiateIn(blogContainer);
                bloget.Controls.Add(blogContainer);
            }
        }

        static private void ShowNavigators(Bloget bloget, string previousLink, string nextLink)
        {
            // Previous/Next Navigators
            HyperLink previousHyperLink = new HyperLink();
            previousHyperLink.Text = "previous";
            previousHyperLink.NavigateUrl = previousLink;
            previousHyperLink.Enabled = !string.IsNullOrEmpty(previousLink);

            HyperLink nextHyperLink = new HyperLink();
            nextHyperLink.Text = "next";
            nextHyperLink.NavigateUrl = nextLink;
            nextHyperLink.Enabled = !string.IsNullOrEmpty(nextLink);

            bloget.WriteLine("<p>");
            bloget.Controls.Add(previousHyperLink);
            bloget.Write(" | ");
            bloget.Controls.Add(nextHyperLink);
            bloget.WriteLine("</p>");
        }

        static internal void ShowFooter(Bloget bloget)
        {
            if (bloget.FooterTemplate != null)
            {
                BlogContainerControl blogContainer = new BlogContainerControl(bloget, bloget.Blog);
                blogContainer.EnableViewState = false;
                bloget.FooterTemplate.InstantiateIn(blogContainer);
                bloget.Controls.Add(blogContainer);
            }
        }

        private void ShowPostNavigators(Post post)
        {
            bloget.WriteLine("<p style=\"text-align:center\">&laquo;&nbsp;");

            Post previousPost = bloget.Blog.Posts.Previous(post.Id);

            if (previousPost != null)
            {
                HyperLink link = new HyperLink();
                link.Text = Elipsis(previousPost.Title);
                link.NavigateUrl = bloget.BuildQueryString(Mode.Post, previousPost, 0, null, null, DateTime.MinValue, null);
                link.Attributes.Add("rel", "nofollow");
                bloget.Controls.Add(link);
            }

            bloget.WriteLine(" | ");

            Post nextPost = bloget.Blog.Posts.Next(post.Id);

            if (nextPost != null)
            {
                HyperLink link = new HyperLink();
                link.Text = Elipsis(nextPost.Title);
                link.NavigateUrl = bloget.BuildQueryString(Mode.Post, nextPost, 0, null, null, DateTime.MinValue, null);
                link.Attributes.Add("rel", "nofollow");
                bloget.Controls.Add(link);
            }

            bloget.WriteLine("&nbsp;&raquo;</p>");
        }

        private void ShowPost(Post post)
        {
            Content content = bloget.Blog.LoadContent(post.Id);

            if (bloget.PostTemplate != null)
            {
                PostContainerControl postContainer = new PostContainerControl(bloget, bloget.Blog, post, content);
                bloget.PostTemplate.InstantiateIn(postContainer);
                bloget.Controls.Add(postContainer);
            }

            else
            {
                bloget.WriteLine(@"<div class=""post"">");
                bloget.WriteLine(@"<h3 class=""post-title"">");
                HyperLink link = new HyperLink();
                link.NavigateUrl = bloget.BuildQueryString(Mode.Post, post, 0, null, null, DateTime.MinValue, null);
                link.Text = post.Title;
                bloget.Controls.Add(link);
                bloget.WriteLine("</h3>");

                if (string.IsNullOrEmpty(post.Author) == false)
                {
                    bloget.WriteLine(@"<span class=""post-author"">by " + 
                        bloget.Page.Server.HtmlEncode(post.Author) + 
                        "</span><br/>");
                }

                bloget.WriteLine(@"<span class=""post-date"">");
                DateTime created = Time.LocalTime(bloget.Blog.TimeZone, post.Created);
                bloget.WriteLine(created.ToString("D", CultureInfo.CurrentCulture) + "</span><br/>");
                bool firstTag = true;

                foreach (int tagInt in post.Tags)
                {
                    if (bloget.Blog.Categories.Contains(tagInt))
                    {
                        bloget.WriteLine(firstTag ? "<span>" : ", ");
                        firstTag = false;

                        Category category = bloget.Blog.Categories[tagInt];
                        HyperLink hyperLink = new HyperLink();

                        hyperLink.NavigateUrl =
                            bloget.BuildQueryString(Mode.Blog, null, 0, category, null, DateTime.MinValue, null);

                        hyperLink.Text = category.Name;
                        bloget.Controls.Add(hyperLink);
                    }
                }

                if (firstTag == false)
                {
                    bloget.WriteLine("</span><br/>");
                }

                bloget.WriteLine("<br/>");
                bloget.WriteLine(@"<div class=""post-content"">");
                bloget.WriteLine(content.Text);
                bloget.WriteLine(@"</div><div class=""post-footer"">");

                if (bloget.IsLoggedIn)
                {
                    HyperLink editLink = new HyperLink();
                    editLink.NavigateUrl = bloget.BuildQueryString(Mode.Edit, post, 0, null, null, DateTime.MinValue, null);
                    editLink.Attributes.Add("rel", "nofollow");
                    editLink.Text = "edit";
                    bloget.Controls.Add(editLink);
                    bloget.WriteLine("&nbsp;|&nbsp;");
                }

                HyperLink commentsLink = new HyperLink();
                commentsLink.NavigateUrl = bloget.BuildQueryString(Mode.Post, post, 0, null, null, DateTime.MinValue, null);
                commentsLink.Attributes.Add("rel", "nofollow");
                commentsLink.Text = string.Format(CultureInfo.CurrentCulture, "comments ({0})", content.Comments.Count);
                bloget.Controls.Add(commentsLink);

                if (content.Attachments.Count > 0)
                {
                    bloget.WriteLine("<br />");
                    HyperLink enclosureLink = new HyperLink();
                    Attachment enclosure = content.Attachments[0];
                    enclosureLink.NavigateUrl = enclosure.Url;
                    enclosureLink.Text = enclosure.ToString();
                    bloget.Controls.Add(enclosureLink);
                }

                HyperLink[] relatedLinks = bloget.RelatedPosts(post, 3);

                if (relatedLinks.Length > 0)
                {
                    bloget.WriteLine("<p class=\"post-related\"><span>Related:</span></p><ul>");

                    foreach (HyperLink related in relatedLinks)
                    {
                        bloget.Write("<li>");
                        bloget.Controls.Add(related);
                        bloget.WriteLine("</li>");
                    }

                    bloget.WriteLine("</ul>");
                }
                bloget.WriteLine("</div></div>");
            }
        }

        private void ShowPostSeparator(Post post)
        {
            if (bloget.PostSeparatorTemplate != null)
            {
                Content content = bloget.Blog.LoadContent(post.Id);
                PostContainerControl postContainer = new PostContainerControl(bloget, bloget.Blog, post, content);
                postContainer.EnableViewState = false;
                bloget.PostSeparatorTemplate.InstantiateIn(postContainer);
                bloget.Controls.Add(postContainer);
            }

            else
            {
                bloget.WriteLine("<hr/>");
            }
        }

        private void ShowCommentHeader(Post post)
        {
            Content content = bloget.Blog.LoadContent(post.Id);

            if (content.Comments.Count > 0)
            {
                if (bloget.CommentHeaderTemplate != null)
                {
                    PostContainerControl postContainer = new PostContainerControl(bloget, bloget.Blog, post, content);
                    postContainer.EnableViewState = false;
                    bloget.CommentHeaderTemplate.InstantiateIn(postContainer);
                    bloget.Controls.Add(postContainer);
                }

                else
                {
                    bloget.WriteLine("<p style=\"font-size:large; font-weight:bold\">Comments</p>");
                }
            }
        }

        private void ShowComments(Post post)
        {
            Content content = bloget.Blog.LoadContent(post.Id);

            foreach (Comment comment in content.Comments)
            {
                if (bloget.CommentTemplate != null)
                {
                    CommentContainerControl commentContainer = new CommentContainerControl(bloget, bloget.Blog, post, content, comment);
                    commentContainer.EnableViewState = false;
                    bloget.CommentTemplate.InstantiateIn(commentContainer);
                    bloget.Controls.Add(commentContainer);
                }

                else
                {
                    bloget.WriteLine("<p><b>" + comment.Title + "</b><br/>");
                    bloget.WriteLine("by " + comment.Author + "<br/>");
                    DateTime created = Time.LocalTime(bloget.Blog.TimeZone, comment.Date);
                    bloget.WriteLine(created.ToString("f", CultureInfo.CurrentCulture));
                    bloget.WriteLine("</p>");
                    bloget.WriteLine("<div>");
                    bloget.WriteLine(CommentToHtml(comment.Text));
                    bloget.WriteLine("</div>");
                    bloget.WriteLine("<hr/>");
                }

                if (bloget.IsLoggedIn)
                {
                    bloget.WriteLine("<p>");
                    ConfirmedButton remove = new ConfirmedButton();
                    remove.ID = "C" + comment.Id;
                    remove.Text = "Delete";
                    remove.Style.Add(HtmlTextWriterStyle.Color, "red");
                    remove.Message = "Remove this comment permanently?";
                    remove.Click += RemoveCommentClick;
                    bloget.Controls.Add(remove);
                    bloget.WriteLine("</p>");
                }
            }
        }

        private void ShowPingBackHeader(Post post)
        {
            Content content = bloget.Blog.LoadContent(post.Id);

            if (content.References.Count == 0)
            {
                return;
            }

            if (bloget.PingBackHeaderTemplate != null)
            {
                PostContainerControl postContainer = new PostContainerControl(bloget, bloget.Blog, post, content);
                postContainer.EnableViewState = false;
                bloget.PingBackHeaderTemplate.InstantiateIn(postContainer);
                bloget.Controls.Add(postContainer);
            }

            else
            {
                bloget.WriteLine("<p style=\"font-size:large; font-weight:bold\">Pingbacks</p>");
            }
        }

        private void ShowPingBacks(Post post)
        {
            Content content = bloget.Blog.LoadContent(post.Id);

            if (content.References.Count <= 0)
            {
                return;
            }

            foreach (Reference pingBack in content.References)
            {
                if (bloget.PingBackTemplate != null)
                {
                    PingBackContainerControl pingBackContainer = new PingBackContainerControl(bloget, bloget.Blog, post, content, pingBack);
                    pingBackContainer.EnableViewState = false;
                    bloget.PingBackTemplate.InstantiateIn(pingBackContainer);
                    bloget.Controls.Add(pingBackContainer);
                }

                else
                {
                    bloget.WriteLine("<p>");
                    DateTime created = Time.LocalTime(bloget.Blog.TimeZone, pingBack.Date);
                    bloget.WriteLine(created.ToString("f", CultureInfo.CurrentCulture));
                    bloget.Write("&nbsp;&nbsp;");
                    HyperLink link = new HyperLink();
                    link.NavigateUrl = pingBack.Link;
                    link.Text = pingBack.Link;
                    bloget.Controls.Add(link);
                    bloget.WriteLine("</p>");
                }

                if (bloget.IsLoggedIn)
                {
                    bloget.WriteLine("<p>");
                    ConfirmedButton remove = new ConfirmedButton();
                    remove.ID = "P" + pingBack.Id;
                    remove.Text = "Delete";
                    remove.Style.Add(HtmlTextWriterStyle.Color, "red");
                    remove.Message = "Remove this pingback permanently?";
                    remove.Click += RemovePingBackClick;
                    bloget.Controls.Add(remove);
                    bloget.WriteLine("</p>");
                }
            }

            bloget.WriteLine("<hr/>");
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private void RemoveCommentClick(object sender, EventArgs ea)
        {
            ConfirmedButton button = sender as ConfirmedButton;

            if (button != null)
            {
                try
                {
                    Guid commentId = new Guid(button.ID.Substring(1));

                    if (string.IsNullOrEmpty(bloget.QueryPost) == false)
                    {
                        Guid id = new Guid(bloget.QueryPost);
                        Post post = bloget.Blog.Posts[id];
                        Content content = bloget.Blog.LoadContent(id);
                        content = new Content(content); // Clone to protect readers

                        if (content.Comments.Contains(commentId))
                        {
                            content.Comments.Remove(commentId);
                            bloget.Blog.SaveContent(id, content);
                            Log.RemoveComment(bloget, post.Title, commentId);
                        }
                    }
                }

                catch (Exception ex)
                {
                    bloget.ErrorPage(ex.ToString());
                    return;
                }

                bloget.Redirect(bloget.Page.Request.RawUrl);
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private void RemovePingBackClick(object sender, EventArgs ea)
        {
            ConfirmedButton button = sender as ConfirmedButton;

            if (button != null)
            {
                try
                {
                    Guid pingBackId = new Guid(button.ID.Substring(1));

                    if (string.IsNullOrEmpty(bloget.QueryPost) == false)
                    {
                        Guid id = new Guid(bloget.QueryPost);
                        Content content = bloget.Blog.LoadContent(id);
                        content = new Content(content); // Clone to protect readers

                        if (content.References.Contains(pingBackId))
                        {
                            content.References.Remove(pingBackId);
                            bloget.Blog.SaveContent(id, content);
                            Log.RemovePingBack(bloget, id, pingBackId);
                        }
                    }
                }

                catch (Exception ex)
                {
                    bloget.ErrorPage(ex.ToString());
                    return;
                }

                bloget.Redirect(bloget.Page.Request.RawUrl);
            }
        }

        private void ShowCommentRequest(Post post)
        {
            if (bloget.Blog.AllowComments && post.EnableComments)
            {
                Content content = bloget.Blog.LoadContent(post.Id);

                if (bloget.Blog.ExpireComments > 0 && content.LastUpdate.AddDays(bloget.Blog.ExpireComments) < DateTime.UtcNow)
                {
                    return;
                }

                if (content.Comments.Count >= bloget.Blog.MaximumCommentsPerPost)
                {
                    return;
                }

                bloget.WriteLine("<p><strong>Leave a Comment</strong></p>");
                InputField("Title", commentTitle, "RE: " + post.Title, "The title of your comment", true, null);
                InputField("Name", commentName, string.Empty, "Your real name please", true, null);
                InputField("Email", commentEmail, string.Empty, "Email is not shown", true, AdminView.EmailValidator());

                bloget.WriteLine("<p>Comments:");
                RequiredFieldValidator rfv = new RequiredFieldValidator();
                rfv.ControlToValidate = commentText.ID;
                rfv.EnableClientScript = false;
                rfv.Text = " *";
                bloget.Controls.Add(rfv);
                bloget.WriteLine("<br/>");

                commentText.Style.Add(HtmlTextWriterStyle.Width, "90%");
                commentText.MaxLength = 0x100000;
                commentText.Wrap = true;
                commentText.Rows = 12;
                commentText.TextMode = TextBoxMode.MultiLine;
                bloget.Controls.Add(commentText);
                bloget.WriteLine("</p>");

                ConfirmedButton submit = new ConfirmedButton();
                submit.Text = "Add Comment";
                submit.Click += AddCommentClick;
                submit.Message = "Add Comment?";
                bloget.Controls.Add(submit);
            }

            else
            {
                bloget.WriteLine("<p>Comments disabled</p>");
            }
        }

        internal static string CommentToHtml(string comment)
        {
            string[] delimiters = new string[] { "\n\n" };
            string[] strings = comment.Split(delimiters, StringSplitOptions.None);
            StringBuilder builder = new StringBuilder();

            foreach (string s in strings)
            {
                builder.Append("<p>");
                builder.Append(s);
                builder.Append("</p>");
            }

            string result = builder.ToString();
            return result.Replace("\n", "<br/>");
        }

        private static string Elipsis(string source)
        {
            if (source.Length < 25)
            {
                return source;
            }

            return string.Format(CultureInfo.CurrentCulture, "{0}...", source.Substring(0, 25));
        }

        void InputField(string textLabel,
                        TextBox textBox,
                        string text,
                        string tooltip,
                        bool required,
                        BaseValidator validator)
        {
            textBox.TextMode = TextBoxMode.SingleLine;
            textBox.MaxLength = 100;
            textBox.Style.Add(HtmlTextWriterStyle.Width, "25em");
            Input(textLabel, textBox, text, tooltip, required, validator);
        }

        void Input(string textLabel,
                   TextBox textBox,
                   string text,
                   string tooltip,
                   bool required,
                   BaseValidator validator)
        {
            Label(textLabel, textBox.ID);
            textBox.Text = text ?? string.Empty;
            textBox.ToolTip = tooltip ?? string.Empty;
            bloget.Controls.Add(textBox);

            if (required)
            {
                RequiredFieldValidator rfv = new RequiredFieldValidator();
                rfv.ControlToValidate = textBox.ID;
                rfv.EnableClientScript = false;
                rfv.Text = " *";
                bloget.Controls.Add(rfv);
            }

            if (validator != null)
            {
                validator.ControlToValidate = textBox.ID;
                bloget.Controls.Add(validator);
            }

            bloget.WriteLine("<br />");
        }
    }
}
