// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BlueOnionSoftware.Bloget
{
    class EditView : View
    {
        readonly TextBox title = new TextBox();
        readonly TextBox text = new TextBox();
        readonly CheckBox draft = new CheckBox();
        readonly CheckBox syndicate = new CheckBox();
        readonly CheckBox enableComments = new CheckBox();
        readonly FileUpload imageUpload = new FileUpload();
        readonly FileUpload fileUpload = new FileUpload();
        readonly FileUpload enclosureUpload = new FileUpload();
        readonly CheckBox enclosureName = new CheckBox();
        readonly TextBox newCategory = new TextBox();
        readonly CheckBoxList categoryList = new CheckBoxList();

        bool disposed;
        const int maxPasswordLength = 30;
        const int maxTextBoxLength = 200;

        enum PostType
        {
            None,
            NewPost,
            EditPost
        } ;

        internal EditView(Bloget blogetArg)
            : base(blogetArg)
        {
            title.ID = "title";
            text.ID = "text";
            draft.ID = "draft";
            syndicate.ID = "syndicate";
            enableComments.ID = "enableComments";
            imageUpload.ID = "imageUpload";
            fileUpload.ID = "fileUpload";
            enclosureUpload.ID = "enclosureUpload";
            enclosureName.ID = "enclosureName";
            newCategory.ID = "newCategory";
            categoryList.ID = "categoryList";

            if (bloget.Page.Header != null)
            {
                const string wysiwygScript = "BlueOnionSoftware.Bloget.Resources.Openwysiwyg.wysiwyg.js";

                if (bloget.Page.ClientScript.IsClientScriptBlockRegistered(wysiwygScript) == false)
                {
                    // Tip from the code project. Register an empty script to get the benifits of registered
                    // scripts using an empty string. Then add the real script to the header section.
                    bloget.Page.ClientScript.RegisterClientScriptBlock(GetType(), wysiwygScript, string.Empty);

                    bloget.Page.Header.Controls.Add(new LiteralControl(
                                                        string.Format(CultureInfo.InvariantCulture,
                                                        "{0}<script type=\"text/javascript\" src=\"{1}\"></script>{2}",
                                                        Environment.NewLine,
                                                        bloget.Page.ClientScript.GetWebResourceUrl(GetType(), wysiwygScript),
                                                        Environment.NewLine)));
                }
            }
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        title.Dispose();
                        text.Dispose();
                        draft.Dispose();
                        syndicate.Dispose();
                        enableComments.Dispose();
                        imageUpload.Dispose();
                        fileUpload.Dispose();
                        enclosureUpload.Dispose();
                        enclosureName.Dispose();
                        newCategory.Dispose();
                        categoryList.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }

        protected override string RootClassId()
        {
            return "edit-view";
        }

        [SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        protected override void ShowView()
        {
            if (bloget.IsAuthorOrAdministrator == false)
            {
                PasswordView passwordForm = new PasswordView(bloget);
                passwordForm.Show();
                return;
            }

            MainMenu.ShowMenu(bloget);

            const int buttonWidth = 8;
            Post post = new Post();
            Content content = new Content();
            string postID = bloget.QueryPost;

            if (string.IsNullOrEmpty(postID) == false)
            {
                try
                {
                    Guid id = new Guid(postID);
                    post = bloget.Blog.Posts[id];
                    content = bloget.Blog.LoadContent(id);
                }

                catch (Exception)
                {
                    bloget.Write("<p>");

                    bloget.Write(string.Format(CultureInfo.InvariantCulture,
                        Properties.Resources.EditViewInvalidPostParameter,
                        bloget.BlogPostParameter));

                    bloget.WriteLine("</p>");
                    return;
                }
            }

            // Title
            bloget.Write("<p>");
            bloget.Write(Properties.Resources.EditViewTitle);
            RequiredFieldValidator rfv = new RequiredFieldValidator();
            rfv.ControlToValidate = title.ID;
            rfv.Text = " *";
            bloget.Controls.Add(rfv);

            bloget.WriteLine(Environment.NewLine);
            title.Style.Add(HtmlTextWriterStyle.Width, "70%");
            title.Style.Add(HtmlTextWriterStyle.FontWeight, "bold");
            title.MaxLength = maxTextBoxLength;
            title.Text = bloget.Page.Server.HtmlDecode(post.Title);
            bloget.Controls.Add(title);
            bloget.WriteLine("</p>");

            // Textbox
            bloget.WriteLine("<p>");
            text.TextMode = TextBoxMode.MultiLine;
            text.Text = content.Text;
            text.Width = new Unit(99, UnitType.Percentage);
            bloget.Controls.Add(text);

            bloget.WriteLine("<script>generate_wysiwyg2('" + text.ClientID + "'," +
                             bloget.Blog.EditorWidth + "," + bloget.Blog.EditorHeight + ")</script>");

            bloget.WriteLine("</p>");

            bloget.WriteLine("<p>");
            draft.Text = Properties.Resources.EditViewDraft;
            draft.Checked = post.Draft;
            bloget.Controls.Add(draft);

            bloget.WriteLine("&nbsp;");

            // Syndicate checkbox
            syndicate.Text = Properties.Resources.EditViewSyndicate;
            syndicate.Checked = post.Syndicate;
            bloget.Controls.Add(syndicate);

            bloget.WriteLine("&nbsp;");

            // Allow comments checkbox
            enableComments.Text = Properties.Resources.EditAllowCommentsButton;
            enableComments.Checked = post.EnableComments;
            bloget.Controls.Add(enableComments);
            bloget.WriteLine("</p>");

            Table table = new Table();
            TableRow row;
            TableCell cell;
            bloget.Controls.Add(table);

            // Add Image
            row = new TableRow();
            table.Rows.Add(row);
            cell = new TableCell();
            cell.Controls.Add(new LiteralControl(Properties.Resources.EditViewAddImage));
            row.Cells.Add(cell);
            cell = new TableCell();
            cell.Controls.Add(imageUpload);
            row.Cells.Add(cell);
            Button addImage = new Button();
            addImage.Text = "Add Image";
            addImage.Width = new Unit(buttonWidth, UnitType.Em);
            addImage.Click += UploadImageClick;
            cell = new TableCell();
            cell.Controls.Add(addImage);
            row.Cells.Add(cell);

            // Add File
            row = new TableRow();
            table.Rows.Add(row);
            cell = new TableCell();
            cell.Controls.Add(new LiteralControl(Properties.Resources.EditViewAddFile));
            row.Cells.Add(cell);
            cell = new TableCell();
            cell.Controls.Add(fileUpload);
            row.Cells.Add(cell);
            Button uploadFile = new Button();
            uploadFile.Text = "Upload File";
            uploadFile.Width = new Unit(buttonWidth, UnitType.Em);
            uploadFile.Click += UploadFileClick;
            cell = new TableCell();
            cell.Controls.Add(uploadFile);
            row.Cells.Add(cell);

            // Enclosure
            row = new TableRow();
            table.Rows.Add(row);
            cell = new TableCell();
            cell.Controls.Add(new LiteralControl(Properties.Resources.EditViewRssEnclosure));
            cell.Controls.Add(new LiteralControl("&nbsp;"));
            row.Cells.Add(cell);

            cell = new TableCell();

            if (content.Attachments.Count > 0)
            {
                enclosureName.Text = content.Attachments[0].Name;
                enclosureName.Checked = true;
                cell.Controls.Add(enclosureName);
            }

            else
            {
                enclosureName.Visible = false;
            }

            enclosureUpload.Visible = (content.Attachments.Count == 0);
            cell.Controls.Add(enclosureUpload);
            row.Cells.Add(cell);

            // New Category
            row = new TableRow();
            table.Rows.Add(row);
            cell = new TableCell();
            cell.Controls.Add(new LiteralControl(Properties.Resources.EditViewNewCategory));
            cell.Controls.Add(new LiteralControl("&nbsp;"));
            row.Cells.Add(cell);
            newCategory.MaxLength = maxPasswordLength;
            cell = new TableCell();
            cell.Controls.Add(newCategory);
            row.Cells.Add(cell);

            RegularExpressionValidator categoryValidator = new RegularExpressionValidator();
            categoryValidator.ControlToValidate = newCategory.ID;
            const string categoryValidatorExpression = "[a-zA-Z0-9.& ]*";
            categoryValidator.ValidationExpression = categoryValidatorExpression;
            categoryValidator.Text = categoryValidatorExpression;
            cell = new TableCell();
            cell.Controls.Add(categoryValidator);
            row.Cells.Add(cell);

            // Category checkbox list
            if (bloget.Blog.Categories.Count != 0)
            {
                categoryList.RepeatDirection = RepeatDirection.Horizontal;
                categoryList.RepeatColumns = 5;

                foreach (Category category in bloget.Blog.Categories.Sorted())
                {
                    ListItem listItem = new ListItem();
                    listItem.Text = category.Name;
                    listItem.Selected = post.HasCategory(category);
                    listItem.Value = category.Id.ToString(CultureInfo.CurrentCulture);
                    categoryList.Items.Add(listItem);
                }

                bloget.Controls.Add(categoryList);
            }

            // Post button
            bloget.WriteLine("<p>");
            Button submit = new Button();
            submit.Text = "          " + Properties.Resources.EditViewPost + "         ";
            submit.ID = "save";
            submit.Click += SavePostClick;
            // Ensure OpenWysiwyg is in html mode
            submit.OnClientClick = "if (viewTextMode == 1) viewText('" + text.ClientID + "');";
            bloget.Controls.Add(submit);
            bloget.WriteLine(string.Empty);

            bloget.WriteLine("&nbsp;");

            // Cancel button
            ConfirmedButton cancel = new ConfirmedButton();
            cancel.Text = Properties.Resources.EditViewCancel;
            cancel.Style.Add("color", "red");
            cancel.ID = "cancel";
            cancel.Message = Properties.Resources.EditViewConfirmCancel;
            cancel.CausesValidation = false;

            cancel.Click +=
                delegate { bloget.Redirect(bloget.BuildQueryString(Mode.Blog, null, 0, null, null, DateTime.MinValue, null)); };

            bloget.Controls.Add(cancel);
            bloget.WriteLine(string.Empty);

            // Remove button
            if (string.IsNullOrEmpty(postID) == false)
            {
                bloget.WriteLine("&nbsp;");

                ConfirmedButton remove = new ConfirmedButton();
                remove.Text = Properties.Resources.EditViewRemove;
                remove.Style.Add("color", "red");
                remove.Message = Properties.Resources.EditViewConfirmRemove;
                remove.CausesValidation = false;
                remove.Click += RemovePostClick;
                bloget.Controls.Add(remove);
            }

            bloget.WriteLine("</p>");
            bloget.Load += OnLoad;
        }

        void OnLoad(object sender, EventArgs ea)
        {
            if (string.IsNullOrEmpty(bloget.Page.Request[bloget.BlogPostParameter]))
            {
                title.Focus();
            }

            bloget.Load -= OnLoad;
        }

        [SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void SavePostClick(object sender, EventArgs ea)
        {
            if (bloget.Page.IsValid == false)
            {
                return;
            }

            Blog blog = new Blog(bloget.Blog); // copy to protect readers
            Post post = new Post();
            Content content = new Content();
            string postID = bloget.Page.Request[bloget.BlogPostParameter];

            if (string.IsNullOrEmpty(postID) == false)
            {
                try
                {
                    Guid id = new Guid(postID);
                    post = blog.Posts[id];
                    content = blog.LoadContent(id);
                    content = new Content(content); // Clone to protect readers
                }

                catch
                {
                    bloget.WriteLine("<p>Invalid post identifier</p>");
                    return;
                }
            }

            post.Title = bloget.Page.Server.HtmlEncode(title.Text);
            post.Author = bloget.GetUser().UserName;
            content.Text = text.Text;

            // Check for attachment
            if (enclosureUpload != null)
            {
                if (enclosureUpload.HasFile)
                {
                    string path = bloget.Page.MapPath(blog.ImageFolder);
                    path = Path.Combine(path, enclosureUpload.FileName);
                    enclosureUpload.SaveAs(path);

                    Attachment attachment = new Attachment();
                    attachment.Url = blog.ImageFolder + enclosureUpload.FileName;
                    attachment.MimeType = enclosureUpload.PostedFile.ContentType;
                    attachment.Length = enclosureUpload.PostedFile.ContentLength;
                    attachment.AttachmentType = "Enclosure";

                    content.Attachments.Clear(); // allow only one attachment for now
                    content.Attachments.Add(attachment);
                }
            }

            if (enclosureName.Visible && enclosureName.Checked == false)
            {
                content.Attachments.Clear();
            }

            blog.SaveContent(post.Id, content);

            bool wasDraft = post.Draft;
            post.Draft = draft.Checked;

            post.Syndicate = syndicate.Checked;

            post.EnableComments = enableComments.Checked;

            // Check existing categores
            if (categoryList != null)
            {
                foreach (ListItem listItem in categoryList.Items)
                {
                    Category category = bloget.Blog.Categories[int.Parse(listItem.Value, CultureInfo.CurrentCulture)];

                    if (listItem.Selected)
                    {
                        post.AddCategory(category);
                    }

                    else if (post.HasCategory(category))
                    {
                        post.RemoveCategory(category);
                    }
                }
            }

            // Check for new category
            if (string.IsNullOrEmpty(newCategory.Text) == false)
            {
                Category category = blog.Categories.CreateCategory(newCategory.Text);
                post.AddCategory(category);
            }

            PostType postType;

            // New ml_post check
            if (string.IsNullOrEmpty(postID))
            {
                postType = PostType.NewPost;
                blog.Posts.Insert(0, post);
            }

            else
            {
                postType = PostType.EditPost;

                if (wasDraft == true && post.Draft == false)
                {
                    if (blog.Posts.Contains(post))
                    {
                        blog.Posts.Remove(post);
                        blog.Posts.Insert(0, post);
                    }
                }
            }

            blog.Save();

            switch (postType)
            {
                case PostType.NewPost:
                    Log.NewPost(bloget, post.Id, post.Title);
                    break;

                case PostType.EditPost:
                    Log.EditPost(bloget, post.Id, post.Title);
                    break;

                default:
                    break;
            }

            if (blog.EnableAutoPingBack == true && post.Draft == false)
            {
                PingBackClient.PingLinks(bloget, bloget.PermaLink(post), content.Text);
            }

            string query = bloget.BuildQueryString(Mode.Post, post, 0, null, null, DateTime.MinValue, null);
            bloget.Redirect(query);
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void RemovePostClick(object sender, EventArgs ea)
        {
            string postID = bloget.Page.Request[bloget.BlogPostParameter];

            if (string.IsNullOrEmpty(postID) == false)
            {
                Guid id;

                try
                {
                    id = new Guid(postID);
                }

                catch
                {
                    bloget.WriteLine("<p>");
                    bloget.WriteLine(Properties.Resources.EditViewRemovePostError);
                    bloget.WriteLine("</p>");
                    return;
                }

                Blog blog = new Blog(bloget.Blog); // copy to protect readers
                blog.Posts.Remove(id);
                blog.Save();
                Log.RemovePost(bloget, id);
                bloget.Redirect(bloget.BuildQueryString(Mode.Blog, null, 0, null, null, DateTime.MinValue, null));
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void UploadImageClick(object sender, EventArgs ea)
        {
            try
            {
                if (imageUpload.HasFile)
                {
                    string path = bloget.Page.MapPath(bloget.Blog.ImageFolder);
                    path = Path.Combine(path, imageUpload.FileName);
                    imageUpload.SaveAs(path);

                    string imageLink =
                        string.Format(CultureInfo.CurrentCulture, @"<img border=""0"" src=""{0}"" />",
                                      bloget.Blog.ImageUrl + imageUpload.FileName);
                    text.Text += imageLink;
                }
            }

            catch (Exception ex)
            {
                Log.Exception(bloget, "UploadImageClick", ex);
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void UploadFileClick(object sender, EventArgs ea)
        {
            try
            {
                if (fileUpload.HasFile)
                {
                    string path = bloget.Page.MapPath(bloget.Blog.ImageFolder);
                    path = Path.Combine(path, fileUpload.FileName);
                    fileUpload.SaveAs(path);

                    const int kiloByte = 1024;
                    const int megaByte = kiloByte * kiloByte;
                    int length = fileUpload.PostedFile.ContentLength;

                    string fileLink =
                        string.Format(CultureInfo.CurrentCulture, @"<a href=""{0}"">{1} ({2:#.##} {3})</a>",
                                      bloget.Blog.ImageUrl + fileUpload.FileName,
                                      fileUpload.FileName,
                                      (length > megaByte) ? (((double)length) / megaByte) : (((double)length) / kiloByte),
                                      (length > megaByte) ? Properties.Resources.EditViewMegabyte : Properties.Resources.EditViewKilobyte);

                    text.Text += fileLink;
                }
            }

            catch (Exception ex)
            {
                Log.Exception(bloget, "UploadFileClick", ex);
            }
        }
    }
}