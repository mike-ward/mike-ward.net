﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Web.Security;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    class EditUserView : View
    {
        bool disposed;
        MembershipUser user;
        readonly TextBox name = new TextBox();
        readonly TextBox displayName = new TextBox();
        readonly TextBox email = new TextBox();
        readonly DropDownList role = new DropDownList();
        readonly TextBox password = new TextBox();
        readonly TextBox password1 = new TextBox();
        readonly TextBox password2 = new TextBox();
        readonly Button editUser = new Button();
        readonly Button cancel = new Button();
        readonly ConfirmedButton remove = new ConfirmedButton();

        internal EditUserView(Bloget bloget)
            : base(bloget)
        {
            name.ID = "name";
            displayName.ID = "displayName";
            role.ID = "role";
            email.ID = "email";
            password.ID = "password";
            password1.ID = "password1";
            password2.ID = "password2";
            editUser.ID = "edit_user";
            cancel.ID = "cancel";
            remove.ID = "remove";
        }

        protected override string RootClassId()
        {
            return "edituser-view";
        }

        protected override void ShowView()
        {
            if (!bloget.IsAdministrator)
            {
                PasswordView passwordForm = new PasswordView(bloget);
                passwordForm.Show();
                return;
            }

            MainMenu.ShowMenu(bloget);

            bloget.WriteLine("<h3>" + Resources.EditUserViewHeader + "</h3>");

            string userName = bloget.Page.Request[bloget.BlogUserParameter];
            user = Membership.GetUser(userName);

            if (user == null)
            {
                bloget.WriteLine(Resources.EditUserViewNoUserSpecified);
                return;
            }

            bloget.WriteLine("<p>");

            Label(Resources.UsersViewNewUserName, name.ID);
            name.ReadOnly = true;
            RequiredTextBoxField(name, user.UserName, string.Empty);
            bloget.WriteLine("<br/>");

            Label(Resources.EditUserViewDisplayName, displayName.ID);
            RequiredTextBoxField(displayName, user.Comment, string.Empty);
            bloget.WriteLine("<br/>");

            if (bloget.IsAdministrator)
            {
                Label("Role", role.ID);
                role.Items.Add(new ListItem(Resources.EditUserViewRoleAuthor, Bloget.AdministratorRole));
                role.Items.Add(new ListItem(Resources.EditUserViewRoleAdministrator, Bloget.AuthorRole));
                role.SelectedIndex = Bloget.IsUserAdministrator(user) ? 1 : 0;
                bloget.Controls.Add(role);
                bloget.WriteLine("<br/>");
            }

            Label(Resources.UsersViewNewUserEmail, email.ID);
            RequiredTextBoxField(email, user.Email, string.Empty);
            CustomValidator emailValidator = AdminView.EmailValidator();
            emailValidator.ControlToValidate = email.ID;
            bloget.Controls.Add(emailValidator);
            bloget.WriteLine("<br/>");

            Label(Resources.AdminViewOldPassword, password.ID);
            PasswordField(password);
            bloget.WriteLine("<br/>");

            Label(Resources.UsersViewNewUserPassword, password1.ID);
            PasswordField(password1);
            CompareValidator compareValidator = new CompareValidator();
            compareValidator.ControlToValidate = password1.ID;
            compareValidator.ControlToCompare = password2.ID;
            compareValidator.ErrorMessage = Resources.PasswordViewValidatorText;
            bloget.Controls.Add(compareValidator);
            bloget.WriteLine("<br/>");

            Label(Resources.UserViewNewUserConfirmPassword, password2.ID);
            PasswordField(password2);
            bloget.WriteLine("</p>");

            bloget.WriteLine("<p>");
            editUser.Command += EditUserCommand;
            SubmitButton(editUser, Resources.EditUserViewSubmit);

            bloget.Write(" ");
            cancel.Command += CancelCommand;
            cancel.CausesValidation = false;
            SubmitButton(cancel, "Cancel");

            if (bloget.IsAdministrator && user.UserName != bloget.GetUser().UserName)
            {
                bloget.Write(" ");
                remove.Message = "Sure?";
                remove.CausesValidation = false;
                remove.Command += RemoveCommand;
                SubmitButton(remove, "Remove");
            }

            bloget.WriteLine("</p>");
        }

        void RemoveCommand(object sender, CommandEventArgs e)
        {
            if (bloget.IsAdministrator && user.UserName != bloget.GetUser().UserName)
            {
                Membership.DeleteUser(user.UserName);
            }

            Log.EditUser(bloget, user.UserName, "Delete user");
            bloget.Redirect(bloget.BuildQueryString(Mode.Users));
        }

        void CancelCommand(object sender, CommandEventArgs e)
        {
            bloget.Redirect(bloget.BuildQueryString(Mode.Users));
        }

        void EditUserCommand(object sender, CommandEventArgs e)
        {
            if (bloget.Page.IsValid)
            {
                try
                {
                    EditUser();
                }

                catch (Exception ex)
                {
                    bloget.WriteLine(ex.Message);
                    return;
                }
            }
        }

        void EditUser()
        {
            if (user.Email != email.Text ||
                user.Comment != displayName.Text)
            {
                user.Email = email.Text;
                user.Comment = displayName.Text;
                Membership.UpdateUser(user);
                Log.EditUser(bloget, user.UserName, "Edit user setting");
            }

            if (string.IsNullOrEmpty(password.Text) == false && string.IsNullOrEmpty(password1.Text) == false)
            {
                string message = user.ChangePassword(password.Text, password1.Text)
                    ? "Updated"
                    : "Failed";

                Log.EditUser(bloget, user.UserName, "Change password");
                bloget.WriteLine(message);
            }
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        name.Dispose();
                        displayName.Dispose();
                        role.Dispose();
                        password.Dispose();
                        password1.Dispose();
                        password2.Dispose();
                        email.Dispose();
                        editUser.Dispose();
                        cancel.Dispose();
                        remove.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }
    }
}
