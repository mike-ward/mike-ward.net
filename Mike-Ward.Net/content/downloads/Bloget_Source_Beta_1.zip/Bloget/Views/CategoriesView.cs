// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Globalization;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    class CategoriesView : View
    {
        bool disposed;
        TextBox addCategory;

        internal CategoriesView(Bloget bloget)
            : base(bloget)
        {
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        addCategory.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }

        protected override string RootClassId()
        {
            return "categories-view";
        }

        protected override void ShowView()
        {
            if (bloget.IsLoggedIn == false || bloget.IsAdministrator == false)
            {
                PasswordView passwordForm = new PasswordView(bloget);
                passwordForm.Show();
                return;
            }

            MainMenu.ShowMenu(bloget);

            addCategory = new TextBox();
            addCategory.MaxLength = 25;
            bloget.Controls.Add(addCategory);

            bloget.Write("&nbsp;");

            Button addButton = new Button();
            addButton.Text = Resources.CategoriesAdd;
            addButton.Command += AddButtonCommand;
            bloget.Controls.Add(addButton);
            bloget.WriteLine("<br/><br/>");

            foreach (Category category in bloget.Blog.Categories.Sorted())
            {
                CategoryItem(category);
            }
        }

        void CategoryItem(Category category)
        {
            ConfirmedButton delete = new ConfirmedButton();
            delete.Text = Resources.CategoriesDelete;
            delete.Message = string.Format(CultureInfo.CurrentCulture, Resources.CategoriesConfirmDelete, category);
            delete.Command += DeleteCommand;
            delete.CommandArgument = category.Id.ToString(CultureInfo.InvariantCulture);
            bloget.Controls.Add(delete);

            bloget.WriteLine("&nbsp;");

            Button edit = new Button();
            edit.Text = Resources.CategoriesEdit;
            edit.Command += EditCommand;
            string textBoxId = "C" + category.Id.ToString(CultureInfo.InvariantCulture);
            edit.CommandArgument = textBoxId;
            bloget.Controls.Add(edit);

            bloget.WriteLine("&nbsp;");

            CategoryTextBox textBox = new CategoryTextBox();
            textBox.ID = textBoxId;
            textBox.CategoryId = category.Id;
            textBox.Text = category.Name;
            textBox.MaxLength = 25;
            bloget.Controls.Add(textBox);

            bloget.WriteLine("&nbsp;");
        }

        void AddButtonCommand(object sender, CommandEventArgs e)
        {
            if (string.IsNullOrEmpty(addCategory.Text) == false)
            {
                bloget.Blog.Categories.CreateCategory(addCategory.Text);
                bloget.Redirect(bloget.Page.Request.RawUrl);
            }
        }

        void DeleteCommand(object sender, CommandEventArgs e)
        {
            int categoryId;
           
            if (int.TryParse(e.CommandArgument as string, out categoryId))
            {
                if (bloget.Blog.Categories.Contains(categoryId))
                {
                    Category category = bloget.Blog.Categories[categoryId];
                    category.Deleted = true;
                    bloget.Redirect(bloget.Page.Request.RawUrl);
                }
            }
        }

        void EditCommand(object sender, CommandEventArgs e)
        {
            CategoryTextBox textBox = bloget.FindControl(e.CommandArgument as string) as CategoryTextBox;

            if (textBox != null)
            {
                if (string.IsNullOrEmpty(textBox.Text) == false)
                {
                    if (bloget.Blog.Categories.Contains(textBox.CategoryId))
                    {
                        Category category = bloget.Blog.Categories[textBox.CategoryId];
                        category.Name = textBox.Text;
                    }
                }
            }
        }
    }

    class CategoryTextBox : TextBox
    {
        int categoryId;

        internal int CategoryId
        {
            get { return categoryId; }
            set { categoryId = value; }
        }
    }
}