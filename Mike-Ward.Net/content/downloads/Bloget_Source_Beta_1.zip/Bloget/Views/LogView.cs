// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Web.Caching;
using System.Web.Hosting;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BlueOnionSoftware.Bloget
{
    class LogView : View
    {
        DropDownList fileList;
        DropDownList pageSizeSelector;
        HiddenField selected;

        bool disposed;
        const string fieldCode = "Code";
        const string fieldTime = "Time";
        const string fieldID = "ID";
        const string fieldReferer = "Referer";
        const string fieldDescription = "Description";

        const string logPageSize = "log_page_size";

        internal LogView(Bloget blogetArg)
            : base(blogetArg)
        {
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        if (fileList != null)
                        {
                            fileList.Dispose();
                        }

                        if (pageSizeSelector != null)
                        {
                            pageSizeSelector.Dispose();
                        }

                        if (selected != null)
                        {
                            selected.Dispose();
                        }
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }

        protected override string RootClassId()
        {
            return "log-view";
        }

        protected override void ShowView()
        {
            if (bloget.IsAdministrator == false)
            {
                PasswordView passwordForm = new PasswordView(bloget);
                passwordForm.Show();
                return;
            }

            MainMenu.ShowMenu(bloget);

            const string listOfLogFilesKey = "LogFiles";
            string[] files = bloget.Page.Session[listOfLogFilesKey] as string[];

            if (files == null)
            {
                string appFolder = HostingEnvironment.MapPath(Log.VirtualLogFolder);
                files = Directory.GetFiles(appFolder, Log.LogFilePattern, SearchOption.TopDirectoryOnly);
                Array.Sort(files, new ReverseCompare());

                bloget.Page.Cache.Insert(listOfLogFilesKey, files, null,
                                         DateTime.Now.AddMinutes(1d), Cache.NoSlidingExpiration);
            }

            fileList = new DropDownList();
            fileList.AutoPostBack = true;
            fileList.Width = Unit.Point(144);
            fileList.Items.Add(new ListItem("Pick File"));
            fileList.SelectedIndexChanged += OnSelect;

            foreach (string file in files)
            {
                ListItem item = new ListItem(Path.GetFileName(file), file);
                fileList.Items.Add(item);
            }

            bloget.Controls.Add(fileList);
            bloget.Controls.Add(new LiteralControl("&nbsp;" + Environment.NewLine));

            pageSizeSelector = new DropDownList();
            pageSizeSelector.Width = Unit.Point(50);
            pageSizeSelector.Items.Add("10");
            pageSizeSelector.Items.Add("20");
            pageSizeSelector.Items.Add("50");
            pageSizeSelector.Items.Add("100");
            pageSizeSelector.SelectedValue = (string) (bloget.Page.Session[logPageSize] ?? "10");
            bloget.Page.Session[logPageSize] = pageSizeSelector.SelectedItem.Value;
            pageSizeSelector.AutoPostBack = true;
            bloget.Controls.Add(pageSizeSelector);

            selected = new HiddenField();
            bloget.Controls.Add(selected);
            bloget.Controls.Add(new LiteralControl(Environment.NewLine + "<br/><br/>" + Environment.NewLine));
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void OnSelect(object sender, EventArgs ea)
        {
            try
            {
                DataView eventView = HostingEnvironment.Cache[fileList.SelectedValue] as DataView;

                if (eventView == null)
                {
                    using (DataTable events = new DataTable("Events"))
                    {
                        events.Locale = CultureInfo.InvariantCulture;
                        events.Columns.Add(fieldCode, typeof (int));
                        events.Columns.Add(fieldTime, typeof (string));
                        events.Columns.Add(fieldID, typeof (string));
                        events.Columns.Add(fieldReferer, typeof (string));
                        events.Columns.Add(fieldDescription, typeof (string));

                        using (FileStream file = FileUtilities.OpenRead(fileList.SelectedValue))
                        using (StreamReader reader = new StreamReader(file))
                        {
                            char[] separators = new char[] {};

                            while (reader.EndOfStream == false)
                            {
                                string line = reader.ReadLine();
                                string[] parts = line.Split(separators, 5, StringSplitOptions.RemoveEmptyEntries);

                                if (parts.Length != 5)
                                {
                                    continue;
                                }

                                int code;
                                if (int.TryParse(parts[0], out code) == false)
                                {
                                    continue;
                                }

                                DateTime date;
                                if (DateTime.TryParse(parts[1], out date) == false)
                                {
                                    continue;
                                }

                                DataRow row = events.NewRow();
                                row[0] = code;
                                row[1] = date.ToString("T", DateTimeFormatInfo.InvariantInfo);
                                row[2] = parts[2];
                                row[3] = parts[3];
                                row[4] = parts[4];
                                events.Rows.Add(row);
                            }
                        }

                        eventView = events.DefaultView;

                        using (CacheDependency cd = new CacheDependency(fileList.SelectedValue))
                        {
                            HostingEnvironment.Cache.Insert(fileList.SelectedValue, eventView, cd,
                                                            Cache.NoAbsoluteExpiration, new TimeSpan(0, 5, 0),
                                                            CacheItemPriority.Low, null);
                        }
                    }
                }

                BuildGrid(eventView);
            }

            catch (Exception ex)
            {
                Log.Exception(bloget, "LogView.OnSelect", ex);
                bloget.Controls.Add(new LiteralControl(ex.ToString()));
            }
        }

        void BuildGrid(DataView events)
        {
            GridView gridView = new GridView();

            // IMPORTANT - add to control group before setting properties to
            // avoid a page fault.
            bloget.Controls.Add(gridView);

            gridView.DataSource = events;
            gridView.CellPadding = 2;
            gridView.AllowSorting = true;
            gridView.Sorting += OnSort;
            gridView.AllowPaging = true;
            gridView.PageSize = Convert.ToInt32(pageSizeSelector.SelectedValue, CultureInfo.CurrentCulture);
            gridView.PagerSettings.Position = PagerPosition.TopAndBottom;
            gridView.PageIndexChanging += OnPageIndexChanging;
            gridView.RowCreated += OnRowCreated;
            gridView.DataBind();
        }

        static void OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            DataRowView dataRowView = e.Row.DataItem as DataRowView;

            if (dataRowView == null)
            {
                return;
            }

            int code;

            if (int.TryParse(dataRowView.Row.ItemArray[0].ToString(), out code) == false)
            {
                code = 0;
            }

            Color[] colors =
                {
                    Color.Empty,
                    Color.FromArgb(0xFF6060),
                    Color.FromArgb(0xAAAAFF),
                    Color.FromArgb(0x60FF60),
                    Color.FromArgb(0xFFFF60)
                };

            e.Row.BackColor = colors[(code/100)%colors.Length];
        }

        void OnSort(object sender, GridViewSortEventArgs ea)
        {
            const string sortKey = "log_sort_direction";

            GridView gridView = (GridView) sender;
            DataView dataView = (DataView) gridView.DataSource;
            ea.SortDirection = (SortDirection) (bloget.Page.Session[sortKey] ?? SortDirection.Descending);
            dataView.Sort = ea.SortExpression + ((ea.SortDirection == SortDirection.Ascending) ? " ASC" : " DESC");

            bloget.Page.Session[sortKey] = (ea.SortDirection == SortDirection.Ascending)
                                               ? SortDirection.Descending
                                               : SortDirection.Ascending;

            gridView.DataBind();
        }

        static void OnPageIndexChanging(object sender, GridViewPageEventArgs ea)
        {
            GridView gridView = (GridView) sender;
            gridView.PageIndex = ea.NewPageIndex;
            gridView.DataBind();
        }
    }
}