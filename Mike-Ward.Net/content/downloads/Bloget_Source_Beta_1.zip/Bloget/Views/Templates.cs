// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BlueOnionSoftware.Bloget
{
    public class BlogContainerControl : Control, INamingContainer
    {
        protected Bloget bloget;
        protected Blog blog;

        public BlogContainerControl(Bloget bloget, Blog blog)
        {
            this.bloget = bloget;
            this.blog = blog;
            EnableViewState = false;
        }

        /// <summary>
        /// The titleNode of the Blog
        /// </summary>
        public string BlogTitle
        {
            get { return blog.Title; }
        }

        /// <summary>
        /// Brief text of the blog. Sometimes referred to as a subtitle
        /// </summary>
        public string BlogDescription
        {
            get { return blog.Description; }
        }

        /// <summary>
        /// The copyright of the blog
        /// </summary>
        public string BlogCopyright
        {
            get { return blog.Copyright; }
        }

        /// <summary>
        /// The email address of the webmaster
        /// </summary>
        public string BlogWebmaster
        {
            get { return blog.Webmaster; }
        }

        /// <summary>
        /// Returns true if logged in
        /// </summary>
        public bool BlogLoggedIn
        {
            get { return bloget.IsLoggedIn; }
        }

        /// <summary>
        /// Returns the current view mode
        /// </summary>
        public Mode BlogMode
        {
            get { return bloget.Mode; }
        }
    }

    public class IndexContainerControl : BlogContainerControl
    {
        protected Post post;

        /// <summary>
        /// Initializes a new instance of the <see cref="IndexContainerControl"/> class.
        /// </summary>
        /// <param name="bloget">The bloget control.</param>
        /// <param name="blog">The blog model being used.</param>
        /// <param name="post">The actual post.</param>
        public IndexContainerControl(Bloget bloget, Blog blog, Post post)
            : base(bloget, blog)
        {
            this.post = post;
        }

        /// <summary>
        /// Gets the post ID. It is expressed as GUID in string format.
        /// </summary>
        /// <value>The post ID.</value>
        [SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", MessageId = "Member")]
        public string PostId
        {
            get { return post.Id.ToString(); }
        }

        /// <summary>
        /// Gets the post title.
        /// </summary>
        /// <value>The post title.</value>
        public string PostTitle
        {
            get { return post.Title; }
        }

        /// <summary>
        /// Gets the post title URL encoded.
        /// </summary>
        /// <value>The post title URL encoded.</value>
        [SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
        public string PostTitleUrlEncoded
        {
            get { return bloget.Page.Server.UrlEncode(post.Title); }
        }

        /// <summary>
        /// Gets the post created.
        /// </summary>
        /// <value>The post created.</value>
        public DateTime PostCreated
        {
            get { return Time.LocalTime(bloget.Blog.TimeZone, post.Created); }
        }

        /// <summary>
        /// Gets the post link.
        /// </summary>
        /// <value>The post link.</value>
        public string PostLink
        {
            get { return bloget.BuildQueryString(Mode.Post, post, 0, null, null, DateTime.MinValue, null); }
        }

        /// <summary>
        /// Gets the post edit link.
        /// </summary>
        /// <value>The post edit link.</value>
        public string PostEditLink
        {
            get { return bloget.BuildQueryString(Mode.Edit, post, 0, null, null, DateTime.MinValue, null); }
        }

        /// <summary>
        /// Gets the post perma link.
        /// </summary>
        /// <value>The post perma link.</value>
        public string PostPermaLink
        {
            get { return bloget.PermaLink(post); }
        }

        /// <summary>
        /// Gets the post perma link URL encoded.
        /// </summary>
        /// <value>The post perma link URL encoded.</value>
        [SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
        public string PostPermaLinkUrlEncoded
        {
            get { return bloget.Page.Server.UrlEncode(bloget.PermaLink(post)); }
        }

        /// <summary>
        /// Gets the post tags.
        /// </summary>
        /// <value>The post tags.</value>
        public IEnumerable<string> PostTags
        {
            get
            {
                List<string> tags = new List<string>();

                foreach (int tagInt in post.Tags)
                {
                    if (bloget.Blog.Categories.Contains(tagInt))
                    {
                        tags.Add(bloget.Blog.Categories[tagInt].Name);
                    }
                }

                return Array.AsReadOnly<string>(tags.ToArray());
            }
        }

        /// <summary>
        /// Posts the tag links.
        /// </summary>
        /// <param name="separator">The separator.</param>
        /// <returns>A string with the tags for the current posting separated by "separator"</returns>
        public string PostTagLinks(string separator)
        {
            using (StringWriter stringWriter = new StringWriter(CultureInfo.CurrentCulture))
            using (HtmlTextWriter html = new HtmlTextWriter(stringWriter))
            {
                bool first = true;

                foreach (int tagInt in post.Tags)
                {
                    if (bloget.Blog.Categories.Contains(tagInt))
                    {
                        html.Write((first) ? Environment.NewLine : separator);
                        first = false;

                        Category category = bloget.Blog.Categories[tagInt];
                        HyperLink hyperLink = new HyperLink();

                        hyperLink.NavigateUrl =
                            bloget.BuildQueryString(Mode.Blog, null, 0, category, null, DateTime.MinValue, null);

                        hyperLink.Text = category.Name;
                        hyperLink.RenderControl(html);
                    }
                }

                html.Flush();
                return stringWriter.ToString();
            }
        }

        /// <summary>
        /// Displays posts related to this post.
        /// </summary>
        /// <param name="maxPosts">Maximum number of related posts to display</param>
        /// <returns></returns>
        public string RelatedPosts(int maxPosts)
        {
            if (maxPosts < 0)
            {
                return string.Empty;
            }

            if (maxPosts > bloget.Blog.Posts.Count)
            {
                maxPosts = bloget.Blog.Posts.Count;
            }

            HyperLink[] links = bloget.RelatedPosts(post, maxPosts);

            using (StringWriter stringWriter = new StringWriter(CultureInfo.CurrentCulture))
            using (HtmlTextWriter html = new HtmlTextWriter(stringWriter))
            {
                foreach (HyperLink link in links)
                {
                    link.RenderControl(html);
                    html.WriteLine("<br />");
                }

                html.Flush();
                return stringWriter.ToString();
            }
        }
    }

    public class PostContainerControl : IndexContainerControl
    {
        protected Content content;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostContainerControl"/> class.
        /// </summary>
        /// <param name="bloget">The bloget control.</param>
        /// <param name="blog">The blog model.</param>
        /// <param name="post">The posting.</param>
        /// <param name="content">The content of the posting.</param>
        public PostContainerControl(Bloget bloget, Blog blog, Post post, Content content)
            : base(bloget, blog, post)
        {
            this.content = content;
        }

        /// <summary>
        /// Gets the content of the post.
        /// </summary>
        /// <value>The content of the post.</value>
        public string PostContent
        {
            get { return content.Text; }
        }

        /// <summary>
        /// Gets an excerpt of the post. An excerpt is the first [length]
        /// characters in a post. All formatting and markup is removed.
        /// </summary>
        /// <param name="length">Max length of excerpt</param>
        /// <returns>Plain text of excerpt</returns>
        public string PostExcerpt(int length)
        {
            return SearchView.Excerpt(bloget, post, length);
        }

        /// <summary>
        /// Gets the post comment count.
        /// </summary>
        /// <value>The post comment count.</value>
        public int PostCommentCount
        {
            get { return content.Comments.Count; }
        }

        /// <summary>
        /// Gets the post pingback count.
        /// </summary>
        /// <value>The post pingback count.</value>
        public int PostPingbackCount
        {
            get { return content.References.Count; }
        }

        /// <summary>
        /// Gets the post source link.
        /// </summary>
        /// <value>The post source link.</value>
        public string PostSourceLink
        {
            get { return content.SourceLink; }
        }

        /// <summary>
        /// Gets the post source title.
        /// </summary>
        /// <value>The post source title.</value>
        public string PostSourceTitle
        {
            get { return content.SourceTitle; }
        }

        /// <summary>
        /// Gets the name of the post enclosure.
        /// </summary>
        /// <value>The name of the post enclosure.</value>
        public string PostEnclosureName
        {
            get { return (content.Attachments.Count > 0) ? content.Attachments[0].Name : string.Empty; }
        }

        /// <summary>
        /// Gets the size of the post enclosure name.
        /// </summary>
        /// <value>The size of the post enclosure name.</value>
        public string PostEnclosureNameSize
        {
            get { return (content.Attachments.Count > 0) ? content.Attachments[0].ToString() : string.Empty; }
        }

        /// <summary>
        /// Gets the post enclosure link.
        /// </summary>
        /// <value>The post enclosure link.</value>
        public string PostEnclosureLink
        {
            get { return (content.Attachments.Count > 0) ? content.Attachments[0].Url : string.Empty; }
        }

        /// <summary>
        /// Gets the type of the post enclosure.
        /// </summary>
        /// <value>The type of the post enclosure.</value>
        public string PostEnclosureType
        {
            get { return (content.Attachments.Count > 0) ? content.Attachments[0].MimeType : string.Empty; }
        }

        /// <summary>
        /// Gets the length of the post enclosure.
        /// </summary>
        /// <value>The length of the post enclosure.</value>
        public long PostEnclosureLength
        {
            get { return (content.Attachments.Count > 0) ? content.Attachments[0].Length : 0; }
        }
    }

    public class CommentContainerControl : PostContainerControl
    {
        readonly Comment comment;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommentContainerControl"/> class.
        /// </summary>
        /// <param name="bloget">The bloget control.</param>
        /// <param name="blog">The blog model.</param>
        /// <param name="post">The posting.</param>
        /// <param name="content">The content of the posting.</param>
        /// <param name="comment">A comment of the posting.</param>
        public CommentContainerControl(Bloget bloget, Blog blog, Post post, Content content, Comment comment)
            : base(bloget, blog, post, content)
        {
            this.comment = comment;
        }

        /// <summary>
        /// Gets the comment title.
        /// </summary>
        /// <value>The comment title.</value>
        public string CommentTitle
        {
            get { return comment.Title; }
        }

        /// <summary>
        /// Gets the comment date.
        /// </summary>
        /// <value>The comment date.</value>
        public DateTime CommentDate
        {
            get { return Time.LocalTime(bloget.Blog.TimeZone, comment.Date); }
        }

        /// <summary>
        /// Gets the comment author.
        /// </summary>
        /// <value>The comment author.</value>
        public string CommentAuthor
        {
            get { return comment.Author; }
        }

        /// <summary>
        /// Gets the comment email.
        /// </summary>
        /// <value>The comment email.</value>
        public string CommentEmail
        {
            get { return comment.Email; }
        }

        /// <summary>
        /// Gets the comment text.
        /// </summary>
        /// <value>The comment text.</value>
        public string CommentText
        {
            get { return BlogView.CommentToHtml(comment.Text); }
        }
    }

    public class PingBackContainerControl : PostContainerControl
    {
        readonly Reference pingBack;

        /// <summary>
        /// Initializes a new instance of the <see cref="PingBackContainerControl"/> class.
        /// </summary>
        /// <param name="bloget">The bloget.</param>
        /// <param name="blog">The blog.</param>
        /// <param name="post">The post.</param>
        /// <param name="content">The content.</param>
        /// <param name="pingBack">The ping back.</param>
        public PingBackContainerControl(Bloget bloget, Blog blog, Post post, Content content, Reference pingBack)
            : base(bloget, blog, post, content)
        {
            this.pingBack = pingBack;
        }

        /// <summary>
        /// Gets the ping back link.
        /// </summary>
        /// <value>The ping back link.</value>
        public string PingBackLink
        {
            get { return pingBack.Link; }
        }

        /// <summary>
        /// Gets the ping back date.
        /// </summary>
        /// <value>The ping back date.</value>
        [SuppressMessage("Microsoft.Naming", "CA1702:CompoundWordsShouldBeCasedCorrectly", MessageId = "BackDate")]
        public DateTime PingBackDate
        {
            get { return Time.LocalTime(bloget.Blog.TimeZone, pingBack.Date); }
        }
    }
}