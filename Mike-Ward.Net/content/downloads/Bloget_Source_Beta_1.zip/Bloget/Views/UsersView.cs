// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;
using System.Web.Security;
using System.Collections.ObjectModel;

namespace BlueOnionSoftware.Bloget
{
    class UsersView : View
    {
        bool disposed;
        readonly GridView users = new GridView();
        readonly CreateUserWizard createUser = new CreateUserWizard();
        readonly UserCollection userCollection = new UserCollection();

        internal UsersView(Bloget bloget)
            : base(bloget)
        {
        }

        protected override string RootClassId()
        {
            return "users-view";
        }

        protected override void ShowView()
        {
            if (bloget.IsAdministrator == false)
            {
                PasswordView passwordForm = new PasswordView(bloget);
                passwordForm.Show();
                return;
            }

            MainMenu.ShowMenu(bloget);

            foreach (MembershipUser user in bloget.GetAllUsers())
            {
                if (Bloget.IsUserAdministrator(user))
                {
                    userCollection.Add(new User(user, Bloget.AdministratorRole));
                }

                else if (Bloget.IsUserAuthor(user))
                {
                    userCollection.Add(new User(user, Bloget.AuthorRole));
                }
            }

            createUser.CreateUserStep.Title = string.Empty;
            createUser.LoginCreatedUser = false;
            createUser.CreatedUser += CreatedUser;
            bloget.Controls.Add(createUser);

            users.AutoGenerateColumns = false;
            users.AutoGenerateEditButton = true;
            users.RowEditing += UsersRowEditing;
            users.CssClass = RootClassId() + "-users";

            BoundField nameColumn = new BoundField();
            nameColumn.DataField = "UserName";
            nameColumn.HeaderText = Resources.UserViewColumnName;
            users.Columns.Add(nameColumn);

            BoundField role = new BoundField();
            role.DataField = "Role";
            role.HeaderText = Resources.UsersViewColumnRole;
            users.Columns.Add(role);

            BoundField emailColumn = new BoundField();
            emailColumn.DataField = "Email";
            emailColumn.HeaderText = Resources.UserViewColumnEmail;
            users.Columns.Add(emailColumn);

            BoundField lastLogin = new BoundField();
            lastLogin.DataField = "LastLogin";
            lastLogin.HeaderText = Resources.UserViewColumnLastLogin;
            lastLogin.ReadOnly = true;
            users.Columns.Add(lastLogin);

            users.DataSource = userCollection;
            bloget.Controls.Add(users);
        }

        void CreatedUser(object sender, EventArgs e)
        {
            Roles.AddUserToRole(createUser.UserName, Bloget.AuthorRole);
        }

        void UsersRowEditing(object sender, GridViewEditEventArgs e)
        {
            User user = userCollection[e.NewEditIndex];

            bloget.Redirect(bloget.BuildQueryString
                (Mode.EditUser, null, 0, null, null, default(DateTime), user.UserName));
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        createUser.Dispose();
                        users.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }
    }

    public class User
    {
        public User(MembershipUser user, string roleArg)
        {
            UserName = user.UserName;
            Email = user.Email;
            LastLogin = user.LastLoginDate;
            Role = roleArg;
        }

        public string UserName { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public DateTime LastLogin { get; set; }
    }

    class UserCollection : Collection<User>
    {
    }
}
