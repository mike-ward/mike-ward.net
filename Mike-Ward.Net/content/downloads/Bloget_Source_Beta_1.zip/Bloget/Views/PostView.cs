// Copyright (C) 2007 Blue Onion Software
// All rights reserved

namespace BlueOnionSoftware.Bloget
{
    class PostView : BlogView
    {
        internal PostView(BlogetBlog blogetBlog)
            : base(blogetBlog)
        {
        }

        protected override void ShowView()
        {
            ShowPost();
        }
    }
}
