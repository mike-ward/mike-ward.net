// Copyright (C) 2007 Blue Onion Software
// All rights reserved

namespace BlueOnionSoftware.Bloget
{
    class PostsByMonthView : BlogView
    {
        internal PostsByMonthView(BlogetBlog blogetBlog)
            : base(blogetBlog)
        {
        }

        protected override void ShowView()
        {
            ShowPostsByMonth();
        }
    }
}