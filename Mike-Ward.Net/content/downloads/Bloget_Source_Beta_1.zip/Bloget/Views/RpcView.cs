// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Xml;

namespace BlueOnionSoftware.Bloget
{
    class RpcView : View
    {
        internal RpcView(Bloget blogetArg)
            : base(blogetArg)
        {
        }

        protected override string RootClassId()
        {
            return null;
        }

        protected override void ShowView()
        {
            if (bloget.Page.Request.RequestType == "POST")
            {
                XmlRpcCall();
            }

            else
            {
                RealSimpleDiscovery();
            }

            bloget.Page.Response.End();
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void XmlRpcCall()
        {
            XmlRpcMethodResponse methodResponse;
            string methodCallName = string.Empty;

            try
            {
                XmlRpcMethodCall methodCall = GetRpcRequest();
                methodCallName = methodCall.Name;
                Log.RpcRequest(bloget, methodCallName);

                switch (methodCall.Name)
                {
                    case PingBackServer.MethodPing:
                        methodResponse = PingBackServer.Ping(methodCall, bloget);
                        break;

                    case MetaWebLog.MethodNewPost:
                    case MetaWebLog.MethodEditPost:
                        methodResponse = MetaWebLog.Post(methodCall, bloget);
                        break;

                    case MetaWebLog.MethodGetPost:
                        methodResponse = MetaWebLog.GetPost(methodCall, bloget);
                        break;

                    case MetaWebLog.MethodGetCategories:
                        methodResponse = MetaWebLog.GetCategories(methodCall, bloget);
                        break;

                    case MetaWebLog.MethodGetRecentPosts:
                        methodResponse = MetaWebLog.GetRecentPosts(methodCall, bloget);
                        break;

                    case MetaWebLog.MethodNewMediaObject:
                        methodResponse = MetaWebLog.NewMediaObject(methodCall, bloget);
                        break;

                    case Blogger.MethodDeletePost:
                        methodResponse = Blogger.DeletePost(methodCall, bloget);
                        break;

                    case Blogger.MethodGetUsersBlogs:
                        methodResponse = Blogger.GetUsersBlogs(methodCall, bloget);
                        break;

                    case Blogger.MethodGetUserInfo:
                        methodResponse = Blogger.GetUserInfo(methodCall, bloget);
                        break;

                    default:
                        methodResponse = new XmlRpcMethodResponse();
                        methodResponse.FaultString = "Unrecognized Rpc request (" + methodCallName + ")";
                        break;
                }
            }

            catch (Exception ex)
            {
                methodResponse = new XmlRpcMethodResponse();
                methodResponse.FaultString = ex.Message;
                Log.Exception(bloget, "BlogetRpc.CreateControls", ex);
            }

            if (string.IsNullOrEmpty(methodResponse.FaultString))
            {
                Log.RpcRequestAccepted(bloget, methodCallName);
            }

            else
            {
                Log.RpcRequestRejected(bloget, methodCallName, methodResponse.FaultString);
            }

            try
            {
                using (XmlWriter writer = XmlRpc.CreateXmlWriter(bloget.Page))
                {
                    methodResponse.Serialize(writer);
                }
            }

            catch (Exception ex)
            {
                Log.Exception(bloget, "BlogetRpc.CreateControls (Serialize)", ex);
            }
        }

        XmlRpcMethodCall GetRpcRequest()
        {
            XmlReaderSettings xmlSettings = new XmlReaderSettings();
            xmlSettings.IgnoreComments = true;
            xmlSettings.IgnoreProcessingInstructions = true;
            xmlSettings.IgnoreWhitespace = true;

            string rpcRequest;

            using (StreamReader streamReader = new StreamReader(bloget.Page.Request.InputStream))
            {
                rpcRequest = streamReader.ReadToEnd();
            }

            try
            {
                using (StringReader stringReader = new StringReader(rpcRequest))
                using (XmlReader reader = XmlReader.Create(stringReader, xmlSettings))
                {
                    return XmlRpc.ReadMethod(reader);
                }
            }

            catch (Exception)
            {
                Log.RpcRequest(bloget, "Exception in GetRpcRequest rethrown, original request:" + rpcRequest);
                throw;
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void RealSimpleDiscovery()
        {
            try
            {
                using (XmlWriter writer = XmlRpc.CreateXmlWriter(bloget.Page))
                {
                    writer.WriteStartDocument();
                    writer.WriteStartElement("rsd", "http://archipelago.phrasewise.com/rsd");
                    writer.WriteAttributeString("version", "1.0");
                    writer.WriteStartElement("service");
                    writer.WriteElementString("engineName", "Bloget");
                    writer.WriteElementString("engineLink", "http://blueonionsoftware.com/Bloget.aspx");
                    writer.WriteElementString("homePageLink", "http://blueonionsoftware.com/");
                    writer.WriteStartElement("apis");
                    writer.WriteStartElement("api");
                    writer.WriteAttributeString("name", "MetaWeblog");
                    writer.WriteAttributeString("preferred", "true");
                    writer.WriteAttributeString("apiLink", bloget.Page.Request.Url.ToString());
                    writer.WriteAttributeString("blogID", "1");
                    writer.WriteEndDocument();
                    writer.Flush();
                }
            }

            catch (Exception ex)
            {
                Log.Exception(bloget, "BlogetRpc.RealSimpleDiscovery", ex);
            }
        }
    }
}