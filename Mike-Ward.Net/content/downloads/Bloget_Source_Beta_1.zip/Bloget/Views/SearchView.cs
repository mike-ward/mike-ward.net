// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    class SearchView : View
    {
        internal SearchView(Bloget bloget)
            : base(bloget)
        {
        }

        protected override string RootClassId()
        {
            return "search-view";
        }

        protected override void ShowView()
        {
            Post[] posts = Search.Find(bloget, bloget.QuerySort);

            if (bloget.SearchResultsTemplate == null)
            {
                NormalView(posts);
            }

            else
            {
                CustomView(posts);
            }
        }

        HyperLink Title(Post post)
        {
            HyperLink link = new HyperLink();
            link.Text = post.Title;
            link.NavigateUrl = bloget.BuildQueryString(Mode.Post, post, 0, null, null, default(DateTime), null);
            return link;
        }

        static readonly Regex removeHtml = new Regex("<(.|\n)*?>", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        internal static string Excerpt(Bloget bloget, Post post, int length)
        {
            Content content = bloget.Blog.LoadContent(post.Id);
            string plainText = removeHtml.Replace(content.Text, string.Empty);
            return plainText.Substring(0, Math.Min(plainText.Length, Math.Min(content.Text.Length, Math.Max(10, length))));
        }

        void NormalView(Post[] posts)
        {
            string results = string.Format(CultureInfo.CurrentCulture,
                                           Resources.SearchResults, posts.Length, bloget.QuerySort);

            bloget.WriteLine("<h2>" + results + "</h2>");

            foreach (Post post in posts)
            {
                bloget.Write("<h3>");
                bloget.Controls.Add(Title(post));
                bloget.WriteLine("</h3>");
                bloget.WriteLine("<div>" + Excerpt(bloget, post, 250) + "...</div>");
            }
        }

        void CustomView(IEnumerable<Post> posts)
        {
            foreach (Post post in posts)
            {
                Content content = bloget.Blog.LoadContent(post.Id);
                PostContainerControl postContainer = new PostContainerControl(bloget, bloget.Blog, post, content);
                bloget.SearchResultsTemplate.InstantiateIn(postContainer);
                bloget.Controls.Add(postContainer);
            }
        }
    }
}