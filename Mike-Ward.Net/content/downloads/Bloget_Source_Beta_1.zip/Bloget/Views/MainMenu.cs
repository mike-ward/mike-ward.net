// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Globalization;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    static class MainMenu
    {
        internal static void ShowMenu(Bloget bloget)
        {
            if (bloget == null)
            {
                throw new ArgumentNullException("bloget");
            }

            bloget.WriteLine(@"<ul class=""admin-menu"">");

            if (bloget.IsAuthorOrAdministrator)
            {
                bloget.WriteLine(MenuItem(bloget, Resources.MainMenuWrite, Mode.Edit));
            }

            if (bloget.IsAdministrator)
            {
                bloget.WriteLine(MenuItem(bloget, Resources.MainMenuAdmin, Mode.Admin));
                bloget.WriteLine(MenuItem(bloget, Resources.MainMenuCategories, Mode.Categories));
            }

            if (bloget.IsAuthorOrAdministrator)
            {
                bloget.WriteLine(MenuItem(bloget, Resources.MainMenuUsers, Mode.Users));
            }

            if (bloget.IsAdministrator)
            {
                bloget.WriteLine(MenuItem(bloget, Resources.MainMenuDrafts, Mode.Drafts));
                bloget.WriteLine(MenuItem(bloget, Resources.MainMenuEventLog, Mode.Log));
            }

            bloget.WriteLine(MenuItem(bloget, Resources.MainMenuViewBlog, Mode.Blog));

            if (bloget.IsLoggedIn)
            {
                bloget.WriteLine(MenuItem(bloget, Resources.MainMenuLogout, Mode.LogOff));
            }

            bloget.WriteLine("</ul>");
        }

        static string MenuItem(Bloget bloget, string text, Mode mode)
        {
            if (mode == bloget.Mode)
            {
                return string.Format(CultureInfo.InvariantCulture, @"<li >{0}</li>", text);
            }

            else
            {
                string link = bloget.BuildQueryString(mode, null, 0, null, null, default(DateTime), null);
                return string.Format(CultureInfo.InvariantCulture, @"<li><a href=""{0}"">{1}</a></li>", link, text);
            }
        }
    }
}