// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Web.Security;
using System.Web.UI.WebControls;

namespace BlueOnionSoftware.Bloget
{
    class PasswordView : View
    {
        bool disposed;
        readonly Login login = new Login();

        internal PasswordView(Bloget blogetArg)
            : base(blogetArg)
        {
            login.ID = "login";
        }

        protected override string RootClassId()
        {
            return "password-view";
        }

        protected override void ShowView()
        {
            bloget.Controls.Add(login);
            bloget.Load += OnLoad;
            login.LoggedIn += LoginLoggedIn;
        }

        void OnLoad(object sender, EventArgs ea)
        {
            login.Focus();
            bloget.Load -= OnLoad;
        }

        void LoginLoggedIn(object sender, EventArgs e)
        {
            FormsAuthentication.RedirectFromLoginPage(login.UserName, login.RememberMeSet);
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        login.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }
    }
}