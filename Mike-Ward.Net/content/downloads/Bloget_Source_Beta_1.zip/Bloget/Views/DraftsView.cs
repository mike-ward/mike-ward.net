// Copyright (C) 2007 Blue Onion Software
// All rights reserved

namespace BlueOnionSoftware.Bloget
{
    class DraftsView : IndexView
    {
        internal DraftsView(Bloget blogetArg)
            : base(blogetArg)
        {
        }

        protected override string RootClassId()
        {
            return "drafts-view";
        }

        protected override void ShowView()
        {
            if (bloget.IsAuthor || bloget.IsAdministrator)
            {
                PasswordView passwordForm = new PasswordView(bloget);
                passwordForm.Show();
                return;
            }

            MainMenu.ShowMenu(bloget);
            Index(true, null);
        }
    }
}
