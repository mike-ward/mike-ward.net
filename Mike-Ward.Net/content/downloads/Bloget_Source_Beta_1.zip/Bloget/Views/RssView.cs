// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Web.UI;
using System.Xml;

namespace BlueOnionSoftware.Bloget
{
    class RssView : View
    {
        internal RssView(Bloget blogetArg)
            : base(blogetArg)
        {
        }

        protected override string RootClassId()
        {
            return null;
        }

        protected override void ShowView()
        {
            using (XmlWriter writer = XmlRpc.CreateXmlWriter(bloget.Page))
            {
                Rss20(writer);
            }

            bloget.Page.Response.End();
        }


        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        internal void Rss20(XmlWriter w)
        {
            w.WriteStartDocument();
            w.WriteStartElement("rss");
            w.WriteAttributeString("version", "2.0");

            w.WriteStartElement("channel");
            w.WriteElementString("title", bloget.Blog.Title);
            w.WriteElementString("description", bloget.Blog.Description);
            w.WriteElementString("link", Uri.EscapeUriString(bloget.Blog.Link));
            w.WriteElementString("language", bloget.Blog.Language);
            w.WriteElementString("copyright", bloget.Blog.Copyright);
            w.WriteElementString("webMaster", bloget.Blog.Webmaster);
            w.WriteElementString("generator", "Powered by Bloget");

            if (string.IsNullOrEmpty(bloget.Blog.RssChannelImage) == false)
            {
                try
                {
                    w.WriteStartElement("image");
                    w.WriteElementString("url", Uri.EscapeUriString(bloget.Blog.RssChannelImage));
                    w.WriteElementString("title", bloget.Blog.Title);
                    w.WriteElementString("link", Uri.EscapeUriString(bloget.Blog.Link));
                    w.WriteElementString("description", bloget.Blog.Description);
                    w.WriteEndElement();
                }

                catch (Exception ex)
                {
                    Log.Exception(bloget, "Rss20", ex);
                }
            }

            int count = 0;

            foreach (
                Post post in
                    bloget.Blog.EnumeratePosts(bloget.QueryStart, bloget.Blog.RssEntriesPerFeed, bloget.QueryCategory,
                                               false, true))
            {
                w.WriteStartElement("item");
                w.WriteElementString("title", post.Title);
                w.WriteElementString("pubDate", post.Created.ToString("r", CultureInfo.InvariantCulture));
                w.WriteElementString("link", Uri.EscapeUriString(bloget.PermaLink(post)));

                w.WriteStartElement("guid");
                w.WriteAttributeString("isPermaLink", "false");
                w.WriteString(post.Id.ToString());
                w.WriteEndElement();

                if (string.IsNullOrEmpty(bloget.Blog.Webmaster) == false)
                {
                    w.WriteElementString("author", bloget.Blog.Webmaster);
                }

                Content content = bloget.Blog.LoadContent(post.Id);

                if (bloget.RssContentTemplate != null)
                {
                    PostContainerControl postContainer = new PostContainerControl(bloget, bloget.Blog, post, content);
                    bloget.RssContentTemplate.InstantiateIn(postContainer);
                    postContainer.DataBind();

                    using (StringWriter sw = new StringWriter(CultureInfo.InvariantCulture))
                    using (HtmlTextWriter html = new HtmlTextWriter(sw))
                    {
                        html.BeginRender();
                        postContainer.RenderControl(html);
                        html.Flush();
                        html.EndRender();
                        w.WriteElementString("description", sw.ToString());
                    }
                }

                else
                {
                    w.WriteElementString("description", content.Text + bloget.Blog.RssFooter);
                }

                foreach (int id in post.Tags)
                {
                    if (bloget.Blog.Categories.Contains(id))
                    {
                        w.WriteElementString("category", bloget.Blog.Categories[id].Name);
                    }
                }

                if (content.Attachments.Count > 0)
                {
                    Attachment attachment = content.Attachments[0];
                    w.WriteStartElement("enclosure");
                    w.WriteAttributeString("url", Uri.EscapeUriString(attachment.Url));
                    w.WriteAttributeString("length", attachment.Length.ToString(CultureInfo.InvariantCulture));
                    w.WriteAttributeString("type", attachment.MimeType);
                    w.WriteEndElement();
                }

                w.WriteEndElement();

                if (++count >= bloget.Blog.PostsPerPage)
                {
                    break;
                }
            }

            w.WriteEndDocument();
            w.Flush();
        }
    }
}