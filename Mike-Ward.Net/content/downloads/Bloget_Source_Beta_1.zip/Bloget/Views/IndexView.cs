// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    class IndexView : View
    {
        internal IndexView(Bloget blogetArg)
            : base(blogetArg)
        {
        }

        protected override string RootClassId()
        {
            return "index-view";
        }

        protected override void ShowView()
        {
            Index(false, bloget.QueryCategory);
        }

        protected void Index(bool draftsOnly, Category category)
        {
            BlogView.ShowHeader(bloget);

            if (bloget.IndexHeaderTemplate != null)
            {
                BlogContainerControl blogContainer = new BlogContainerControl(bloget, bloget.Blog);
                bloget.IndexHeaderTemplate.InstantiateIn(blogContainer);
                bloget.Controls.Add(blogContainer);
            }

            int year = -1;
            int month = -1;
            bool noEntries = true;

            foreach (Post post in bloget.Blog.EnumeratePosts(0, bloget.Blog.Posts.Count, category, draftsOnly, false))
            {
                if (post.Created.Year != year)
                {
                    IndexYearSeparator(post);
                    year = post.Created.Year;
                    month = -1;
                }

                if (post.Created.Month != month)
                {
                    IndexMonthSeparator(post, (month == -1));
                    month = post.Created.Month;
                }

                IndexEntry(post);
                noEntries = false;
            }

            if (noEntries == true)
            {
                bloget.WriteLine("<p>" + Resources.IndexViewNoEntriesFound + "</p>");
            }

            if (bloget.IndexFooterTemplate != null)
            {
                BlogContainerControl blogContainer = new BlogContainerControl(bloget, bloget.Blog);
                bloget.IndexFooterTemplate.InstantiateIn(blogContainer);
                bloget.Controls.Add(blogContainer);
            }

            BlogView.ShowFooter(bloget);
            bloget.PoweredByBloget();
        }

        void IndexEntry(Post post)
        {
            if (bloget.IndexTemplate != null)
            {
                IndexContainerControl indexContainer = new IndexContainerControl(bloget, bloget.Blog, post);
                bloget.IndexTemplate.InstantiateIn(indexContainer);
                bloget.Controls.Add(indexContainer);
            }

            else
            {
                bloget.WriteLine(post.Created.ToString("MM-dd-yyyy", CultureInfo.CurrentCulture) + "&nbsp;&nbsp;");
                HyperLink link = new HyperLink();
                link.Text = post.Title;
                link.NavigateUrl = bloget.BuildQueryString(Mode.Post, post, 0, null, null, DateTime.MinValue, null);
                bloget.Controls.Add(link);
                bloget.WriteLine("<br/>");
            }
        }

        void IndexMonthSeparator(Post post, bool firstMonth)
        {
            if (bloget.IndexMonthSeparatorTemplate != null)
            {
                IndexContainerControl indexContainer = new IndexContainerControl(bloget, bloget.Blog, post);
                bloget.IndexMonthSeparatorTemplate.InstantiateIn(indexContainer);
                bloget.Controls.Add(indexContainer);
            }

            else
            {
                if (firstMonth == false)
                {
                    bloget.WriteLine("<br/>");
                }
            }
        }

        void IndexYearSeparator(Post post)
        {
            if (bloget.IndexYearSeparatorTemplate != null)
            {
                IndexContainerControl indexContainer = new IndexContainerControl(bloget, bloget.Blog, post);
                bloget.IndexYearSeparatorTemplate.InstantiateIn(indexContainer);
                bloget.Controls.Add(indexContainer);
            }

            else
            {
                bloget.WriteLine(@"<h3 class=""index-year"">" +
                                 post.Created.Year.ToString(CultureInfo.CurrentCulture) + "</h3>");
            }
        }
    }
}