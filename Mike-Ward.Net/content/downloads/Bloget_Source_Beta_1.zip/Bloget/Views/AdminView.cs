// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Hosting;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    class AdminView : View
    {
        readonly TextBox title = new TextBox();
        readonly TextBox description = new TextBox();
        readonly TextBox link = new TextBox();
        readonly TextBox firstName = new TextBox();
        readonly TextBox lastName = new TextBox();

        readonly TextBox language = new TextBox();
        readonly TextBox copyright = new TextBox();
        readonly TextBox webMaster = new TextBox();
        readonly TextBox author = new TextBox();
        readonly TextBox rssChannelImage = new TextBox();
        readonly TextBox rssFooter = new TextBox();
        readonly TextBox rssEntriesPerFeed = new TextBox();

        readonly TextBox itemsPerPage = new TextBox();
        readonly DropDownList timeZone = new DropDownList();
        readonly TextBox editorWidth = new TextBox();
        readonly TextBox editorHeight = new TextBox();

        readonly CheckBox allowComments = new CheckBox();
        readonly TextBox expireComments = new TextBox();
        readonly TextBox maximumComments = new TextBox();
        readonly TextBox maximumPingBacks = new TextBox();

        readonly CheckBox emailComments = new CheckBox();
        readonly CheckBox emailPingbacks = new CheckBox();
        readonly TextBox emailFrom = new TextBox();
        readonly TextBox emailTo = new TextBox();
        readonly Button testEmail = new Button();

        readonly CheckBox enableRealSimpleDiscovery = new CheckBox();
        readonly CheckBox enableMetaWebLogApi = new CheckBox();
        readonly CheckBox enableAutoPingBack = new CheckBox();
        readonly CheckBox enablePingBackService = new CheckBox();
        readonly TextBox expirePingBacks = new TextBox();

        readonly TextBox imageFolder = new TextBox();
        readonly TextBox imageUrl = new TextBox();

        readonly FileUpload upload = new FileUpload();
        readonly Button save = new Button();

        bool disposed;

        const int MaxTextBoxLength = 200;
        const int MaxPasswordLength = 30;

        static readonly CultureInfo currentCulture = CultureInfo.CurrentCulture;
        static readonly CultureInfo invariantCulture = CultureInfo.InvariantCulture;

        internal AdminView(BlogetBlog blogetBlog)
            : base(blogetBlog)
        {
            title.ID = "title";
            description.ID = "description";
            link.ID = "link";
            firstName.ID = "firstName";
            lastName.ID = "lastName";

            language.ID = "language";
            copyright.ID = "copyright";
            webMaster.ID = "webMaster";
            author.ID = "author";
            rssChannelImage.ID = "rssChannelImage";
            rssFooter.ID = "rssFooter";
            rssEntriesPerFeed.ID = "rssEntriesPerFeed";

            itemsPerPage.ID = "itemsPerPage";
            timeZone.ID = "timeZone";
            editorWidth.ID = "editorWidth";
            editorHeight.ID = "editorHeight";

            allowComments.ID = "allowComments";
            expireComments.ID = "expireComments";
            maximumComments.ID = "maximumComments";
            maximumPingBacks.ID = "maximumPingBacks";

            emailComments.ID = "emailComments";
            emailPingbacks.ID = "emailPingbacks";
            emailFrom.ID = "emailFrom";
            emailTo.ID = "emailTo";
            testEmail.ID = "testEmail";

            enableRealSimpleDiscovery.ID = "enableRSD";
            enableMetaWebLogApi.ID = "enableMetaWebLogApi";
            expirePingBacks.ID = "expirePingBacks";
            enableAutoPingBack.ID = "enableAutoPingBack";
            enablePingBackService.ID = "enablePingBackService";

            imageFolder.ID = "imageFolder";
            imageUrl.ID = "imageUrl";

            upload.ID = "upload";
            save.ID = "saveButton";
        }

        void BasicInformationSection()
        {
            Section(Resources.AdminViewBasicInformationSection);

            InputField(Resources.AdminViewTitle, title, bloget.Blog.Title, string.Empty, true, null);
            InputField(Resources.AdminViewSubtitle, description, bloget.Blog.Description, string.Empty, true, null);
            InputField(Resources.AdminViewBlogLink, link, bloget.Blog.Link, Resources.AdminViewBlogLinkTip, true, UrlValidator());

            EndSection();
        }

        void SyndicationSection()
        {
            Section(Resources.AdminViewSyndicationSection);

            InputField(Resources.AdminViewLanguage, language, bloget.Blog.Language, Resources.AdminViewLanguageTip, true,
                       null);

            InputField(Resources.AdminViewCopyright, copyright, bloget.Blog.Copyright, Resources.AdminViewCopyrightTip,
                       true, null);

            InputField(Resources.AdminViewWebMaster, webMaster, bloget.Blog.Webmaster, Resources.AdminViewWebMasterTip,
                       true,
                       EmailValidator());

            InputField(Resources.AdminViewRssChannelImage, rssChannelImage, bloget.Blog.RssChannelImage,
                       Resources.AdminViewRssChannelImageTip, false, UrlValidator());

            InputField(Resources.AdminViewRssFooter, rssFooter, bloget.Blog.RssFooter, Resources.AdminViewRssFooterTip,
                       false, null);

            NumericField(Resources.AdminViewPostsPerFeed, rssEntriesPerFeed,
                         bloget.Blog.RssEntriesPerFeed.ToString(currentCulture),
                         Resources.AdminViewPostsPerFeedTip, false, RangeValidator("1", "100"));

            EndSection();
        }

        void AppearanceSection()
        {
            Section(Resources.AdminViewAppearanceSection);

            NumericField(Resources.AdminViewItemsPerPage, itemsPerPage,
                         bloget.Blog.PostsPerPage.ToString(currentCulture),
                         Resources.AdminViewItemsPerPageTip, true, RangeValidator("1", "100"));

            TimeZoneField(timeZone);

            NumericField(Resources.AdminViewEditorWidth, editorWidth, bloget.Blog.EditorWidth.ToString(currentCulture),
                         Resources.AdminViewEditorWidthTip, true, RangeValidator("100", "5000"));

            NumericField(Resources.AdminViewEditorHeight, editorHeight,
                         bloget.Blog.EditorHeight.ToString(currentCulture),
                         Resources.AdminViewEditorHeightTip, true, RangeValidator("100", "5000"));

            EndSection();
        }

        void CommentSection()
        {
            Section(Resources.AdminViewCommentsSection);

            CheckBoxField(Resources.AdminViewAllowComments, allowComments, bloget.Blog.AllowComments,
                          Resources.AdminViewAllowCommentsTip);

            NumericField(Resources.AdminViewExpireComments, expireComments,
                         bloget.Blog.ExpireComments.ToString(currentCulture),
                         Resources.AdminViewExpireCommentsTip, true,
                         RangeValidator("1", "999"));

            NumericField(Resources.AdminViewCommentsPerPost, maximumComments,
                         bloget.Blog.MaximumCommentsPerPost.ToString(currentCulture),
                         Resources.AdminViewCommentsPerPostTip, true, RangeValidator("1", "999"));

            EndSection();
        }

        void NotificationsSection()
        {
            Section(Resources.AdminViewNotificationsSection);

            CheckBoxField(Resources.AdminViewNotifyComments, emailComments, bloget.Blog.EmailComments,
                          Resources.AdminViewNotifyCommentsTip);

            CheckBoxField(Resources.AdminViewNotifyPingBacks, emailPingbacks, bloget.Blog.EmailPingbacks,
                          Resources.AdminViewNotifyPingBacksTip);

            InputField(Resources.AdminViewNotifyToAddress, emailTo, bloget.Blog.EmailTo,
                       Resources.AdminViewNotifyToAddressTip, false, EmailValidator());

            Label(string.Empty, string.Empty);
            testEmail.Text = Resources.AdminViewNotifyTestMessageButton;
            testEmail.Click += SendTestEmailClick;
            bloget.Controls.Add(testEmail);

            EndSection();
        }

        void ServicesSection()
        {
            Section(Resources.AdminViewServicesSection);

            CheckBoxField(Resources.AdminViewServicesRsd, enableRealSimpleDiscovery,
                          bloget.Blog.EnableRealSimpleDiscovery,
                          Resources.AdminViewServicesRsdTip);

            CheckBoxField(Resources.AdminViewServicesMetaWeblogApi, enableMetaWebLogApi, bloget.Blog.EnableMetaWeblogApi,
                          Resources.AdminViewServicesMetaWeblogApiTip);

            CheckBoxField(Resources.AdminViewServicesSendPingbacks, enableAutoPingBack, bloget.Blog.EnableAutoPingBack,
                          Resources.AdminViewServicesSendPingbacksTips);

            CheckBoxField(Resources.AdminViewServicesAcceptPingBacks, enablePingBackService,
                          bloget.Blog.EnablePingBackService,
                          Resources.AdminViewServicesAcceptPingBacksTip);

            NumericField(Resources.AdminViewServicesExpirePingBacks, expirePingBacks,
                         bloget.Blog.ExpirePingBacks.ToString(currentCulture),
                         Resources.AdminViewServicesExpirePingBacksTip,
                         true, RangeValidator("1", "999"));

            NumericField(Resources.AdminViewServicesMaximumPingBacks, maximumPingBacks,
                         bloget.Blog.MaximumPingsBacksPerPost.ToString(currentCulture),
                         Resources.AdminViewServicesMaximumPingBacksTip,
                         true, RangeValidator("1", "999"));

            EndSection();
        }

        void ImagesSection()
        {
            Section(Resources.AdminViewImagesSection);

            InputField(Resources.AdminViewImageFolder, imageFolder, bloget.Blog.ImageFolder,
                       Resources.AdminViewImageFolderTip,
                       false, VirtualPathValidator());

            InputField(Resources.AdminViewImageUrl, imageUrl, bloget.Blog.ImageUrl,
                       Resources.AdminViewImageUrlTip,
                       false, UrlValidator());

            EndSection();
        }

        void ImportExportSection()
        {
            Section(Resources.AdminViewImportExportSection);
            Button export = new Button();
            export.ID = "export";
            export.Text = Resources.AdminViewImportExportDownloadButton;
            export.ToolTip = Resources.AdminViewImportExportDownloadButtonTip;
            export.Click += ExportDataClick;
            Label(Resources.AdminViewImportExportExportLabel, export.ID);
            bloget.Controls.Add(export);
            bloget.WriteLine("<br />");

            Label(Resources.AdminViewImportExportImportLabel, upload.ID);
            bloget.Controls.Add(upload);
            bloget.Write("&nbsp;");
            Button import = new Button();
            import.Text = Resources.AdminViewImportExportImportButton;
            import.ToolTip = Resources.AdminViewImportExportImportButtonTip;
            import.Click += ImportDataClick;
            bloget.Controls.Add(import);

            EndSection();
        }

        protected override string RootClassId()
        {
            return "admin-view";
        }

        protected override void ShowView()
        {
            if (bloget.IsAdministrator == false)
            {
                PasswordView passwordForm = new PasswordView(bloget);
                passwordForm.Show();
                return;
            }

            bloget.Page.MaintainScrollPositionOnPostBack = true;
            MainMenu.ShowMenu(bloget);

            BasicInformationSection();
            SyndicationSection();
            AppearanceSection();
            CommentSection();
            NotificationsSection();
            ServicesSection();
            ImagesSection();
            ImportExportSection();

            ValidationSummary validationSummary = new ValidationSummary();
            validationSummary.HeaderText = Resources.AdminViewSummaryValidation;
            bloget.WriteLine("<p>");
            bloget.Controls.Add(validationSummary);
            bloget.WriteLine("</p>");

            save.Text = Text.ButtonPadding(Resources.AdminViewSaveButton);
            save.Click += SaveAdminClick;
            bloget.Controls.Add(save);
            bloget.WriteLine("&nbsp;");

            Button cancel = new Button();
            cancel.Text = Text.ButtonPadding(Resources.AdminViewDoneButton);
            cancel.Style.Add("color", "red");
            cancel.CausesValidation = false;
            cancel.Click +=
                delegate { bloget.Redirect(bloget.BuildQueryString(Mode.Blog, null, 0, null, null, default(DateTime), null)); };
            bloget.Controls.Add(cancel);

            bloget.Load += OnLoad;
        }

        void OnLoad(object sender, EventArgs ea)
        {
            bloget.Page.Form.DefaultButton = save.UniqueID;
            bloget.Load -= OnLoad;
        }

        static CustomValidator UrlValidator()
        {
            CustomValidator urlValidator = new CustomValidator();
            urlValidator.ServerValidate += UrlValidate;
            urlValidator.Text = " * ";
            return urlValidator;
        }

        static void UrlValidate(object sender, ServerValidateEventArgs ea)
        {
            // Empty is a valid string in this case.
            ea.IsValid = Uri.IsWellFormedUriString(ea.Value, UriKind.Absolute) ? true : string.IsNullOrEmpty(ea.Value);
        }

        static CustomValidator VirtualPathValidator()
        {
            CustomValidator virtualPathValidator = new CustomValidator();
            virtualPathValidator.ServerValidate += VirtualPathValidate;
            virtualPathValidator.Text = Resources.AdminViewVirtualPathValidator;
            virtualPathValidator.ToolTip = Resources.AdminViewVirtualPathValidatorTip;
            return virtualPathValidator;
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        static void VirtualPathValidate(object sender, ServerValidateEventArgs ea)
        {
            try
            {
                HostingEnvironment.MapPath(ea.Value);
                ea.IsValid = true;
            }

            catch (Exception)
            {
                ea.IsValid = false;
            }
        }

        internal static CustomValidator EmailValidator()
        {
            CustomValidator emailValidator = new CustomValidator();
            emailValidator.ServerValidate += EmailValidate;
            emailValidator.Text = " * ";
            return emailValidator;
        }

        static void EmailValidate(object sender, ServerValidateEventArgs ea)
        {
            // Empty string is valid
            ea.IsValid =
                Regex.IsMatch(
                    ea.Value,
                    @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
                    ? true
                    : string.IsNullOrEmpty(ea.Value);
        }

        static RangeValidator RangeValidator(string minimum, string maximum)
        {
            RangeValidator rangeValidator = new RangeValidator();
            rangeValidator.Type = ValidationDataType.Integer;
            rangeValidator.MinimumValue = minimum;
            rangeValidator.MaximumValue = maximum;
            rangeValidator.Text = string.Format(currentCulture, " ({0} - {1})", minimum, maximum);
            return rangeValidator;
        }

        [SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        void SaveAdminClick(object sender, EventArgs ea)
        {
            if (bloget.Page.IsValid == false)
            {
                return;
            }

            Blog blog = new Blog(bloget.Blog); // copy to protect readers

            if (blog.Title != title.Text)
            {
                Log.Administration(bloget, "Title", blog.Title, title.Text);
                blog.Title = title.Text;
            }

            if (blog.Description != description.Text)
            {
                Log.Administration(bloget, "Description", blog.Description, description.Text);
                blog.Description = description.Text;
            }

            if (blog.Link != link.Text)
            {
                Log.Administration(bloget, "Link", blog.Link, link.Text);
                blog.Link = link.Text;
            }

            if (blog.Language != language.Text)
            {
                Log.Administration(bloget, "Language", blog.Language, language.Text);
                blog.Language = language.Text;
            }

            if (blog.Copyright != copyright.Text)
            {
                Log.Administration(bloget, "Copyright", blog.Copyright, copyright.Text);
                blog.Copyright = copyright.Text;
            }

            if (blog.Webmaster != webMaster.Text)
            {
                Log.Administration(bloget, "Webmaster", blog.Webmaster, webMaster.Text);
                blog.Webmaster = webMaster.Text;
            }

            //if (blog.AuthorEmail != author.Text)
            //{
            //    Log.Administration(bloget, "Author", blog.AuthorEmail, author.Text);
            //    blog.AuthorEmail = author.Text;
            //}

            if (blog.RssChannelImage != rssChannelImage.Text)
            {
                Log.Administration(bloget, "RSS Channel Image", blog.RssChannelImage, rssChannelImage.Text);
                blog.RssChannelImage = rssChannelImage.Text;
            }

            if (blog.RssFooter != rssFooter.Text)
            {
                Log.Administration(bloget, "RSS Footer", blog.RssFooter, rssFooter.Text);
                blog.RssFooter = rssFooter.Text;
            }

            int itemsPerFeed = int.Parse(rssEntriesPerFeed.Text, currentCulture);

            if (blog.RssEntriesPerFeed != itemsPerFeed)
            {
                Log.Administration(bloget, "Rss entries per feed", blog.RssEntriesPerFeed.ToString(invariantCulture),
                                   itemsPerFeed.ToString(invariantCulture));
                blog.RssEntriesPerFeed = itemsPerFeed;
            }

            int itemsPerPageCount = int.Parse(itemsPerPage.Text, currentCulture);

            if (blog.PostsPerPage != itemsPerPageCount)
            {
                Log.Administration(bloget, "Items Per Page", blog.PostsPerPage.ToString(invariantCulture),
                                   itemsPerPageCount.ToString(invariantCulture));
                blog.PostsPerPage = itemsPerPageCount;
            }

            int selectedTimeZone = int.Parse(timeZone.SelectedValue, invariantCulture);

            if (blog.TimeZone != selectedTimeZone)
            {
                Log.Administration(bloget, "Timezone", blog.TimeZone.ToString(invariantCulture),
                                   selectedTimeZone.ToString(invariantCulture));
                blog.TimeZone = selectedTimeZone;
            }

            int width = int.Parse(editorWidth.Text, currentCulture);

            if (blog.EditorWidth != width)
            {
                Log.Administration(bloget, "Editor Width", blog.EditorWidth.ToString(invariantCulture),
                                   width.ToString(invariantCulture));
                blog.EditorWidth = width;
            }

            int height = int.Parse(editorHeight.Text, currentCulture);

            if (blog.EditorHeight != height)
            {
                Log.Administration(bloget, "Editor Height", blog.EditorHeight.ToString(invariantCulture),
                                   height.ToString(invariantCulture));
                blog.EditorHeight = height;
            }

            if (blog.AllowComments != allowComments.Checked)
            {
                Log.Administration(bloget, "Allow Comments", blog.AllowComments.ToString(invariantCulture),
                                   allowComments.Checked.ToString(invariantCulture));
                blog.AllowComments = allowComments.Checked;
            }

            int expireCommentsCount = int.Parse(expireComments.Text, currentCulture);

            if (blog.ExpireComments != expireCommentsCount)
            {
                Log.Administration(bloget, "Expire Comments", blog.ExpireComments.ToString(invariantCulture),
                                   expireCommentsCount.ToString(invariantCulture));
                blog.ExpireComments = expireCommentsCount;
            }

            int maximumCommentsCount = int.Parse(maximumComments.Text, currentCulture);

            if (blog.MaximumCommentsPerPost != maximumCommentsCount)
            {
                Log.Administration(bloget, "Maximum Comments Per Post",
                                   blog.MaximumCommentsPerPost.ToString(invariantCulture),
                                   maximumCommentsCount.ToString(invariantCulture));
                blog.MaximumCommentsPerPost = maximumCommentsCount;
            }

            if (blog.EmailComments != emailComments.Checked)
            {
                Log.Administration(bloget, "Email Comments", blog.EmailComments.ToString(invariantCulture),
                                   emailComments.Checked.ToString(invariantCulture));
                blog.EmailComments = emailComments.Checked;
            }

            if (blog.EmailPingbacks != emailPingbacks.Checked)
            {
                Log.Administration(bloget, "Email Pingbacks", blog.EmailPingbacks.ToString(invariantCulture),
                                   emailPingbacks.Checked.ToString(invariantCulture));
                blog.EmailPingbacks = emailPingbacks.Checked;
            }

            if (blog.EmailTo != emailTo.Text)
            {
                Log.Administration(bloget, "Email To", blog.EmailTo, emailTo.Text);
                blog.EmailTo = emailTo.Text;
            }

            if (blog.ImageFolder != imageFolder.Text)
            {
                Log.Administration(bloget, "Image Folder", blog.ImageFolder, imageFolder.Text);
                blog.ImageFolder = imageFolder.Text;
            }

            if (blog.ImageUrl != imageUrl.Text)
            {
                Log.Administration(bloget, "Image Url", blog.ImageUrl, imageUrl.Text);
                blog.ImageUrl = imageUrl.Text;
            }

            if (blog.EnableMetaWeblogApi != enableMetaWebLogApi.Checked)
            {
                Log.Administration(bloget, "MetaWebLogApi", blog.EnableMetaWeblogApi.ToString(invariantCulture),
                                   enableMetaWebLogApi.Checked.ToString(invariantCulture));
                blog.EnableMetaWeblogApi = enableMetaWebLogApi.Checked;
            }

            if (blog.EnableAutoPingBack != enableAutoPingBack.Checked)
            {
                Log.Administration(bloget, "Auto Pingback", blog.EnableAutoPingBack.ToString(invariantCulture),
                                   enableAutoPingBack.Checked.ToString(invariantCulture));
                blog.EnableAutoPingBack = enableAutoPingBack.Checked;
            }

            if (blog.EnablePingBackService != enablePingBackService.Checked)
            {
                Log.Administration(bloget, "Pingback Service", blog.EnablePingBackService.ToString(invariantCulture),
                                   enablePingBackService.Checked.ToString(invariantCulture));
                blog.EnablePingBackService = enablePingBackService.Checked;
            }

            if (blog.EnableRealSimpleDiscovery != enableRealSimpleDiscovery.Checked)
            {
                Log.Administration(bloget, "RSD", blog.EnableRealSimpleDiscovery.ToString(invariantCulture),
                                   enableRealSimpleDiscovery.Checked.ToString(invariantCulture));
                blog.EnableRealSimpleDiscovery = enableRealSimpleDiscovery.Checked;
            }

            int expirePingBacksCount = int.Parse(expirePingBacks.Text, currentCulture);

            if (blog.ExpirePingBacks != expirePingBacksCount)
            {
                Log.Administration(bloget, "Expire Pingbacks", blog.ExpirePingBacks.ToString(invariantCulture),
                                   expirePingBacksCount.ToString(invariantCulture));
                blog.ExpirePingBacks = expirePingBacksCount;
            }

            int maximumPingBacksCount = int.Parse(maximumPingBacks.Text, currentCulture);

            if (blog.MaximumPingsBacksPerPost != maximumPingBacksCount)
            {
                Log.Administration(bloget, "Maximum Pingbacks", blog.MaximumPingsBacksPerPost.ToString(invariantCulture),
                                   maximumPingBacksCount.ToString(invariantCulture));
                blog.MaximumPingsBacksPerPost = maximumPingBacksCount;
            }

            blog.Save();
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void SendTestEmailClick(object sender, EventArgs ea)
        {
            try
            {
                bloget.SendEmail(emailTo.Text, Resources.AdminViewTestEmailSubject,
                                 Resources.AdminViewTestEmailMessage);
            }

            catch (Exception ex)
            {
                Log.Exception(bloget, "SendTestEmailClick", ex);
                bloget.ErrorPage(ex.Message);
            }
        }

        void ExportDataClick(object sender, EventArgs ea)
        {
            Log.Administration(bloget, "Export", string.Empty, string.Empty);
            BackupData();
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        void ImportDataClick(object sender, EventArgs ea)
        {
            try
            {
                if (upload.HasFile)
                {
                    ImportBlog.Import(bloget.Blog, upload.FileContent);
                    Log.Administration(bloget, "Import", string.Empty, string.Empty);
                }
            }

            catch (Exception ex)
            {
                Log.Exception(bloget, "ImportDataClick", ex);
            }
        }

        void Section(string titleArg)
        {
            bloget.WriteLine(@"<fieldset class=""adminview-section"">");
            bloget.WriteLine("<legend>" + titleArg + "</legend>");
        }

        void EndSection()
        {
            bloget.WriteLine("</fieldset>");
        }

        void InputField(string textLabel,
                        TextBox textBox,
                        string text,
                        string tooltip,
                        bool required,
                        BaseValidator validator)
        {
            textBox.TextMode = TextBoxMode.SingleLine;
            textBox.MaxLength = MaxTextBoxLength;
            textBox.Style.Add(HtmlTextWriterStyle.Width, "25em");
            Input(textLabel, textBox, text, tooltip, required, validator);
        }

        void PasswordField(string textLabel,
                           TextBox textBox,
                           string text,
                           string tooltip,
                           bool required,
                           BaseValidator validator)
        {
            textBox.TextMode = TextBoxMode.Password;
            textBox.MaxLength = MaxPasswordLength;
            textBox.Style.Add(HtmlTextWriterStyle.Width, "10em");
            Input(textLabel, textBox, text, tooltip, required, validator);
        }

        void NumericField(string textLabel,
                          TextBox textBox,
                          string text,
                          string tooltip,
                          bool required,
                          BaseValidator validator)
        {
            textBox.TextMode = TextBoxMode.SingleLine;
            textBox.MaxLength = 8;
            textBox.Style.Add(HtmlTextWriterStyle.Width, "5em");
            Input(textLabel, textBox, text, tooltip, required, validator);
        }

        void TimeZoneField(ListControl dropDownList)
        {
            Label(Resources.AdminViewTimeZone, dropDownList.ID);

            foreach (int offset in Time.TimeOffsets())
            {
                dropDownList.Items.Add(new ListItem(offset.ToString(currentCulture), offset.ToString(currentCulture)));

                if (offset == bloget.Blog.TimeZone)
                {
                    dropDownList.SelectedIndex = (timeZone.Items.Count - 1);
                }
            }

            dropDownList.Style.Add(HtmlTextWriterStyle.Width, MaxPasswordLength.ToString(invariantCulture));
            bloget.Controls.Add(dropDownList);

            bloget.WriteLine(string.Format(currentCulture, Resources.AdminViewServerTime, DateTime.UtcNow.ToShortTimeString()));
            bloget.WriteLine("<br />");
        }

        void Input(string textLabel,
                   TextBox textBox,
                   string text,
                   string toolTip,
                   bool required,
                   BaseValidator validator)
        {
            Label(textLabel, textBox.ID);

            if (required)
            {
                RequiredTextBoxField(textBox, text, toolTip);
            }

            else
            {
                TextBoxField(textBox, text, toolTip);
            }

            if (validator != null)
            {
                validator.ControlToValidate = textBox.ID;
                bloget.Controls.Add(validator);
            }

            bloget.WriteLine("<br />");
        }

        void CheckBoxField(string textLabel,
                           CheckBox checkBox,
                           bool check,
                           string tooltip)
        {
            Label(textLabel, checkBox.ID);
            checkBox.Checked = check;
            checkBox.ToolTip = tooltip;
            bloget.Controls.Add(checkBox);
            bloget.WriteLine("<br />");
        }

        void BackupData()
        {
            using (XmlTextWriter xml = new XmlTextWriter(bloget.Page.Response.OutputStream, Encoding.UTF8))
            {
                xml.Formatting = Formatting.Indented;

                bloget.Page.Response.Clear();
                bloget.Page.Response.ContentType = "text/xml";

                string time = DateTime.UtcNow.ToString("s", invariantCulture);
                time = time.Replace(':', '-');
                string filename = Path.GetFileNameWithoutExtension(bloget.Blog.DataContext) + "-" + time + ".xml";
                bloget.Page.Response.AddHeader("Content-Disposition", "attachment;filename=" + filename);

                ExportBlog.Export(bloget.Blog, xml);
                bloget.Page.Response.Flush();
            }

            bloget.Page.Response.End();
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        title.Dispose();
                        description.Dispose();
                        link.Dispose();
                        firstName.Dispose();
                        lastName.Dispose();

                        language.Dispose();
                        copyright.Dispose();
                        webMaster.Dispose();
                        author.Dispose();
                        rssChannelImage.Dispose();
                        rssFooter.Dispose();
                        rssEntriesPerFeed.Dispose();

                        itemsPerPage.Dispose();
                        timeZone.Dispose();
                        editorWidth.Dispose();
                        editorHeight.Dispose();

                        allowComments.Dispose();
                        expireComments.Dispose();
                        maximumComments.Dispose();
                        maximumPingBacks.Dispose();

                        emailComments.Dispose();
                        emailPingbacks.Dispose();
                        emailTo.Dispose();
                        testEmail.Dispose();

                        enableRealSimpleDiscovery.Dispose();
                        enableMetaWebLogApi.Dispose();
                        enableAutoPingBack.Dispose();
                        enablePingBackService.Dispose();
                        expirePingBacks.Dispose();

                        imageFolder.Dispose();
                        imageUrl.Dispose();

                        upload.Dispose();
                        save.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }
    }
}