// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;
using System.Collections.Generic;

namespace BlueOnionSoftware.Bloget
{
    abstract class View : IDisposable
    {
        bool disposed;
        protected Bloget bloget;
        const int maxTextBoxLength = 256;
        const int maxPasswordLength = 30;
        List<Label> labels = new List<Label>();

        protected View(Bloget blogetArg)
        {
            Throw.IfNull(blogetArg, "blogetArg");
            bloget = blogetArg;
        }

        protected abstract void ShowView();
        protected abstract string RootClassId();

        internal void Show()
        {
            bool close = false;

            try
            {
                if (RootClassId() != null)
                {
                    bloget.WriteLine("<div class=\"" + RootClassId() + "\">");
                    close = true;
                }
                    
                ShowView();
            }

            finally
            {
                if (close)
                {
                    bloget.WriteLine("</div>");
                }
            }
        }

        protected void Label(string text, string id)
        {
            Throw.IfNull(text, "text");
            Throw.IfNull(id, "id");

            Label label = new Label();
            labels.Add(label);
            label.Text = text + "&nbsp;";
            label.CssClass = RootClassId() + "-label";
            label.ID = "label" + id;
            label.AssociatedControlID = id;
            bloget.Controls.Add(label);
        }

        static protected RequiredFieldValidator CreateRequiredFieldValidator(string id)
        {
            RequiredFieldValidator rfv = new RequiredFieldValidator();
            rfv.ID = "rfv" + id;
            rfv.ControlToValidate = id;
            rfv.EnableClientScript = true;
            rfv.Text = Text.ButtonPadding(Resources.PasswordViewValidatorText);
            return rfv;
        }

        protected void TextBoxField(TextBox textBox, string text, string toolTip)
        {
            Throw.IfNull(textBox, "textBox");
            Throw.IfNull(text, "text");
            Throw.IfNull(toolTip, "toolTip");

            textBox.Text = text;
            textBox.ToolTip = toolTip;
            textBox.MaxLength = maxTextBoxLength;
            textBox.CssClass = RootClassId() + "-input";
            bloget.Controls.Add(textBox);
        }

        protected void RequiredTextBoxField(TextBox textBox, string text, string toolTip)
        {
            TextBoxField(textBox, text, toolTip);
            bloget.Controls.Add(CreateRequiredFieldValidator(textBox.ID));
        }

        protected void PasswordField(TextBox textBox)
        {
            TextBoxField(textBox, string.Empty, string.Empty);
            textBox.TextMode = TextBoxMode.Password;
            textBox.MaxLength = maxPasswordLength;
        }

        protected void RequiredPasswordField(TextBox textBox)
        {
            PasswordField(textBox);
            bloget.Controls.Add(CreateRequiredFieldValidator(textBox.ID));
        }

        protected void SubmitButton(Button button, string text)
        {
            Throw.IfNull(button, "button");
            Throw.IfNullOrEmpty(text, "text");

            button.Text = Text.ButtonPadding(text);
            button.CssClass = RootClassId() + "-submit";
            bloget.Controls.Add(button);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        protected virtual void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        labels.ForEach(l => l.Dispose());
                    }
                }
            }

            finally
            {
                GC.SuppressFinalize(this);
            }
        }
    }
}