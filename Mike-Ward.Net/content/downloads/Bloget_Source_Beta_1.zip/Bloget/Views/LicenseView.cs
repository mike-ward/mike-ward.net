// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    class LicenseView : View
    {
        internal LicenseView(Bloget blogetArg)
            : base(blogetArg)
        {
        }

        protected override string RootClassId()
        {
            return "license-view";
        }

        protected override void ShowView()
        {
            bloget.WriteLine(Resources.LicenseAgreement);

            Button accept = new Button();
            accept.Text = Resources.LicenseViewAccept;
            accept.Click += AcceptClick;

            bloget.WriteLine("<p style=\"text-align:center\">");
            bloget.Controls.Add(accept);
            bloget.WriteLine("</p>");
        }

        void AcceptClick(object sender, EventArgs ea)
        {
            Blog blog = new Blog(bloget.Blog); // copy to protect readers
            blog.LicenseAgreement = true;
            Log.LicenseAgreementAccepted(bloget);
            blog.Save();
            bloget.Redirect(bloget.Page.Request.Path);
        }
    }
}