﻿// Copyright 2007 Blue Onion Software
// All rights reserved

using System;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    class ContactView : View
    {
        bool disposed;
        readonly TextBox name = new TextBox();
        readonly TextBox email = new TextBox();
        readonly TextBox message = new TextBox();
        readonly ConfirmedButton submit = new ConfirmedButton();
        BlogetContactForm contactForm;

        internal ContactView(BlogetContactForm blogetContactForm)
            : base(blogetContactForm)
        {
            name.ID = "name";
            email.ID = "email";
            message.ID = "message";
            submit.ID = "submit";
            contactForm = blogetContactForm;
        }

        protected override void Dispose(bool managed)
        {
            try
            {
                if (disposed == false)
                {
                    disposed = true;

                    if (managed)
                    {
                        name.Dispose();
                        email.Dispose();
                        message.Dispose();
                        submit.Dispose();
                    }
                }
            }

            finally
            {
                base.Dispose(managed);
            }
        }

        protected override string RootClassId()
        {
            return "blog-contact";
        }

        protected override void ShowView()
        {
            Label(Resources.ContactFormNameLabel, name.ID);
            RequiredTextBoxField(name, string.Empty, string.Empty);
            bloget.WriteLine("<br/>");

            Label(Resources.ContactFormEmailLabel, email.ID);
            RequiredTextBoxField(email, string.Empty, string.Empty);
            bloget.WriteLine("<br/>");

            Label(Resources.ContactFormMessageLabel, message.ID);
            message.MaxLength = 2048;
            message.TextMode = TextBoxMode.MultiLine;
            RequiredTextBoxField(message, string.Empty, string.Empty);
            bloget.WriteLine("<br/>");

            submit.Command += SubmitCommand;
            SubmitButton(submit, Resources.ContactFormSubmitLabel);
        }

        void SubmitCommand(object sender, CommandEventArgs e)
        {
            if (bloget.Page.IsValid)
            {
                string text = string.Format(Resources.ContactFormMessageFormat, name.Text, email.Text, message.Text, Environment.NewLine);
                bloget.SendEmail(bloget.Blog.Webmaster, contactForm.Subject ?? Resources.ContactFormMessageSubject, text);
                contactForm.MessageSent();
            }
        }
    }
}
