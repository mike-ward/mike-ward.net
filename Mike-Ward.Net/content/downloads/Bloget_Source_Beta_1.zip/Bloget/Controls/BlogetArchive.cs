// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.Design;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    /// <summary>
    /// The BlogetArchive control shows the months where a blog entry was made.
    /// It is a common element found most blog engines. While interesting, the
    /// index control is much more powerful and comprehensive.
    /// </summary>
    [Designer(typeof (BlogetArchiveDesigner))]
    public class BlogetArchive : Bloget
    {
        int length = 10;
        string more = "More...";
        ITemplate archiveTemplate;

        [Browsable(false)]
        [Description("Archive template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof (ArchiveContainerControl))]
        public ITemplate ArchiveTemplate
        {
            get { return archiveTemplate; }
            set { archiveTemplate = value; }
        }

        [Bindable(false)]
        [Category("Appearance")]
        [DefaultValue("10")]
        [Localizable(false)]
        public int Length
        {
            get { return length; }
            set { length = (value > 0) ? value : length; }
        }

        [Bindable(false)]
        [Category("Appearance")]
        [DefaultValue("10")]
        [Localizable(true)]
        public string More
        {
            get { return more; }
            set { more = value; }
        }

        protected override void CreateChildControls()
        {
            int count = length;

            if (archiveTemplate == null)
            {
                Controls.Add(new LiteralControl(@"<ul class=""bloget-archive-list"">"));
            }

            foreach (ArchiveDate archiveDate in Blog.ArchiveDates())
            {
                if (count-- <= 0)
                {
                    break;
                }

                if (archiveTemplate != null)
                {
                    ArchiveContainerControl archiveContainer = new ArchiveContainerControl(this, Blog, archiveDate);
                    archiveTemplate.InstantiateIn(archiveContainer);
                    Controls.Add(archiveContainer);
                }

                else
                {
                    Controls.Add(new LiteralControl("<li>"));
                    HyperLink link = new HyperLink();

                    link.Text = string.Format(CultureInfo.CurrentCulture, "{0} ({1})",
                                              archiveDate.Date.ToString("Y", CultureInfo.CurrentCulture),
                                              archiveDate.Count);

                    link.NavigateUrl = BuildQueryString(Mode.Blog, null, 0, null, null, archiveDate.Date, null);
                    Controls.Add(link);
                    Controls.Add(new LiteralControl("</li>" + Environment.NewLine));
                }
            }

            if (archiveTemplate == null)
            {
                if (string.IsNullOrEmpty(more) == false)
                {
                    Controls.Add(new LiteralControl("<li>"));
                    HyperLink link = new HyperLink();
                    link.Text = more;
                    link.NavigateUrl = BuildQueryString(Mode.Index, null, 0, null, null, DateTime.MinValue, null);
                    Controls.Add(link);
                    Controls.Add(new LiteralControl("</li>" + Environment.NewLine));
                }

                Controls.Add(new LiteralControl("</ul>" + Environment.NewLine));
            }
        }
    }

    /// <summary>
    /// ArchiveContainerControl defines what can be referenced in the Archive
    /// template
    /// </summary>
    public class ArchiveContainerControl : BlogContainerControl
    {
        readonly ArchiveDate archiveDate;

        public ArchiveContainerControl(Bloget bloget, Blog blog, ArchiveDate archiveDateArg)
            : base(bloget, blog)
        {
            archiveDate = archiveDateArg;
        }

        public DateTime ArchiveDate
        {
            get { return archiveDate.Date; }
        }

        public int ArchiveCount
        {
            get { return archiveDate.Count; }
        }

        public string ArchiveLink
        {
            get { return bloget.BuildQueryString(Mode.Blog, null, 0, null, null, archiveDate.Date, null); }
        }
    }

    class BlogetArchiveDesigner : ControlDesigner
    {
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            SetViewFlags(ViewFlags.TemplateEditing, true);
        }

        public override string GetDesignTimeHtml()
        {
            return "<span>" + Resources.ArchiveViewDesignTimeHtml + "</span>";
        }

        public override bool AllowResize
        {
            get { return true; }
        }

        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override TemplateGroupCollection TemplateGroups
        {
            get
            {
                TemplateGroupCollection collection = new TemplateGroupCollection();
                TemplateGroup group;
                TemplateDefinition template;
                Bloget control;

                control = (Bloget) Component;
                group = new TemplateGroup("Bloget");

                template = new TemplateDefinition(this, "ArchiveTemplate", control, "ArchiveTemplate", true);
                group.AddTemplateDefinition(template);

                collection.Add(group);
                return collection;
            }
        }
    }
}