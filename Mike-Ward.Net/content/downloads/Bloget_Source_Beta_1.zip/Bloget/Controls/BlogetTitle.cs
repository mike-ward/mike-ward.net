// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Web.UI.Design;

namespace BlueOnionSoftware.Bloget
{
    [Designer(typeof (BlogetBlogHeaderDesigner))]
    public class BlogetTitle : Bloget
    {
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        protected override void CreateChildControls()
        {
            if (TitleTemplate != null)
            {
                BlogContainerControl blogContainer = new BlogContainerControl(this, Blog);
                TitleTemplate.InstantiateIn(blogContainer);
                Controls.Add(blogContainer);
            }

            else
            {
                WriteLine(string.Format(CultureInfo.CurrentCulture, 
                    "<h1><a href=\"{0}\">{1}</a></h1><p>{2}</p>",
                    Page.Request.Path,
                    Blog.Title,
                    Blog.Description));
            }

            base.CreateChildControls();
        }
    }

    public class BlogHeaderContainerControl : BlogContainerControl
    {
        public BlogHeaderContainerControl(Bloget bloget, Blog blog)
            : base(bloget, blog)
        {
        }
    }

    class BlogetBlogHeaderDesigner : ControlDesigner
    {
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            SetViewFlags(ViewFlags.TemplateEditing, true);
        }

        public override string GetDesignTimeHtml()
        {
            return "<span>Sample Blog Header</span>";
        }

        public override bool AllowResize
        {
            get { return true; }
        }

        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override TemplateGroupCollection TemplateGroups
        {
            get
            {
                TemplateGroupCollection collection = new TemplateGroupCollection();
                TemplateGroup group;
                TemplateDefinition template;
                Bloget control;

                control = (Bloget) Component;
                group = new TemplateGroup("Bloget");

                template = new TemplateDefinition(this, "HeaderTemplate", control, "HeaderTemplate", true);
                group.AddTemplateDefinition(template);

                collection.Add(group);
                return collection;
            }
        }
    }
}