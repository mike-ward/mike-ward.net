// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.ComponentModel;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.Design;
using System.Diagnostics.CodeAnalysis;

namespace BlueOnionSoftware.Bloget
{
    [Designer(typeof(BlogetCategoryDesigner))]
    public class BlogetCategory : Bloget
    {
        private ITemplate categoryTemplate;

        [Browsable(false)]
        [Description("Category template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(CategoryContainerControl))]
        public ITemplate CategoryTemplate
        {
            get { return categoryTemplate; }
            set { categoryTemplate = value; }
        }

        protected override void CreateChildControls()
        {
            ShowCategories();
            base.CreateChildControls();
        }

        private void ShowCategories()
        {
            if (categoryTemplate == null)
            {
                Controls.Add(new LiteralControl(@"<ul class=""bloget-category-list"">"));
            }

            Mode linkMode = (Mode == Mode.Index) ? Mode.Index : Mode.Blog;

            Category allCategory = new Category();
            allCategory.Name = "All";
            allCategory.Id = -1;
            allCategory.Count = Blog.AllPostsCount;
            CategoryEntry(linkMode, allCategory);


            foreach (Category category in Blog.Categories.Sorted())
            {
                CategoryEntry(linkMode, category);
            }

            if (categoryTemplate == null)
            {
                Controls.Add(new LiteralControl("</ul>" + Environment.NewLine));
            }
        }

        private void CategoryEntry(Mode linkMode, Category category)
        {
            if (categoryTemplate != null)
            {
                CategoryContainerControl categoryContainer = new CategoryContainerControl(this, Blog, category);
                categoryTemplate.InstantiateIn(categoryContainer);
                Controls.Add(categoryContainer);
            }

            else
            {
                Controls.Add(new LiteralControl("<li>"));
                string format = "{0} ({1})";
                HyperLink link = new HyperLink();
                link.Text = string.Format(CultureInfo.CurrentCulture, format, category.Name, category.Count);
                link.NavigateUrl = BuildQueryString(linkMode, null, 0, category, null, DateTime.MinValue, null);
                Controls.Add(link);
                Controls.Add(new LiteralControl("</li>" + Environment.NewLine));
            }
        }
    }

    internal class BlogetCategoryDesigner : ControlDesigner
    {
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            SetViewFlags(ViewFlags.TemplateEditing, true);
        }

        public override string GetDesignTimeHtml()
        {
            return "<span>Sample Category</span>";
        }

        public override bool AllowResize
        {
            get { return true; }
        }

        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override TemplateGroupCollection TemplateGroups
        {
            get
            {
                TemplateGroupCollection collection = new TemplateGroupCollection();
                TemplateGroup group;
                TemplateDefinition template;
                Bloget control;

                control = (Bloget)Component;
                group = new TemplateGroup("Bloget");

                template = new TemplateDefinition(this, "CategoryTemplate", control, "CategoryTemplate", true);
                group.AddTemplateDefinition(template);

                collection.Add(group);
                return collection;
            }
        }
    }

    /// <summary>
    /// CategoryContainerControl defines what can be referenced in the Category template
    /// </summary>
    public class CategoryContainerControl : BlogContainerControl
    {
        readonly Category category;

        public CategoryContainerControl(Bloget bloget, Blog blog, Category category)
            : base(bloget, blog)
        {
            this.category = category;
        }

        public string CategoryName
        {
            get { return category.Name; }
        }

        public int CategoryId
        {
            get { return category.Id; }
        }

        public int CategoryCount
        {
            get { return category.Count; }
        }
    }
}
