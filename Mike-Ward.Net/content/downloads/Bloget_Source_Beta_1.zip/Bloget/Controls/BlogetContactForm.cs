﻿// Copyright 2007 Blue Onion Software
// All rights reserved

using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Web.UI.Design;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    [Designer(typeof(BlogetContactFormDesigner))]
    public class BlogetContactForm : Bloget
    {
        public string Subject { get; set; }
        public string SuccessUrl { get; set; }

        protected override void CreateChildControls()
        {
            ContactView contactView = new ContactView(this);
            contactView.Show();
            base.CreateChildControls();
        }

        internal void MessageSent()
        {
            Redirect(SuccessUrl ?? Blog.Link);
        }
    }

    class BlogetContactFormDesigner : ControlDesigner
    {
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            SetViewFlags(ViewFlags.TemplateEditing, false);
        }

        public override string GetDesignTimeHtml()
        {
            return "<span>" + Resources.ContactFormDesignTimeHtml + "</span>";
        }

        public override bool AllowResize
        {
            get { return true; }
        }
    }
}
