// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Web.UI.Design;

namespace BlueOnionSoftware.Bloget
{
    class BlogetDesigner : ControlDesigner
    {
        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            SetViewFlags(ViewFlags.TemplateEditing, true);
        }

        public override string GetDesignTimeHtml()
        {
            return
                "<span>Sample blog content. Visit http://blueonionsoftware.com/Bloget.aspx for more information about Bloget.</span>";
        }

        public override bool AllowResize
        {
            get { return true; }
        }

        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override TemplateGroupCollection TemplateGroups
        {
            get
            {
                TemplateGroupCollection collection = new TemplateGroupCollection();
                TemplateGroup group;
                TemplateDefinition template;
                Bloget control;

                control = (Bloget) Component;
                group = new TemplateGroup("Bloget");

                template = new TemplateDefinition(this, "HeaderTemplate", control, "HeaderTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "FooterTemplate", control, "FooterTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "PostTemplate", control, "PostTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "PostSeparatorTemplate", control, "PostSeparatorTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "CommentHeaderTemplate", control, "CommentHeaderTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "CommentTemplate", control, "CommentTemplate", true);
                group.AddTemplateDefinition(template);

                template =
                    new TemplateDefinition(this, "PingBackHeaderTemplate", control, "PingBackHeaderTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "PingBackTemplate", control, "PingBackTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "IndexHeaderTemplate", control, "IndexHeaderTemplate", true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "IndexTemplate", control, "IndexTemplate", true);
                group.AddTemplateDefinition(template);

                template =
                    new TemplateDefinition(this, "IndexMonthSeparatorTemplate", control, "IndexMonthSeparatorTemplate",
                                           true);
                group.AddTemplateDefinition(template);

                template =
                    new TemplateDefinition(this, "IndexYearSeparatorTemplate", control, "IndexYearSeparatorTemplate",
                                           true);
                group.AddTemplateDefinition(template);

                template = new TemplateDefinition(this, "IndexFooterTemplate", control, "IndexFooterTemplate", true);
                group.AddTemplateDefinition(template);

                collection.Add(group);
                return collection;
            }
        }
    }
}