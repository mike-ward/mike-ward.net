// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Net.Mail;
using System.Security.Permissions;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    [AspNetHostingPermission(SecurityAction.Demand, Level = AspNetHostingPermissionLevel.Minimal)]
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    [SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces"), DefaultProperty("DataFile")]
    abstract public class Bloget : CompositeControl
    {
        string dataContext;
        Mode showOnly;
        string prefix;

        Blog blog;
        Mode mode;

        string queryPost;
        int queryStart;
        Category queryCategory;
        string querySort;
        DateTime queryDate;

        internal const string AdministratorRole = "BlogAdministrator";
        internal const string AuthorRole = "BlogAuthor";

        ITemplate titleTemplate;
        ITemplate footerTemplate;
        ITemplate postTemplate;
        ITemplate postSeparatorTemplate;
        ITemplate commentHeaderTemplate;
        ITemplate commentTemplate;
        ITemplate pingBackHeaderTemplate;
        ITemplate pingBackTemplate;

        ITemplate indexHeaderTemplate;
        ITemplate indexTemplate;
        ITemplate indexMonthSeparatorTemplate;
        ITemplate indexYearSeparatorTemplate;
        ITemplate indexFooterTemplate;

        ITemplate searchTemplate;
        ITemplate searchResultsTemplate;

        ITemplate rssContentTemplate;

        [SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "System.DateTime.TryParse(System.String,System.DateTime@)"), SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [SuppressMessage("Microsoft.Security", "CA2109:ReviewVisibleEventHandlers", MessageId = "0#")]
        protected override void OnInit(EventArgs e)
        {
            if (string.IsNullOrEmpty(DataContext))
            {
                ErrorPage("No DataFile Specified");
                return;
            }

            EnableViewState = false;

            try
            {
                string path = Page.MapPath(DataContext);
                blog = Blog.Load(path);
            }

            catch (Exception ex)
            {
                ErrorPage(ex.ToString());
                return;
            }

            queryPost = Page.Request[BlogPostParameter] ?? string.Empty;

            if (int.TryParse((Page.Request[BlogStartParameter] ?? "0"), out queryStart) == false)
            {
                queryStart = 0;
            }

            queryCategory = CategoryFromIdString(Page.Request[BlogCategoryParameter]);
            querySort = Page.Request[BlogSortParameter] ?? string.Empty;
            querySort = Page.Server.HtmlDecode(querySort);
            DateTime.TryParse(Page.Request[BlogDateParameter], out queryDate);
            mode = string.IsNullOrEmpty(queryPost) ? Mode.Blog : Mode.Post;
            string modeParameter = Page.Request[BlogModeParameter];

            if (string.IsNullOrEmpty(modeParameter) == false)
            {
                try
                {
                    mode = (Mode)Enum.Parse(typeof(Mode), modeParameter, true);
                }

                catch (ArgumentException)
                {
                    mode = Mode.Blog;
                }
            }

            if (ShowOnly != Mode.None)
            {
                mode = ShowOnly;
            }

            if (blog.LicenseAgreement == false)
            {
                mode = Mode.LicenseAgreement;
            }

            DataBind();
            base.OnInit(e);
        }

        [Bindable(false)]
        [Category("Data")]
        [DefaultValue("")]
        [Localizable(false)]
        public string DataContext
        {
            get { return dataContext ?? string.Empty; }
            set { dataContext = value; }
        }

        [Bindable(false)]
        [Category("Behavior")]
        [DefaultValue("Mode.None")]
        [Localizable(false)]
        public Mode ShowOnly
        {
            get { return showOnly; }
            set { showOnly = value; }
        }

        [Bindable(false)]
        [Category("Behavior")]
        [Localizable(false)]
        public string Prefix
        {
            get { return prefix ?? string.Empty; }
            set { prefix = value; }
        }

        [Bindable(false)]
        [Browsable(false)]
        public MembershipUser GetUser()
        {
            return Membership.GetUser();
        }

        [Bindable(false)]
        [Browsable(false)]
        public bool IsLoggedIn
        {
            get { return (GetUser() != null); }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal bool IsAdministrator
        {
            get
            {
                MembershipUser user = GetUser();
                return (user != null) ? Roles.IsUserInRole(AdministratorRole) : false;
            }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal bool IsAuthor
        {
            get
            {
                MembershipUser user = GetUser();
                return (user != null) ? Roles.IsUserInRole(AuthorRole) : false;
            }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal bool IsAuthorOrAdministrator
        {
            get
            {
                return IsAuthor || IsAdministrator;
            }
        }

        static internal bool IsUserAdministrator(MembershipUser user)
        {
            return Roles.IsUserInRole(user.UserName, AdministratorRole);
        }

        static internal bool IsUserAuthor(MembershipUser user)
        {
            return Roles.IsUserInRole(user.UserName, AuthorRole);
        }

        internal MembershipUserCollection GetAllUsers()
        {
            return Membership.GetAllUsers();
        }

        [Bindable(false)]
        [Browsable(false)]
        public string BlogTitle
        {
            get { return blog.Title; }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal Blog Blog
        {
            get { return blog; }
        }

        [Bindable(false)]
        [Browsable(false)]
        public Mode Mode
        {
            get { return mode; }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal string QueryPost
        {
            get { return queryPost; }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal int QueryStart
        {
            get { return queryStart; }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal Category QueryCategory
        {
            get { return queryCategory; }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal string QuerySort
        {
            get { return querySort ?? string.Empty; }
        }

        [Bindable(false)]
        [Browsable(false)]
        internal DateTime QueryDate
        {
            get { return queryDate; }
        }

        internal void PoweredByBloget()
        {
            string tagline = string.Format(CultureInfo.CurrentCulture,
                                           "<p style=\"font-size:x-small; text-align:center\">{0} " +
                                           "<a href=\"http://blueonionsoftware.com/Bloget.aspx\">{1}&trade;</a></p>",
                                           Resources.PoweredBy, Resources.BlogetTitle);

            Controls.Add(new LiteralControl(tagline));
        }

        internal void ErrorPage(string error)
        {
            mode = Mode.None;
            ChildControlsCreated = true;
            Controls.Add(new LiteralControl("<p>" + error + "</p>"));
        }

        internal string BlogModeParameter
        {
            get { return Prefix + "m"; }
        }

        internal string BlogPostParameter
        {
            get { return Prefix + "p"; }
        }

        internal string BlogStartParameter
        {
            get { return Prefix + "s"; }
        }

        internal string BlogCategoryParameter
        {
            get { return Prefix + "c"; }
        }

        internal string BlogSortParameter
        {
            get { return Prefix + "o"; }
        }

        internal string BlogDateParameter
        {
            get { return Prefix + "d"; }
        }

        internal string BlogSearchParameter
        {
            get { return Prefix + "f"; }
        }

        internal string BlogUserParameter
        {
            get { return Prefix + "u"; }
        }

        internal string BuildQueryString(Mode modeArg)
        {
            return BuildQueryString(modeArg, null, 0, null, null, default(DateTime), null);
        }

        [SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
        internal string BuildQueryString(Mode modeArg,
                                         Post post,
                                         int start,
                                         Category category,
                                         string sortExpression,
                                         DateTime date,
                                         string userName)
        {
            string link = Page.Request.Url.ToString();
            int offset = link.IndexOf('?');

            if (offset != -1)
            {
                link = link.Substring(0, offset);
            }

            StringBuilder query = new StringBuilder();
            string argSeparator = "?";

            query.Append(link);

            if (post != null)
            {
                query.Append(argSeparator);
                query.Append(BlogPostParameter);
                query.Append("=");
                query.Append(post.Id.ToString());
                argSeparator = "&";
            }

            if (modeArg != Mode.Blog && modeArg != Mode.Post)
            {
                query.Append(argSeparator);
                query.Append(BlogModeParameter);
                query.Append("=");
                query.Append(modeArg.ToString().ToLowerInvariant());
                argSeparator = "&";
            }

            if (start != 0)
            {
                query.Append(argSeparator);
                query.Append(BlogStartParameter);
                query.Append("=");
                query.Append(start.ToString(CultureInfo.InvariantCulture));
                argSeparator = "&";
            }

            if (category != null)
            {
                query.Append(argSeparator);
                query.Append(BlogCategoryParameter);
                query.Append("=");
                query.Append(category.Id.ToString(CultureInfo.InvariantCulture));
                argSeparator = "&";
            }

            if (string.IsNullOrEmpty(sortExpression) == false)
            {
                query.Append(argSeparator);
                query.Append(BlogSortParameter);
                query.Append("=");
                query.Append(Page.Server.UrlEncode(sortExpression));
                argSeparator = "&";
            }

            if (string.IsNullOrEmpty(userName) == false)
            {
                query.Append(argSeparator);
                query.Append(BlogUserParameter);
                query.Append("=");
                query.Append(Page.Server.UrlEncode(userName));
                argSeparator = "&";
            }

            if (date != default(DateTime))
            {
                query.Append(argSeparator);
                query.Append(BlogDateParameter);
                query.Append("=");
                query.Append(date.ToString("MM/yyyy", CultureInfo.InvariantCulture));
                argSeparator = "&";
            }

            // Propagate other query parameters
            foreach (string key in Page.Request.QueryString)
            {
                if (string.CompareOrdinal(key, BlogModeParameter) == 0 ||
                    string.CompareOrdinal(key, BlogPostParameter) == 0 ||
                    string.CompareOrdinal(key, BlogStartParameter) == 0 ||
                    string.CompareOrdinal(key, BlogCategoryParameter) == 0 ||
                    string.CompareOrdinal(key, BlogSortParameter) == 0 ||
                    string.CompareOrdinal(key, BlogDateParameter) == 0 ||
                    string.CompareOrdinal(key, BlogUserParameter) == 0)
                {
                    continue;
                }

                query.Append(argSeparator);
                query.Append(key);
                query.Append("=");
                query.Append(Page.Request.QueryString[key]);
                argSeparator = "&";
            }

            return query.ToString();
        }

        internal string PermaLink(Post post)
        {
            return string.Format(CultureInfo.InvariantCulture, "{0}?{1}={2}",
                                 blog.Link, BlogPostParameter, post.Id);
        }

        internal string RpcServiceUrl()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0}?{1}={2}",
                                 blog.Link, BlogModeParameter, Mode.Rpc);
        }

        Category CategoryFromIdString(string id)
        {
            int categoryId;
            Category category = null;

            if (int.TryParse(id, out categoryId))
            {
                if (blog.Categories.Contains(categoryId))
                {
                    category = blog.Categories[categoryId];
                }
            }

            return category;
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        internal void SendEmail(string to, string subject, string message)
        {
            using (MailMessage mailMessage = new MailMessage())
            {
                try
                {
                    mailMessage.To.Add(new MailAddress(to));
                    mailMessage.Subject = subject;
                    mailMessage.Body = message;
                    
                    SmtpClient smtp = new SmtpClient();
                    smtp.Send(mailMessage);
                    Log.EmailSent(this, mailMessage.From.Address, to, subject);
                }

                catch (Exception ex)
                {
                    Log.Exception(this, "SendEmail", ex);
                }
            }
        }

        internal HyperLink[] RelatedPosts(Post post, int maxPosts)
        {
            List<string> tags = new List<string>();

            foreach (int tagInt in post.Tags)
            {
                if (blog.Categories.Contains(tagInt))
                {
                    tags.Add(blog.Categories[tagInt].Name);
                }
            }

            StringBuilder query = new StringBuilder();

            foreach (string tag in tags)
            {
                const string space = " ";
                query.Append(tag);
                query.Append(space);
            }

            Post[] posts = Search.Find(this, query.Append(post.Title).ToString());
            List<HyperLink> links = new List<HyperLink>();

            foreach (Post matchingPost in posts)
            {
                if (matchingPost != post)
                {
                    HyperLink link = new HyperLink();
                    link.Text = matchingPost.Title;
                    link.NavigateUrl = BuildQueryString(Mode.Post, matchingPost, 0, null, null, default(DateTime), null);
                    links.Add(link);
                }

                if (--maxPosts < 0)
                {
                    break;
                }
            }

            return links.ToArray();
        }

        internal void Redirect(string redirectUrl)
        {
            redirectUrl = Page.Response.ApplyAppPathModifier(redirectUrl);
            Page.Response.Redirect(redirectUrl, true);
        }

        internal void Write(string html)
        {
            Throw.IfNull(html, "html");
            Controls.Add(new LiteralControl(html));
        }

        internal void WriteLine(string html)
        {
            Throw.IfNull(html, "html");
            Controls.Add(new LiteralControl(html + Environment.NewLine));
        }

        [Browsable(false)]
        [Description("Header template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(BlogContainerControl))]
        public ITemplate TitleTemplate
        {
            get { return titleTemplate; }
            set { titleTemplate = value; }
        }

        [Browsable(false)]
        [Description("Footer template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(BlogContainerControl))]
        public ITemplate FooterTemplate
        {
            get { return footerTemplate; }
            set { footerTemplate = value; }
        }

        [Browsable(false)]
        [Description("Post template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(PostContainerControl))]
        public ITemplate PostTemplate
        {
            get { return postTemplate; }
            set { postTemplate = value; }
        }

        [Browsable(false)]
        [Description("Post separator template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(PostContainerControl))]
        public ITemplate PostSeparatorTemplate
        {
            get { return postSeparatorTemplate; }
            set { postSeparatorTemplate = value; }
        }

        [Browsable(false)]
        [Description("Comment header template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(PostContainerControl))]
        public ITemplate CommentHeaderTemplate
        {
            get { return commentHeaderTemplate; }
            set { commentHeaderTemplate = value; }
        }

        [Browsable(false)]
        [Description("Comment template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(CommentContainerControl))]
        public ITemplate CommentTemplate
        {
            get { return commentTemplate; }
            set { commentTemplate = value; }
        }

        [Browsable(false)]
        [Description("Pingback header template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(PostContainerControl))]
        public ITemplate PingBackHeaderTemplate
        {
            get { return pingBackHeaderTemplate; }
            set { pingBackHeaderTemplate = value; }
        }

        [Browsable(false)]
        [Description("Pingback template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(PingBackContainerControl))]
        public ITemplate PingBackTemplate
        {
            get { return pingBackTemplate; }
            set { pingBackTemplate = value; }
        }

        [Browsable(false)]
        [Description("Index header template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(IndexContainerControl))]
        public ITemplate IndexHeaderTemplate
        {
            get { return indexHeaderTemplate; }
            set { indexHeaderTemplate = value; }
        }

        [Browsable(false)]
        [Description("Index template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(IndexContainerControl))]
        public ITemplate IndexTemplate
        {
            get { return indexTemplate; }
            set { indexTemplate = value; }
        }

        [Browsable(false)]
        [Description("Index month template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(IndexContainerControl))]
        public ITemplate IndexMonthSeparatorTemplate
        {
            get { return indexMonthSeparatorTemplate; }
            set { indexMonthSeparatorTemplate = value; }
        }

        [Browsable(false)]
        [Description("Index year template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(IndexContainerControl))]
        public ITemplate IndexYearSeparatorTemplate
        {
            get { return indexYearSeparatorTemplate; }
            set { indexYearSeparatorTemplate = value; }
        }

        [Browsable(false)]
        [Description("Index footer template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(IndexContainerControl))]
        public ITemplate IndexFooterTemplate
        {
            get { return indexFooterTemplate; }
            set { indexFooterTemplate = value; }
        }

        [Browsable(false)]
        [Description("RSS content template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(PostContainerControl))]
        public ITemplate RssContentTemplate
        {
            get { return rssContentTemplate; }
            set { rssContentTemplate = value; }
        }

        [Browsable(false)]
        [Description("Search template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(BlogContainerControl))]
        public ITemplate SearchTemplate
        {
            get { return searchTemplate; }
            set { searchTemplate = value; }
        }

        [Browsable(false)]
        [Description("Search results template")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [TemplateContainer(typeof(PostContainerControl))]
        public ITemplate SearchResultsTemplate
        {
            get { return searchResultsTemplate; }
            set { searchResultsTemplate = value; }
        }
    }
}