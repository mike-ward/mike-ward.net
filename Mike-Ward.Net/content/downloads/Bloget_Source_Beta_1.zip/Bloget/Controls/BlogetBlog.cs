﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.ComponentModel;
using System.Web.UI;

namespace BlueOnionSoftware.Bloget
{
    public enum Mode
    {
        None,
        Blog,
        Post,
        Edit,
        Admin,
        Index,
        Drafts,
        LicenseAgreement,
        LogOn,
        LogOff,
        Log,
        Rss,
        Rpc,
        Search,
        Categories,
        Users,
        EditUser
    }

    [Designer(typeof(BlogetDesigner))]
    [ToolboxData("<{0}:Bloget runat=\"server\" DataFile=\"filename\"></{0}:Bloget>")]
    public class BlogetBlog : Bloget
    {
        protected override void CreateChildControls()
        {
            CreateView(this, Mode).Show();
            base.CreateChildControls();
        }

        static View CreateView(BlogetBlog blogetBlog, Mode mode)
        {
            switch (mode)
            {
                case Mode.LicenseAgreement:
                    return new LicenseView(blogetBlog);

                case Mode.Blog:
                    return (blogetBlog.QueryDate == DateTime.MinValue)
                               ? new BlogView(blogetBlog)
                               : new PostsByMonthView(blogetBlog);

                case Mode.Post:
                    return new PostView(blogetBlog);

                case Mode.Edit:
                    return new EditView(blogetBlog);

                case Mode.Admin:
                    return new AdminView(blogetBlog);

                case Mode.Index:
                    return new IndexView(blogetBlog);

                case Mode.Drafts:
                    return new DraftsView(blogetBlog);

                case Mode.Log:
                    return new LogView(blogetBlog);

                case Mode.LogOn:
                    return new PasswordView(blogetBlog);

                case Mode.LogOff:
                    Log.Logout(blogetBlog);
                    blogetBlog.Page.Response.Clear();
                    System.Web.Security.FormsAuthentication.SignOut();
                    blogetBlog.Redirect(blogetBlog.BuildQueryString(Mode.Blog));
                    return new BlogView(blogetBlog);

                case Mode.Rss:
                    return new RssView(blogetBlog);

                case Mode.Rpc:
                    return new RpcView(blogetBlog);

                case Mode.Search:
                    return new SearchView(blogetBlog);

                case Mode.Categories:
                    return new CategoriesView(blogetBlog);

                case Mode.Users:
                    return new UsersView(blogetBlog);

                case Mode.EditUser:
                    return new EditUserView(blogetBlog);

                default:
                    return new BlogView(blogetBlog);
            }
        }
    }
}
