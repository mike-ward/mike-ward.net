// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Web.UI.Design;
using System.Web.UI.WebControls;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    [Designer(typeof (BlogetSearchDesigner))]
    public class BlogetSearch : Bloget
    {
        readonly TextBox textBox = new TextBox();
        readonly Button submit = new Button();
        const int maxFindLength = 30;
        const string textBoxID = "search_textbox";

        protected override void CreateChildControls()
        {
            const string space = " ";
            textBox.ID = textBoxID;
            textBox.MaxLength = maxFindLength;
            textBox.Text = QuerySort;
            textBox.TextChanged += GetSearchClick;
            Controls.Add(textBox);

            Write(space);

            submit.Click += GetSearchClick;
            submit.Text = Text.ButtonPadding(Resources.SearchFindButton);
            Controls.Add(submit);

            base.CreateChildControls();
        }

        void GetSearchClick(object sender, EventArgs ea)
        {
            string query = BuildQueryString(Mode.Search, null, 0, null, textBox.Text, default(DateTime), null);
            Redirect(query);
        }
    }

    class BlogetSearchDesigner : BlogetDesigner
    {
        public override string GetDesignTimeHtml()
        {
            return @"<input type=""text"" /> <input type=""button"" name="" Find "" />";
        }

        [SuppressMessage("Microsoft.Security", "CA2116:AptcaMethodsShouldOnlyCallAptcaMethods")]
        public override TemplateGroupCollection TemplateGroups
        {
            get
            {
                TemplateGroupCollection collection = new TemplateGroupCollection();
                TemplateGroup group;
                TemplateDefinition template;
                Bloget control;

                control = (Bloget) Component;
                group = new TemplateGroup("Bloget");

                template = new TemplateDefinition(this, "IndexTemplate", control, "IndexTemplate", true);
                group.AddTemplateDefinition(template);

                collection.Add(group);
                return collection;
            }
        }
    }
}