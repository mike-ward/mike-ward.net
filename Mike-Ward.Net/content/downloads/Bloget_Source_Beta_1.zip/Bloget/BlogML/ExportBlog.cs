// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Web.Hosting;
using System.Xml;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget
{
    static class ExportBlog
    {
        internal static void Export(Blog blog, XmlTextWriter stream)
        {
            if (blog == null)
            {
                throw new ArgumentException("ExportBlog(blog)");
            }

            if (stream == null)
            {
                throw new ArgumentException("ExportBlog(stream)");
            }

            blogType blogML = new blogType();

            blogML.title = CreateTitleType(blog.Title);
            blogML.subtitle = CreateTitleType(blog.Description);
            blogML.rooturl = blog.Link;
            blogML.datecreated = DateTime.UtcNow;

            //blogML.authors = new authorType[] {CreateAuthorType(blog.Author, blog.AuthorEmail)};
            blogML.extendedproperties = CreateExtendedProperties(blog);
            blogML.categories = CreateCategories(blog);
            blogML.posts = CreatePosts(blog);

            XmlSerializer serializer = new XmlSerializer(typeof (blogType));
            serializer.Serialize(stream, blogML);
            stream.Flush();
        }

        static titleType CreateTitleType(string text)
        {
            titleType title = new titleType();
            string[] textArray = new string[] {text};
            title.Text = textArray;
            title.type = contentTypes.text;
            return title;
        }

        static authorType CreateAuthorType(string name, string email)
        {
            authorType author = new authorType();
            InitializeNodeType(author, "0", name);
            author.email = email;
            return author;
        }

        static void InitializeNodeType(nodeType node, string id, string title)
        {
            node.id = id;
            node.title = CreateTitleType(title);
            node.approved = true;
            node.datecreated = DateTime.UtcNow;
            node.datecreatedSpecified = false;
            node.datemodified = DateTime.UtcNow;
            node.datemodifiedSpecified = false;
        }

        static extendedpropertyType[] CreateExtendedProperties(Blog blog)
        {
            List<extendedpropertyType> extendedProperties = new List<extendedpropertyType>();
            CultureInfo cultureInfo = CultureInfo.InvariantCulture;

            extendedProperties.Add(ExtendedProperty("accepted_license", blog.LicenseAgreement.ToString(cultureInfo)));
            //extendedProperties.Add(ExtendedProperty("author_first_name", blog.FirstName));
            //extendedProperties.Add(ExtendedProperty("author_last_name", blog.LastName));
            extendedProperties.Add(ExtendedProperty("language", blog.Language));
            extendedProperties.Add(ExtendedProperty("copyright", blog.Copyright));
            extendedProperties.Add(ExtendedProperty("webmaster", blog.Webmaster));
            //extendedProperties.Add(ExtendedProperty("author_email", blog.AuthorEmail));
            extendedProperties.Add(ExtendedProperty("rss_image", blog.RssChannelImage));
            extendedProperties.Add(ExtendedProperty("rss_footer", blog.RssFooter));
            extendedProperties.Add(ExtendedProperty("rss_entries_per_feed", blog.RssEntriesPerFeed.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("posts_per_page", blog.PostsPerPage.ToString(cultureInfo)));
            //extendedProperties.Add(ExtendedProperty("password", blog.Password));
            //extendedProperties.Add(ExtendedProperty("salt", blog.Salt));
            extendedProperties.Add(ExtendedProperty("allow_comments", blog.AllowComments.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("max_comments_per_post", blog.MaximumCommentsPerPost.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("expire_comments", blog.ExpireComments.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("email_comments", blog.EmailComments.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("email_pingbacks", blog.EmailPingbacks.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("email_to", blog.EmailTo));
            //extendedProperties.Add(ExtendedProperty("email_host", blog.EmailHost));
            //extendedProperties.Add(ExtendedProperty("email_port", blog.EmailPort.ToString(cultureInfo)));
            //extendedProperties.Add(ExtendedProperty("email_authorize", blog.EmailAuthorization.ToString(cultureInfo)));
            //extendedProperties.Add(ExtendedProperty("email_username", blog.EmailUserName));
            //extendedProperties.Add(ExtendedProperty("email_password", blog.EmailPassword));
            extendedProperties.Add(ExtendedProperty("image_folder", blog.ImageFolder));
            extendedProperties.Add(ExtendedProperty("image_url", blog.ImageUrl));
            extendedProperties.Add(ExtendedProperty("enable_megaweblogapi", blog.EnableMetaWeblogApi.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("enable_rsd", blog.EnableRealSimpleDiscovery.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("enable_auto_pingback", blog.EnableAutoPingBack.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("enable_pingback_service", blog.EnablePingBackService.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("expire_pingbacks", blog.ExpirePingBacks.ToString(cultureInfo)));
            extendedProperties.Add(ExtendedProperty("maximum_pingbacks_per_post", blog.MaximumPingsBacksPerPost.ToString(cultureInfo)));

            return extendedProperties.ToArray();
        }

        static extendedpropertyType ExtendedProperty(string name, string value)
        {
            extendedpropertyType extendedProperty = new extendedpropertyType();
            extendedProperty.name = name;
            extendedProperty.value = value;
            return extendedProperty;
        }

        static categoryType[] CreateCategories(Blog blog)
        {
            List<categoryType> categories = new List<categoryType>();

            foreach (Category category in blog.Categories)
            {
                categories.Add(CreateCategory(category.Id, category.Name));
            }

            return categories.ToArray();
        }

        static categoryType CreateCategory(int id, string name)
        {
            categoryType category = new categoryType();
            InitializeNodeType(category, id.ToString(CultureInfo.InvariantCulture), name);
            category.parentref = "0";
            category.description = name;
            return category;
        }

        static postType[] CreatePosts(Blog blog)
        {
            List<postType> posts = new List<postType>();

            foreach (Post post in blog.Posts)
            {
                posts.Add(CreatePost(post, blog.LoadContent(post.Id)));
            }

            return posts.ToArray();
        }

        static postType CreatePost(Post post, Content content)
        {
            postType postML = new postType();
            InitializeNodeType(postML, post.Id.ToString(), post.Title);

            postML.datecreated = post.Created;
            postML.datecreatedSpecified = true;
            postML.approved = !post.Draft;
            postML.posturl = string.Empty;
            postML.type = blogpostTypes.normal;
            postML.typeSpecified = true;
            postML.postname = CreateTitleType(post.Title);

            // Categories
            List<categoryRefType> categoryRefs = new List<categoryRefType>();

            foreach (int tag in post.Tags)
            {
                categoryRefType categoryRef = new categoryRefType();
                categoryRef.@ref = tag.ToString(CultureInfo.InvariantCulture);
                categoryRefs.Add(categoryRef);
            }

            postML.categories = categoryRefs.ToArray();

            // Author
            authorRefType authorRef = new authorRefType();
            authorRef.@ref = "0";
            authorsRefType authorsRef = new authorsRefType();
            authorsRef.author = authorRef;
            postML.authors = authorsRef;

            // Text
            contentType contentML = new contentType();
            contentML.type = contentTypes.text;
            contentML.Value = content.Text;
            postML.content = contentML;

            // Comments
            List<commentType> comments = new List<commentType>();

            foreach (Comment comment in content.Comments)
            {
                commentType commentML = new commentType();
                InitializeNodeType(commentML, comment.Id.ToString(), comment.Title);
                commentML.datecreated = comment.Date;
                commentML.datecreatedSpecified = true;
                commentML.username = comment.Author;
                commentML.useremail = comment.Email;

                contentType commentText = new contentType();
                commentText.type = contentTypes.text;
                commentText.Value = comment.Text;
                commentML.content = commentText;

                comments.Add(commentML);
            }

            postML.comments = comments.ToArray();

            // Trackbacks
            List<trackbackType> trackbacks = new List<trackbackType>();

            foreach (Reference reference in content.References)
            {
                trackbackType trackback = new trackbackType();
                InitializeNodeType(trackback, reference.Id.ToString(), reference.Link);
                trackback.url = reference.Link;
                trackback.datecreated = reference.Date;
                trackback.datecreatedSpecified = true;
                trackbacks.Add(trackback);
            }

            postML.trackbacks = trackbacks.ToArray();

            // Attachments
            List<attachmentType> attachments = new List<attachmentType>();

            foreach (Attachment attachment in content.Attachments)
            {
                attachmentType attachmentML = new attachmentType();
                attachmentML.embedded = true;
                attachmentML.mimetype = attachment.MimeType;

                using (FileStream stream = FileUtilities.OpenRead(HostingEnvironment.MapPath(attachment.Url)))
                {
                    byte[] bytes = new byte[stream.Length];

                    if (stream.Read(bytes, 0, bytes.Length) != bytes.Length)
                    {
                        throw new InvalidOperationException("Attachment length inconsistent");
                    }

                    attachmentML.Value = Convert.ToBase64String(bytes);
                }
            }

            postML.attachments = attachments.ToArray();
            return postML;
        }
    }
}