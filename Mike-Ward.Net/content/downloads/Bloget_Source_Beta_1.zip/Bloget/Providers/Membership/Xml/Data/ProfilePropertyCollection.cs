// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.ObjectModel;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    public class ProfilePropertyCollection : KeyedCollection<string, ProfileProperty>
    {
        protected override string GetKeyForItem(ProfileProperty item)
        {
            return item.Key;
        }
    }
}
