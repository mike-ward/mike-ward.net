// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Xml;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    [XmlRoot("workspaces", Namespace = WorkspaceNamespace)]
    public class WorkspaceCollection
    {
        internal const string WorkspaceNamespace = "urn:blueonionsoftware-com:bloget:workspace:data";

        List<Workspace> workspaces;
        byte[] shared;

        [XmlElement(typeof(byte[]), ElementName = "sharedPersonalization")]
        public byte[] SharedPersonalizationBlob
        {
            get { return shared; }
            set { shared = value; }
        }

        public WorkspaceCollection() 
        {
            workspaces = new List<Workspace>();
        }

        internal WorkspaceCollection(IList<Workspace> workspacesArg)
        {
            workspaces = new List<Workspace>(workspacesArg);
        }

        public Workspace this[int index]
        {
            get { return workspaces[index]; }
            set { workspaces[index] = value; }
        }

        [XmlElement("Workspace", typeof(Workspace))]
        public Collection<Workspace> Workspaces
        {
            get { return new Collection<Workspace>(workspaces); }
        }

        public static WorkspaceCollection Load(string fileName)
        {
            try
            {
                return BlueOnionSoftware.Bloget.Utility.Serializer.Load<WorkspaceCollection>(fileName, WorkspaceNamespace);
            }

            catch (System.IO.FileNotFoundException)
            {
                return new WorkspaceCollection();
            }
        }

        public void Save(string fileName)
        {
            BlueOnionSoftware.Bloget.Utility.Serializer.Save<WorkspaceCollection>(fileName, WorkspaceNamespace, this);
        }

        public Workspace FindByUserAndPath(string userName, string path)
        {
            foreach (Workspace workspace in workspaces)
            {
                if (string.Compare(workspace.UserName, userName, true, CultureInfo.CurrentCulture) == 0)
                {
                    if (string.Compare(workspace.Path, path, true, CultureInfo.CurrentCulture) == 0) 
                    { 
                        return workspace;
                    }
                }
            }

            return null;
        }

        public Collection<Workspace> FindByPath(string path)
        {
            Collection<Workspace> spaces = new Collection<Workspace>();

            foreach (Workspace workspace in workspaces)
            {
                if (string.Compare(workspace.Path, path, true, CultureInfo.CurrentCulture) == 0)
                {
                    spaces.Add(workspace);
                }
            }

            return spaces;
        }

        public Collection<Workspace> FindByUserName(string userName)
        {
            Collection<Workspace> spaces = new Collection<Workspace>();

            foreach (Workspace workspace in workspaces)
            {
                if (string.Compare(workspace.UserName, userName, true, CultureInfo.CurrentCulture) == 0)
                {
                    spaces.Add(workspace);
                }
            }

            return spaces;
        }
    }
}
