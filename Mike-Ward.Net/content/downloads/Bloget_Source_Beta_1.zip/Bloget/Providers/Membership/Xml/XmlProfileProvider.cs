// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Web;
using System.Web.Profile;

namespace BlueOnionSoftware.Bloget.Providers
{
    public class XmlProfileProvider : System.Web.Profile.ProfileProvider
    {
        private string dataStorePath;
        private string applicationName;

        public string DataStorePath
        {
            get { return dataStorePath; }
            set { dataStorePath = value; }
        }

        private string DataStoreFile
        {
            get
            {
                string path;

                if (HttpContext.Current != null)
                {
                    path = HttpContext.Current.Server.MapPath(DataStorePath);
                }

                else
                {
                    path = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath;
                    string dataStorePath = DataStorePath.Replace("~/", string.Empty);
                    path = System.IO.Path.Combine(path, dataStorePath);

                }

                return System.IO.Path.Combine(path, string.Format("{0}_Profiles.xml", applicationName));
            }
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            Throw.IfNull(config, "config");

            if (String.IsNullOrEmpty(name)) 
            { 
                name = "XmlProfileProvider";
            }

            base.Initialize(name, config);

            dataStorePath = String.IsNullOrEmpty(config["dataStorePath"]) ? "~/App_Data" : config["dataStorePath"];
            applicationName = String.IsNullOrEmpty(config["applicationName"]) ? "Bloget" : config["applicationName"];
        }

        public override int DeleteInactiveProfiles(System.Web.Profile.ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);
            List<Data.Profile> toBeRemoved = new List<Data.Profile>();

            foreach (Data.Profile profile in profiles)
            {
                switch (authenticationOption)
                {
                    case ProfileAuthenticationOption.All:
                        if (profile.LastActivityDate <= userInactiveSinceDate) 
                        { 
                            toBeRemoved.Add(profile); 
                        }
                        break;

                    case ProfileAuthenticationOption.Anonymous:
                        if (profile.LastActivityDate <= userInactiveSinceDate && profile.IsAnonymous) 
                        { 
                            toBeRemoved.Add(profile); 
                        }
                        break;

                    case ProfileAuthenticationOption.Authenticated:
                        if (profile.LastActivityDate <= userInactiveSinceDate && !profile.IsAnonymous) 
                        { 
                            toBeRemoved.Add(profile);
                        }
                        break;
                }
            }

            for (int i = 0; i < toBeRemoved.Count; i++)
            {
                profiles.Remove(toBeRemoved[i]);
            }

            return toBeRemoved.Count;
        }

        public override int DeleteProfiles(string[] usernames)
        {
            int counter = 0;
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);

            foreach (string name in usernames)
            {
                Collection<Data.Profile> p = profiles.FindByUserName(name, ProfileAuthenticationOption.All);

                if (p.Count > 0)
                {
                    for (int i = 0; i < p.Count; i++)
                    {
                        profiles.Remove(p[i]);
                        counter++;
                    }
                }
            }

            profiles.Save(DataStoreFile);
            return counter;
        }

        public override int DeleteProfiles(System.Web.Profile.ProfileInfoCollection profiles)
        {
            List<string> usernames = new List<string>();

            foreach (System.Web.Profile.ProfileInfo pi in profiles)
            {
                usernames.Add(pi.UserName);
            }

            return DeleteProfiles(usernames.ToArray());
        }

        public override System.Web.Profile.ProfileInfoCollection FindInactiveProfilesByUserName(System.Web.Profile.ProfileAuthenticationOption authenticationOption, string usernameToMatch, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        public override System.Web.Profile.ProfileInfoCollection FindProfilesByUserName(System.Web.Profile.ProfileAuthenticationOption authenticationOption, string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);
            ProfileInfoCollection pic = profiles.CreateProfileInfoCollection(authenticationOption);
            List<ProfileInfo> lst = new List<ProfileInfo>();

            foreach (ProfileInfo p in pic)
            {
                if (p.UserName.Contains(usernameToMatch)) { lst.Add(p); }
            }

            totalRecords = lst.Count;

            ProfileInfoCollection output = new ProfileInfoCollection();
            for (int i = (pageIndex * pageSize); i < ((pageIndex * pageSize) + pageSize); i++)
            {
                if (lst.Count < i) { break; }
                output.Add(lst[i]);
            }

            return output;
        }

        public override System.Web.Profile.ProfileInfoCollection GetAllInactiveProfiles(System.Web.Profile.ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);

            ProfileInfoCollection pic = profiles.CreateProfileInfoCollection(authenticationOption);
            List<ProfileInfo> lst = new List<ProfileInfo>();

            foreach (ProfileInfo pi in pic)
            {
                if (pi.LastActivityDate <= userInactiveSinceDate)
                {
                    lst.Add(pi);
                }
            }

            totalRecords = lst.Count;
            int counter = 0;

            ProfileInfoCollection newPic = new ProfileInfoCollection();

            foreach (ProfileInfo pi in lst)
            {
                if (counter > (pageIndex * pageSize) && counter < ((pageIndex * pageSize) + pageSize))
                {
                    newPic.Add(pi);
                }
                counter++;
            }

            return newPic;
        }

        public override System.Web.Profile.ProfileInfoCollection GetAllProfiles(System.Web.Profile.ProfileAuthenticationOption authenticationOption, int pageIndex, int pageSize, out int totalRecords)
        {
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);
            ProfileInfoCollection pic = profiles.CreateProfileInfoCollection(authenticationOption);
            ProfileInfoCollection newPic = new ProfileInfoCollection();

            totalRecords = pic.Count;
            int counter = 0;

            foreach (ProfileInfo pi in pic)
            {
                if (counter > (pageIndex * pageSize) && counter < ((pageIndex * pageSize) + pageSize))
                {
                    newPic.Add(pi);
                }

                counter++;
            }

            return newPic;
        }

        public override int GetNumberOfInactiveProfiles(System.Web.Profile.ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);
            ProfileInfoCollection pic = profiles.CreateProfileInfoCollection(authenticationOption);
            int counter = 0;

            foreach (ProfileInfo p in pic)
            {
                if (p.LastActivityDate <= userInactiveSinceDate)
                {
                    counter++;
                }
            }

            return counter;
        }

        public override string ApplicationName
        {
            get { return applicationName; }
            set { applicationName = value; }
        }

        public override System.Configuration.SettingsPropertyValueCollection GetPropertyValues(System.Configuration.SettingsContext context, System.Configuration.SettingsPropertyCollection collection)
        {
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);
            Collection<Data.Profile> profile = null;

            string userID = context["UserName"].ToString();
            bool authenticated = Convert.ToBoolean(context["IsAuthenticated"]);

            if (authenticated)
            {
                profile = profiles.FindByUserName(userID, ProfileAuthenticationOption.Authenticated);
            }

            else
            {
                profile = profiles.FindByUserName(userID, ProfileAuthenticationOption.Anonymous);
            }


            System.Configuration.SettingsPropertyValueCollection spvc = new System.Configuration.SettingsPropertyValueCollection();
            Data.Profile prof = null;

            if (profile.Count > 0)
            {
                prof = profile[0];
            }


            foreach (System.Configuration.SettingsProperty prop in collection)
            {
                System.Configuration.SettingsPropertyValue val = new System.Configuration.SettingsPropertyValue(prop);

                if (prof != null && prof.Properties.Contains(prop.Name))
                {
                    if (val.Deserialized)
                    {
                        val.PropertyValue = prof.Properties[prop.Name].Value;
                    }

                    else
                    {
                        val.SerializedValue = prof.Properties[prop.Name].Value;
                        if (prop.SerializeAs == System.Configuration.SettingsSerializeAs.ProviderSpecific)
                        {
                            val.PropertyValue = Convert.ChangeType(val.SerializedValue, prop.PropertyType);
                        }
                    }

                    val.IsDirty = false;
                }

                spvc.Add(val);
            }

            return spvc;
        }

        public override void SetPropertyValues(System.Configuration.SettingsContext context, System.Configuration.SettingsPropertyValueCollection collection)
        {
            Data.ProfileCollection profiles = Data.ProfileCollection.Load(DataStoreFile);
            Collection<Data.Profile> profile = null;

            string userID = context["UserName"].ToString();
            bool authenticated = Convert.ToBoolean(context["IsAuthenticated"]);

            if (authenticated)
            {
                profile = profiles.FindByUserName(userID, ProfileAuthenticationOption.Authenticated);
            }

            else
            {
                profile = profiles.FindByUserName(userID, ProfileAuthenticationOption.Anonymous);
            }

            Data.Profile p = null;

            if (profile.Count > 0)
            {
                p = profile[0];
            }

            else
            {
                p = new Data.Profile();
                p.IsAnonymous = !authenticated;
                p.UserName = userID;
                profiles.Add(p);
            }

            foreach (System.Configuration.SettingsPropertyValue val in collection)
            {
                if (val.SerializedValue != null)
                {
                    if (p.Properties.Contains(val.Name))
                    {
                        p.Properties[val.Name].Value = val.SerializedValue;
                    }

                    else
                    {
                        Data.ProfileProperty pro = new Data.ProfileProperty(val.Name);
                        pro.Value = val.SerializedValue;
                        p.Properties.Add(pro);
                    }
                }
            }

            profiles.Save(DataStoreFile);
        }
    }
}
