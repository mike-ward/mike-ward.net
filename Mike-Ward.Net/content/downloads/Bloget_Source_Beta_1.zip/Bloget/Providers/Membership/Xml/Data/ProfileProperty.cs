using System;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    public class ProfileProperty
    {
        private string _key;
        private object _value;

        public ProfileProperty() { }

        public ProfileProperty(string key)
        {
            _key = key;
        }

        [XmlAttribute("name")]
        public string Key
        {
            get { return _key; }
            set { _key = value; }
        }

        [XmlElement(DataType = "base64Binary", Type = typeof(byte[]), ElementName = "binaryValue")]
        [XmlElement(typeof(string), ElementName = "value")]
        public object Value
        {
            get { return _value; }
            set { _value = value; }
        }
    }
}
