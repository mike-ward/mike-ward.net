// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    public class Profile
    {
        ProfilePropertyCollection inner;
        string username;
        bool anonymous;
        DateTime lastActivity;
        DateTime lastUpdates;
        
        public Profile()
        {
            inner = new ProfilePropertyCollection();            
        }

        [XmlElement("username")]
        public string UserName
        {
            get { return username; }
            set { username = value; }
        }

        
        [XmlElement("anonymous")]
        public bool IsAnonymous
        {
            get { return anonymous; }
            set { anonymous = value; }
        }
        
        [XmlElement("lastActivity")]
        public DateTime LastActivityDate
        {
            get { return lastActivity; }
            set { lastActivity = value; }
        }

        [XmlElement("lastUpdated")]
        public DateTime LastUpdatedDate
        {
            get { return lastUpdates; }
            set { lastUpdates = value; }
        }

        [XmlElement("property")]
        public ProfilePropertyCollection Properties
        {
            get { return inner; }
        }

        [XmlIgnore]
        public int Size
        {
            get { return inner.Count; }
        }

        public System.Web.Profile.ProfileInfo CreateProfileInfo()
        {
            return new System.Web.Profile.ProfileInfo(this.username, this.anonymous, this.lastActivity, this.lastUpdates, this.Size);            
        }
    }
}
