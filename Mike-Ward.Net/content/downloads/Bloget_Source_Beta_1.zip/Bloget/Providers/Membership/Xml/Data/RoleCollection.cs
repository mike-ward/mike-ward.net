// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    [XmlRoot("roles", Namespace = RoleNamespace)]
    public class RoleCollection : Collection<Role>
    {
        internal const string RoleNamespace = "urn:blueonionsoftware-com:bloget:role:data";

        public RoleCollection()
            : base()
        {
        }

        internal RoleCollection(IList<Role> roles)
            : base(roles)
        {
        }

        public static RoleCollection Load(string fileName)
        {
            try
            {
                return BlueOnionSoftware.Bloget.Utility.Serializer.Load<RoleCollection>(fileName, RoleNamespace);
            }

            catch (System.IO.FileNotFoundException)
            {
                return new RoleCollection();
            }
        }

        public void Save(string fileName)
        {
            BlueOnionSoftware.Bloget.Utility.Serializer.Save<RoleCollection>(fileName, RoleNamespace, this);
        }

        public Role FindByName(string name)
        {
            foreach (Role role in this)
            {
                if (string.Compare(role.Name, name, true, CultureInfo.CurrentCulture) == 0)
                {
                    return role;
                }
            }

            return null;
        }
    }
}
