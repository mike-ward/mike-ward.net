// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Web;

namespace BlueOnionSoftware.Bloget.Providers
{
    public class XmlRoleProvider : System.Web.Security.RoleProvider
    {
        string dataStorePath;
        string applicationName;

        public string DataStorePath
        {
            get { return dataStorePath; }
            set { dataStorePath = value; }
        }

        string DataStoreFile
        {
            get
            {
                string path;

                if (HttpContext.Current != null)
                {
                    path = HttpContext.Current.Server.MapPath(DataStorePath);
                }

                else
                {
                    path = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath;
                    string dataStorePath = DataStorePath.Replace("~/", string.Empty);
                    path = System.IO.Path.Combine(path, dataStorePath);

                }

                return System.IO.Path.Combine(path, string.Format("{0}_Roles.xml", applicationName));
            }
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            Throw.IfNull(config, "config");

            if (String.IsNullOrEmpty(name))
            {
                name = "XmlRoleProvider";
            }

            base.Initialize(name, config);

            dataStorePath  = String.IsNullOrEmpty(config["dataStorePath"]) ? "~/App_Data" : config["dataStorePath"];
            applicationName = String.IsNullOrEmpty(config["applicationName"]) ? "Bloget" : config["applicationName"];
        }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);

            foreach (string roleName in roleNames)
            {
                Data.Role role = roles.FindByName(roleName);

                if (role != null)
                {
                    foreach (string username in usernames)
                    {
                        if (!role.Users.Contains(username))
                        {
                            role.Users.Add(username);
                        }
                    }
                }
            }

            roles.Save(DataStoreFile);
        }

        public override string ApplicationName
        {
            get { return applicationName; }
            set { applicationName = value; }
        }

        public override void CreateRole(string roleName)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);
            Data.Role role = new Data.Role();

            role.Name = roleName;
            roles.Add(role);
            roles.Save(DataStoreFile);
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);
            Data.Role role = roles.FindByName(roleName);

            if (role != null)
            {
                if (throwOnPopulatedRole && role.Users.Count > 0)
                {
                    return false;
                }

                roles.Remove(role);
                roles.Save(DataStoreFile);
            }

            return true;
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);
            Data.Role role = roles.FindByName(roleName);
            List<string> users = new List<string>();

            if (role != null)
            {
                foreach (string user in role.Users)
                {
                    if (user.Contains(usernameToMatch))
                    {
                        users.Add(user);
                    }
                }
            }

            return users.ToArray();
        }

        public override string[] GetAllRoles()
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);
            List<Data.Role> roleList = new List<Data.Role>(roles);

            List<string> names = roleList.ConvertAll<string>(new Converter<BlueOnionSoftware.Bloget.Providers.Data.Role, string>(ConvertRoleToString));
            return names.ToArray();
        }

        static string ConvertRoleToString(Data.Role role)
        {
            return role.Name;
        }

        public override string[] GetRolesForUser(string username)
        {
            List<string> roleList = new List<string>();
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);

            foreach (Data.Role role in roles)
            {
                if (role.Users.Contains(username))
                {
                    roleList.Add(role.Name);
                }
            }

            return roleList.ToArray();
        }

        public override string[] GetUsersInRole(string roleName)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);
            Data.Role role = roles.FindByName(roleName);
            string[] output = null;

            if (role != null)
            {
                output = new string[role.Users.Count];
                role.Users.CopyTo(output, 0);
            }

            return output;
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);
            Data.Role role = roles.FindByName(roleName);

            if (role != null)
            {
                return role.Users.Contains(username);
            }

            return false;
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);

            foreach (string roleName in roleNames)
            {
                Data.Role role = roles.FindByName(roleName);

                if (role != null)
                {
                    foreach (string username in usernames)
                    {
                        if (role.Users.Contains(username))
                        {
                            role.Users.Remove(username);
                        }
                    }
                }
            }

            roles.Save(DataStoreFile);
        }

        public override bool RoleExists(string roleName)
        {
            Data.RoleCollection roles = Data.RoleCollection.Load(DataStoreFile);
            Data.Role role = roles.FindByName(roleName);
            return role != null;
        }
    }
}
