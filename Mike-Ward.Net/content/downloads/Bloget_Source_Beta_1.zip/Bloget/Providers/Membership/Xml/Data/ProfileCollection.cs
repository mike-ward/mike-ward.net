// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Web.Profile;
using System.Xml;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    [XmlRoot("profiles", Namespace = ProfileNamespace)]
    public class ProfileCollection : Collection<Profile>
    {
        internal const string ProfileNamespace = "urn:blueonionsoftware-com:bloget:profile:data";

        public ProfileCollection() 
            : base() 
        { 
        }

        internal ProfileCollection(IList<Profile> profiles) 
            : base(profiles) 
        { 
        }

        public static ProfileCollection Load(string fileName)
        {
            try
            {
                return BlueOnionSoftware.Bloget.Utility.Serializer.Load<ProfileCollection>(fileName, ProfileNamespace);
            }

            catch (FileNotFoundException)
            {
                return new ProfileCollection();
            }
        }
        
        public void Save(string fileName)
        {
            BlueOnionSoftware.Bloget.Utility.Serializer.Save<ProfileCollection>(fileName, ProfileNamespace, this);
        }

        public Collection<Profile> FindByUserName(string userName, System.Web.Profile.ProfileAuthenticationOption authenticationType)
        {
            List<Profile> profiles = new List<Profile>();

            foreach (Profile p in this)
            {
                if (string.Compare(userName, p.UserName, true, CultureInfo.CurrentCulture) == 0) 
                {
                    switch (authenticationType)
                    {
                        case System.Web.Profile.ProfileAuthenticationOption.All:
                            profiles.Add(p);
                            break;

                        case System.Web.Profile.ProfileAuthenticationOption.Anonymous:
                            if (p.IsAnonymous) { profiles.Add(p); }
                            break;

                        case System.Web.Profile.ProfileAuthenticationOption.Authenticated:
                            if (!p.IsAnonymous) { profiles.Add(p); }
                            break;
                    } 
                }
            }

            return new Collection<Profile>(profiles);
        }

        public ProfileInfoCollection CreateProfileInfoCollection(ProfileAuthenticationOption authenticationOption)
        {
            ProfileInfoCollection pic = new ProfileInfoCollection();

            foreach (Profile p in this)
            {
                switch (authenticationOption)
                {
                    case ProfileAuthenticationOption.All:
                        pic.Add(p.CreateProfileInfo());
                        break;

                    case ProfileAuthenticationOption.Anonymous:
                        if (p.IsAnonymous) { pic.Add(p.CreateProfileInfo()); }
                        break;

                    case ProfileAuthenticationOption.Authenticated:
                        if (!p.IsAnonymous) { pic.Add(p.CreateProfileInfo()); }
                        break;
                }
            }

            return pic;
        }
    }
}
