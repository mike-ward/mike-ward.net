// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Web.Security;
using System.Xml;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    public class User
    {
        string userName;
        string email;
        byte[] password;
        bool locked;
        bool active;
        string challengeQuestion;
        string challengeAnswer;
        string comment;
        Guid userKey;

        DateTime lastLogin;
        DateTime lastActivity;
        DateTime lastPasswordChanged;
        DateTime lastLockedOut;
        DateTime createdOn;

        [XmlElement("id")]
        public Guid Key
        {
            get { return userKey; }
            set { userKey = value; }
        }

        [XmlElement("username")]
        public string UserName
        {
            get { return userName ?? string.Empty; }
            set { userName = value; }
        }

        [XmlElement("email")]
        public string Email
        {
            get { return email ?? string.Empty; }
            set { email = value; }
        }

        [XmlElement("comment")]
        public string Comment
        {
            get { return comment ?? string.Empty; }
            set { comment = value; }
        }

        [XmlElement(typeof(byte[]), DataType = "base64Binary", ElementName = "password")]
        public byte[] Password
        {
            get { return password; }
            set { password = value; }
        }

        [XmlElement("locked")]
        public bool IsLocked
        {
            get { return locked; }
            set { locked = value; }
        }

        [XmlElement("question")]
        public string ChallengeQuestion
        {
            get { return challengeQuestion ?? string.Empty; }
            set { challengeQuestion = value; }
        }

        [XmlElement("answer")]
        public string ChallengeAnswer
        {
            get { return challengeAnswer ?? string.Empty; }
            set { challengeAnswer = value; }
        }

        [XmlElement("lastLogin")]
        public DateTime LastLoggedIn
        {
            get { return lastLogin; }
            set { lastLogin = value; }
        }

        [XmlElement("lastActivity")]
        public DateTime LastActivity
        {
            get { return lastActivity; }
            set { lastActivity = value; }
        }

        [XmlElement("lastPasswordChange")]
        public DateTime LastPasswordChange
        {
            get { return lastPasswordChanged; }
            set { lastPasswordChanged = value; }
        }

        [XmlElement("lastLockedOut")]
        public DateTime LastLockedOut
        {
            get { return lastLockedOut; }
            set { lastLockedOut = value; }
        }

        [XmlElement("createdOn")]
        public DateTime CreatedOn
        {
            get { return createdOn; }
            set { createdOn = value; }
        }

        [XmlElement("active")]
        public bool IsActive
        {
            get { return active; }
            set { active = value; }
        }

        internal MembershipUser CreateMembershipUser(string providerName)
        {
            return new MembershipUser(providerName, this.UserName, this.Key, this.Email, this.ChallengeQuestion,
                    this.Comment, this.IsActive, this.IsLocked, this.CreatedOn, this.LastLoggedIn, this.LastActivity,
                    this.LastPasswordChange, this.LastLockedOut);
        }
    }
}
