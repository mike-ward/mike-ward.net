// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace BlueOnionSoftware.Bloget.Providers
{
    public class XmlMembershipProvider : MembershipProvider
    {
        string dataStorePath;
        string applicationName;
        bool enableReset;
        bool enableRetrieve;
        MembershipPasswordFormat passwordFormat;
        bool uniqueEmail;
        string passwordExpression;
        bool requiresChallenge;
        int attempts;
        int attemptWindow;
        int minPasswordLength;
        int minNonAlphaChars;
        readonly Encoding encoder = Encoding.UTF8;

        public XmlMembershipProvider()
            : base()
        {
        }

        public string DataStorePath
        {
            get { return dataStorePath; }
            set { dataStorePath = value; }
        }

        string DataStoreFile
        {
            get
            {
                string path;

                if (HttpContext.Current != null)
                {
                    path = HttpContext.Current.Server.MapPath(DataStorePath);
                }

                else
                {
                    path = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath;
                    string dataStorePath = DataStorePath.Replace("~/", string.Empty);
                    path = System.IO.Path.Combine(path, dataStorePath);
                }

                return System.IO.Path.Combine(path, string.Format("{0}_Members.xml", applicationName));
            }
        }

        Data.UserCollection RetrieveUsers(bool activeOnly)
        {
            Data.UserCollection users = Data.UserCollection.Load(DataStoreFile);
            return (activeOnly) ? users.FindAllActiveUsers() : users;
        }

        static byte[] ComputeHash(byte[] input)
        {
            using (SHA512Managed provider = new SHA512Managed())
            {
                byte[] hash = provider.ComputeHash(input);
                provider.Clear();
                return hash;
            }
        }

        static MembershipUserCollection CreateMembershipUserCollection(IList<Data.User> users)
        {
            MembershipUserCollection userCollection = new MembershipUserCollection();

            foreach (Data.User user in users)
            {
                userCollection.Add(user.CreateMembershipUser(Membership.Provider.Name));
            }

            return userCollection;
        }

        bool CompareByteArray(byte[] array1, byte[] array2)
        {
            if (array1.Length != array2.Length)
            {
                return false;
            }

            for (int i = 0; i < array1.Length; ++i)
            {
                if (array1[i] != array2[i])
                {
                    return false;
                }
            }

            return true;
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            Throw.IfNull(config, "config");
            
            if (String.IsNullOrEmpty(name))
            {
                name = "XmlMembershipProvider";
            }

            base.Initialize(name, config);

            passwordFormat = String.IsNullOrEmpty(config["passwordFormat"])
                ? MembershipPasswordFormat.Hashed 
                : passwordFormat = (MembershipPasswordFormat)System.Enum.Parse(typeof(MembershipPasswordFormat), config["passwordFormat"], true);

            dataStorePath = String.IsNullOrEmpty(config["dataStorePath"]) ? "~/App_Data" : config["dataStorePath"];
            applicationName = String.IsNullOrEmpty(config["applicationName"]) ? "Bloget" : config["applicationName"];
            enableRetrieve = String.IsNullOrEmpty(config["enablePasswordRetrieval"]) ? false : bool.Parse(config["enablePasswordRetrieval"]);
            enableReset = String.IsNullOrEmpty(config["enablePasswordReset"]) ? false : bool.Parse(config["enablePasswordReset"]);
            requiresChallenge = String.IsNullOrEmpty(config["requiresQuestionAndAnswer"]) ? false : bool.Parse(config["requiresQuestionAndAnswer"]);
            uniqueEmail = String.IsNullOrEmpty(config["requiresUniqueEmail"]) ? false : bool.Parse(config["requiresUniqueEmail"]);
            attemptWindow = String.IsNullOrEmpty(config["passwordAttemptWindow"]) ? 1 : int.Parse(config["passwordAttemptWindow"], CultureInfo.InvariantCulture);
            passwordExpression = String.IsNullOrEmpty(config["passwordStrengthRegularExpression"]) ? string.Empty : config["passwordStrengthRegularExpression"];
            attempts = String.IsNullOrEmpty(config["maxInvalidPasswordAttempts"]) ? 6 : int.Parse(config["maxInvalidPasswordAttempts"], CultureInfo.InvariantCulture);
            minNonAlphaChars = String.IsNullOrEmpty(config["minRequiredNonAlphanumericCharacters"]) ? 0 : int.Parse(config["minRequiredNonAlphanumericCharacters"], CultureInfo.InvariantCulture);
            minPasswordLength = String.IsNullOrEmpty(config["minRequiredPasswordLength"]) ? 4 : int.Parse(config["minRequiredPasswordLength"], CultureInfo.InvariantCulture);
        }

        public override string ApplicationName
        {
            get { return applicationName; }
            set { applicationName = value; }
        }

        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            Data.UserCollection users = RetrieveUsers(true);
            Data.User user = users.FindByUserName(username);

            if (user == null)
            {
                return false;
            }

            byte[] oldPass = encoder.GetBytes(oldPassword);
            byte[] newPass = encoder.GetBytes(newPassword);

            switch (PasswordFormat)
            {
                case MembershipPasswordFormat.Clear:
                    if (CompareByteArray(user.Password, oldPass))
                    {
                        user.Password = newPass;
                    }

                    else
                    {
                        return false;
                    }
                    break;

                case MembershipPasswordFormat.Encrypted:
                    if (CompareByteArray(user.Password, base.EncryptPassword(oldPass)))
                    {
                        user.Password = base.EncryptPassword(newPass);
                    }

                    else
                    {
                        return false;
                    }
                    break;

                case MembershipPasswordFormat.Hashed:
                    if (CompareByteArray(user.Password, ComputeHash(oldPass)))
                    {
                        user.Password = ComputeHash(newPass);
                    }

                    else
                    {
                        return false;
                    }
                    break;
            }

            users.Save(DataStoreFile);
            return true;
        }

        public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            Data.UserCollection users = RetrieveUsers(true);
            Data.User usr = users.FindByUserName(username);

            if (usr == null)
            {
                return false;
            }

            bool passwordOK = false;
            byte[] passBytes = encoder.GetBytes(password);

            switch (PasswordFormat)
            {
                case MembershipPasswordFormat.Clear:
                    passwordOK = CompareByteArray(usr.Password, passBytes);
                    break;

                case MembershipPasswordFormat.Encrypted:
                    passwordOK = CompareByteArray(usr.Password, base.EncryptPassword(passBytes));
                    break;

                case MembershipPasswordFormat.Hashed:
                    passwordOK = CompareByteArray(usr.Password, ComputeHash(passBytes));
                    break;
            }

            if (passwordOK)
            {
                usr.ChallengeQuestion = newPasswordQuestion;
                usr.ChallengeAnswer = newPasswordAnswer;
                users.Save(DataStoreFile);
            }

            return passwordOK;
        }

        public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
        {
            Data.UserCollection users = RetrieveUsers(false);

            //Perform Checks
            if (users.FindByUserName(username) != null)
            {
                status = MembershipCreateStatus.DuplicateUserName;
                return null;
            }

            if (RequiresUniqueEmail && users.FindByEmail(email) != null)
            {
                status = MembershipCreateStatus.DuplicateEmail;
                return null;
            }

            Data.User newUser = new Data.User();
            byte[] pass = encoder.GetBytes(password);
            newUser.Key = Guid.NewGuid();
            newUser.UserName = username;

            switch (PasswordFormat)
            {
                case MembershipPasswordFormat.Clear:
                    newUser.Password = pass;
                    break;

                case MembershipPasswordFormat.Hashed:
                    newUser.Password = ComputeHash(pass);
                    break;

                case MembershipPasswordFormat.Encrypted:
                    newUser.Password = base.EncryptPassword(pass);
                    break;
            }

            newUser.CreatedOn = DateTime.UtcNow;
            newUser.LastLoggedIn = DateTime.UtcNow;
            newUser.LastActivity = DateTime.UtcNow;
            newUser.IsActive = isApproved;
            newUser.Email = email;
            newUser.ChallengeQuestion = passwordQuestion;
            newUser.ChallengeAnswer = passwordAnswer;

            users.Add(newUser);
            users.Save(DataStoreFile);

            status = MembershipCreateStatus.Success;
            return newUser.CreateMembershipUser(Membership.Provider.Name);
        }

        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            Data.UserCollection users = RetrieveUsers(false);
            Data.User usr = users.FindByUserName(username);

            if (usr == null)
            {
                return false;
            }

            if (deleteAllRelatedData)
            {
                users.Remove(usr);
            }

            else
            {
                usr.IsActive = false;
            }

            users.Save(DataStoreFile);
            return true;
        }

        public override bool EnablePasswordReset
        {
            get { return enableReset; }
        }

        public override bool EnablePasswordRetrieval
        {
            get { return enableRetrieve; }
        }

        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            Data.UserCollection users = RetrieveUsers(false);
            List<Data.User> userCollection = new List<BlueOnionSoftware.Bloget.Providers.Data.User>();

            foreach (Data.User user in users)
            {
                if (string.Compare(emailToMatch, user.Email, true, CultureInfo.CurrentCulture) == 0)
                {
                    userCollection.Add(user);
                }
            }

            totalRecords = userCollection.Count;
            return CreateMembershipUserCollection(userCollection.GetRange(pageIndex * pageSize, (totalRecords < pageSize ? totalRecords : pageSize)));
        }

        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            Data.UserCollection users = RetrieveUsers(false);
            List<Data.User> userCollection = new List<BlueOnionSoftware.Bloget.Providers.Data.User>();

            foreach (Data.User user in users)
            {
                if (string.Compare(usernameToMatch, user.UserName, true, CultureInfo.CurrentCulture) == 0)
                {
                    userCollection.Add(user);
                }
            }

            totalRecords = userCollection.Count;
            return CreateMembershipUserCollection(userCollection.GetRange(pageIndex * pageSize, (totalRecords < pageSize ? totalRecords : pageSize)));
        }

        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            Data.UserCollection users = RetrieveUsers(false);
            totalRecords = users.Count;
            List<Data.User> userList = new List<Data.User>(users);
            return CreateMembershipUserCollection(userList.GetRange(pageIndex * pageSize, (totalRecords < pageSize ? totalRecords : pageSize)));
        }

        public override int GetNumberOfUsersOnline()
        {
            int onlineCounter = 0;
            int minutes = Membership.UserIsOnlineTimeWindow;
            Data.UserCollection users = RetrieveUsers(true);

            foreach (Data.User user in users)
            {
                if (user.LastActivity > DateTime.UtcNow.AddMinutes(-minutes))
                {
                    onlineCounter++;
                }
            }

            return onlineCounter;
        }

        public override string GetPassword(string username, string answer)
        {
            Data.UserCollection users = RetrieveUsers(true);
            Data.User usr = users.FindByUserName(username);

            if (usr != null && string.Compare(usr.ChallengeAnswer, answer, true, CultureInfo.CurrentCulture) == 0)
            {
                switch (PasswordFormat)
                {
                    case MembershipPasswordFormat.Clear:
                        return encoder.GetString(usr.Password);

                    case MembershipPasswordFormat.Encrypted:
                        return encoder.GetString(base.DecryptPassword(usr.Password));
                }
            }

            throw new NotSupportedException();
        }

        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            Data.UserCollection users = RetrieveUsers(false);
            Data.User usr = users.FindByUserName(username);

            if (usr != null)
            {
                return usr.CreateMembershipUser(Membership.Provider.Name);
            }

            return null;
        }

        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            Guid key = (Guid)providerUserKey;
            Data.UserCollection users = RetrieveUsers(false);
            Data.User usr = users.FindByKey(key);

            if (usr != null)
            {
                if (userIsOnline)
                {
                    usr.LastActivity = DateTime.UtcNow;
                    users.Save(DataStoreFile);
                }

                return usr.CreateMembershipUser(Membership.Provider.Name);
            }

            return null;
        }

        public override string GetUserNameByEmail(string email)
        {
            Data.UserCollection users = RetrieveUsers(false);
            Data.User usr = users.FindByEmail(email);

            if (usr != null)
            {
                return usr.UserName;
            }

            return null;
        }

        public override int MaxInvalidPasswordAttempts
        {
            get { return attempts; }
        }

        public override int MinRequiredNonAlphanumericCharacters
        {
            get { return minNonAlphaChars; }
        }

        public override int MinRequiredPasswordLength
        {
            get { return minPasswordLength; }
        }

        public override int PasswordAttemptWindow
        {
            get { return attemptWindow; }
        }

        public override MembershipPasswordFormat PasswordFormat
        {
            get { return passwordFormat; }
        }

        public override string PasswordStrengthRegularExpression
        {
            get { return passwordExpression; }
        }

        public override bool RequiresQuestionAndAnswer
        {
            get { return requiresChallenge; }
        }

        public override bool RequiresUniqueEmail
        {
            get { return uniqueEmail; }
        }

        public override string ResetPassword(string username, string answer)
        {
            Data.UserCollection users = RetrieveUsers(false);
            Data.User user = users.FindByUserName(username);

            string password = Membership.GeneratePassword(minPasswordLength, minNonAlphaChars);
            byte[] newPassword = encoder.GetBytes(password);

            if (user != null)
            {
                switch (PasswordFormat)
                {
                    case MembershipPasswordFormat.Clear:
                        user.Password = newPassword;
                        break;

                    case MembershipPasswordFormat.Encrypted:
                        user.Password = base.EncryptPassword(newPassword);
                        break;

                    case MembershipPasswordFormat.Hashed:
                        user.Password = ComputeHash(newPassword);
                        break;
                }

                users.Save(DataStoreFile);
                return password;
            }

            return null;
        }

        public override bool UnlockUser(string userName)
        {
            Data.UserCollection users = RetrieveUsers(false);
            Data.User usr = users.FindByUserName(userName);

            if (usr != null) { usr.IsLocked = false; users.Save(DataStoreFile); }

            return true;
        }

        public override void UpdateUser(MembershipUser user)
        {
            Throw.IfNull(user, "user");

            Data.UserCollection users = RetrieveUsers(false);
            Data.User storedUser = users.FindByUserName(user.UserName);

            if (storedUser != null)
            {
                storedUser.LastActivity = user.LastActivityDate;
                storedUser.LastLockedOut = user.LastLockoutDate;
                storedUser.LastPasswordChange = user.LastPasswordChangedDate;
                storedUser.ChallengeQuestion = user.PasswordQuestion;
                storedUser.Email = user.Email;
                storedUser.IsLocked = user.IsLockedOut;
                storedUser.IsActive = user.IsApproved;
                storedUser.Comment = user.Comment;

                users.Save(DataStoreFile);
            }
        }

        public override bool ValidateUser(string username, string password)
        {
            Data.UserCollection users = RetrieveUsers(false);
            Data.User usr = users.FindByUserName(username);
            byte[] passwordBytes = encoder.GetBytes(password);
            bool passed = false;

            if (usr != null)
            {
                switch (PasswordFormat)
                {
                    case MembershipPasswordFormat.Clear:
                        passed = CompareByteArray(usr.Password, passwordBytes);
                        break;

                    case MembershipPasswordFormat.Encrypted:
                        passed = CompareByteArray(usr.Password, DecryptPassword(passwordBytes));
                        break;

                    case MembershipPasswordFormat.Hashed:
                        passed = CompareByteArray(usr.Password, ComputeHash(passwordBytes));
                        break;
                }
            }

            if (passed)
            {
                if (usr.IsLocked)
                {
                    passed = false;
                }

                else
                {
                    usr.LastLoggedIn = DateTime.UtcNow;
                    usr.LastActivity = DateTime.UtcNow;
                    users.Save(DataStoreFile);
                }
            }

            return passed;
        }
    }
}
