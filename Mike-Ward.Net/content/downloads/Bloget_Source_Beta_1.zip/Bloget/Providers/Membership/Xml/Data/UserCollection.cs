// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    [XmlRoot("users", Namespace = UserNamespace)]
    public class UserCollection : Collection<User>
    {
        internal const string UserNamespace = "urn:blueonionsoftware-com:bloget:user:data";

        public UserCollection()
            : base()
        {
        }

        internal UserCollection(IList<User> array)
            : base(array)
        {
        }

        public static UserCollection Load(string fileName)
        {
            try
            {
                return BlueOnionSoftware.Bloget.Utility.Serializer.Load<UserCollection>(fileName, UserNamespace);
            }

            catch (System.IO.FileNotFoundException)
            {
                return new UserCollection();
            }
        }

        public void Save(string fileName)
        {
            BlueOnionSoftware.Bloget.Utility.Serializer.Save<UserCollection>(fileName, UserNamespace, this);
        }

        public User FindByUserName(string userName)
        {
            foreach (User user in this)
            {
                if (string.Compare(user.UserName, userName, true, CultureInfo.CurrentCulture) == 0)
                {
                    return user;
                }
            }

            return null;
        }

        public User FindByEmail(string email)
        {
            foreach (User user in this)
            {
                if (string.Compare(user.Email, email, true, CultureInfo.CurrentCulture) == 0)
                {
                    return user;
                }
            }

            return null;
        }

        public User FindByKey(Guid key)
        {
            foreach (User user in this)
            {
                if (user.Key.Equals(key))
                {
                    return user;
                }
            }

            return null;
        }

        public UserCollection FindAllActiveUsers()
        {
            UserCollection users = new UserCollection();

            foreach (User user in this)
            {
                if (user.IsActive)
                {
                    users.Add(user);
                }
            }

            return users;
        }
    }
}
