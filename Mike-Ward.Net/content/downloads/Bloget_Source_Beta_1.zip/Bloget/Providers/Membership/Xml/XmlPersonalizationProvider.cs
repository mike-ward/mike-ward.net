// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Web;
using System.Web.UI.WebControls.WebParts;

namespace BlueOnionSoftware.Bloget.Providers
{
    public class XmlPersonalizationProvider : PersonalizationProvider
    {
        private string dataStorePath;
        private string applicationName;

        public string DataStorePath
        {
            get { return dataStorePath; }
            set { dataStorePath = value; }
        }

        private string DataStoreFile
        {
            get
            {
                string path;

                if (HttpContext.Current != null)
                {
                    path = HttpContext.Current.Server.MapPath(DataStorePath);
                }

                else
                {
                    path = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath;
                    string dataStorePath = DataStorePath.Replace("~/", string.Empty);
                    path = System.IO.Path.Combine(path, dataStorePath);

                }
                
                return System.IO.Path.Combine(path, string.Format("{0}_Personalization.xml", applicationName));
            }
        }

        public override string ApplicationName
        {
            get { return applicationName; }
            set { applicationName = value; }
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            Throw.IfNull(config, "config");
            
            if (String.IsNullOrEmpty(name))
            { 
                name = "XmlPersonalizationProvider";
            }

            base.Initialize(name, config);

            dataStorePath = String.IsNullOrEmpty(config["dataStorePath"]) ? "~/App_Data" : config["dataStorePath"];
            applicationName = String.IsNullOrEmpty(config["applicationName"]) ? "Bloget" : config["applicationName"];
        }

        public override PersonalizationStateInfoCollection FindState(PersonalizationScope scope, PersonalizationStateQuery query, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        public override int GetCountOfState(PersonalizationScope scope, PersonalizationStateQuery query)
        {
            throw new NotImplementedException();
        }

        protected override void LoadPersonalizationBlobs(WebPartManager webPartManager, string path, string userName, ref byte[] sharedDataBlob, ref byte[] userDataBlob)
        {
            Data.WorkspaceCollection spaces = Data.WorkspaceCollection.Load(DataStoreFile);

            if (spaces.SharedPersonalizationBlob != null) 
            { 
                sharedDataBlob = spaces.SharedPersonalizationBlob; 
            }

            Data.Workspace space = spaces.FindByUserAndPath(userName, path);
            
            if (space != null && space.PersonalizationBlob != null)
            {
                userDataBlob = space.PersonalizationBlob;
            }
        }

        protected override void ResetPersonalizationBlob(WebPartManager webPartManager, string path, string userName)
        {
            Data.WorkspaceCollection spaces = Data.WorkspaceCollection.Load(DataStoreFile);
            Data.Workspace space = spaces.FindByUserAndPath(userName, path);

            if (space != null)
            {
                spaces.Workspaces.Remove(space);
                spaces.Save(DataStoreFile);
            }
        }

        /// <returns>The number of rows deleted.</returns>
        public override int ResetState(PersonalizationScope scope, string[] paths, string[] usernames)
        {
            throw new NotImplementedException();
        }

        public override int ResetUserState(string path, DateTime userInactiveSinceDate)
        {
            throw new NotImplementedException();
        }

        protected override void SavePersonalizationBlob(WebPartManager webPartManager, string path, string userName, byte[] dataBlob)
        {
            Data.WorkspaceCollection spaces = Data.WorkspaceCollection.Load(DataStoreFile);

            if (!String.IsNullOrEmpty(userName))
            {
                Data.Workspace space = spaces.FindByUserAndPath(userName, path);

                if (space == null)
                {
                    space = new Data.Workspace();
                    space.Path = path;
                    space.UserName = userName;
                    spaces.Workspaces.Add(space);
                }

                space.PersonalizationBlob = dataBlob;
            }

            else
            {
                spaces.SharedPersonalizationBlob = dataBlob;
            }

            spaces.Save(DataStoreFile);
        }
    }
}
