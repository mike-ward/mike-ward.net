// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    public class Workspace
    {
        private string username;
        private string path;
        private byte[] personalization;

        [XmlElement("username")]
        public string UserName
        {
            get { return username ?? string.Empty; }
            set { username = value; }
        }

        [XmlElement("path")]
        public string Path
        {
            get { return path ?? string.Empty; }
            set { path = value; }
        }

        [XmlText(typeof(byte[]))]
        public byte[] PersonalizationBlob
        {
            get { return personalization; }
            set { personalization = value; }
        }
    }
}
