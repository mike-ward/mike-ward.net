// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget.Providers.Data
{
    [Serializable()]
    public class Role
    {
        private string name;
        private List<string> usernames;

        public Role()
        {
            usernames = new List<string>();
        }

        [XmlElement("name")]
        public string Name
        {
            get { return name ?? string.Empty; }
            set { name = value; }
        }

        [XmlElement("user")]
        public Collection<string> Users
        {
            get { return new Collection<string>(usernames); }
        }
    }
}
