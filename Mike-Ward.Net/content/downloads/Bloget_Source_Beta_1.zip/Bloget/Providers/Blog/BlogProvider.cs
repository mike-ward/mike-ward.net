﻿// Copyright (C) 2008 Blue Onion Software
// All rights reserved

using System;
using System.Web.Configuration;
using System.Configuration.Provider;

namespace BlueOnionSoftware.Bloget.Providers
{
    abstract class BlogProvider : System.Configuration.Provider.ProviderBase
    {
        static object padLock = new object();
        static BlogProvider provider;
        static ProviderCollection providers;

        internal abstract Blog Load(string context);
        internal abstract void Save(Blog blog, string context);
        internal abstract Content LoadContent(Guid id, string context);
        internal abstract void SaveContent(Guid id, Content content, string context);

        static internal BlogProvider DefaultProvider
        {
            get { return provider ?? LoadDefaultProvider(); }
        }

        static internal ProviderCollection Providers
        {
            get { return providers ?? LoadProviders(); }
        }

        static BlogProvider LoadDefaultProvider()
        {
            LoadProviders();
            return provider;
        }

        static ProviderCollection LoadProviders()
        {
            lock (padLock) // load only once
            {
                if (provider == null)
                {
                    providers = new ProviderCollection();
                    BlogProviderSection section = (BlogProviderSection)WebConfigurationManager.GetSection("Bloget/blogProvider");

                    if (section == null)
                    {
                        provider = new XmlBlogProvider();
                        provider.Initialize("XmlBlogProvider", null);
                        providers.Add(provider);
                    }

                    else
                    {
                        ProvidersHelper.InstantiateProviders(section.Providers, providers, typeof(BlogProvider));
                        provider = (BlogProvider)providers[section.DefaultProvider];
                    }

                    if (provider == null)
                    {
                        throw new ProviderException("Unable to load default BlogProvider");
                    }
                }
            }

            return providers;
        }

        static internal void LoadProviderForUnitTests()
        {
            lock (padLock) // load only once
            {
                provider = new XmlBlogProvider();
                provider.Initialize("XmlBlogProvider", null);
                providers = new ProviderCollection();
                providers.Add(provider);
            }
        }
    }
}
