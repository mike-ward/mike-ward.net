﻿// Copyright (C) 2008 Blue Onion Software
// All rights reserved

using System;
using System.IO;
using System.Web.Hosting;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget.Providers
{
    class XmlBlogProvider : BlogProvider
    {
        const string NamespaceUri = "urn:blueonionsoftware-com:bloget:runtime:data";

        internal override Blog Load(string context)
        {
            Throw.IfNullOrEmpty(context, "path");

            Blog blog = File.Exists(context)
                ? Utility.Serializer.Load<Blog>(context, NamespaceUri)
                : CreateBlog(context);

            return blog;
        }

        internal override void Save(Blog blog, string context)
        {
            Utility.Serializer.Save<Blog>(context, NamespaceUri, blog);
        }

        internal override Content LoadContent(Guid id, string context)
        {
            Throw.IfEmpty(id, "id");
            Throw.IfNullOrEmpty(context, "path");
            string contentPath = null;
            Content content = null;

            try
            {
                contentPath = ResolvePostContentPath(id, context);
                content = Utility.Serializer.Load<Content>(contentPath, NamespaceUri);
            }

            catch (Exception ex)
            {
                content = new Content();
                content.Text = "Content \"" + contentPath + "\" " + ex.Message;
            }

            return content;
        }

        internal override void SaveContent(Guid id, Content content, string context)
        {
            Throw.IfEmpty(id, "id");
            Throw.IfNull(content, "content");
            Throw.IfNullOrEmpty(context, "path");

            string filename = ResolvePostContentPath(id, context);
            content.LastUpdate = DateTime.UtcNow;
            Utility.Serializer.Save<Content>(filename, NamespaceUri, content);
        }

        Blog CreateBlog(string path)
        {
            if (File.Exists(path))
            {
                throw new InvalidOperationException("XmlBlogProvider: File already exists: " + path);
            }

            Blog blog = new Blog();
            blog.DataContext = path;

            Post post = new Post();
            post.Title = Resources.BlogFirstPostTitle;

            Content content = new Content();
            content.Text = Resources.Welcome.Replace("[post]", post.Id.ToString());
            blog.SaveContent(post.Id, content);

            blog.Posts.Add(post);
            blog.Save();
            return blog;
        }

        string ResolvePostContentPath(Guid id, string path)
        {
            return Path.Combine(Path.GetDirectoryName(path), "C" + id + ".xml");
        }
    }
}
