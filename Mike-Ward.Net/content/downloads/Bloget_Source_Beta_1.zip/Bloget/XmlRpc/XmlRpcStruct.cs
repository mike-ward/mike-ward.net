// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Xml;

namespace BlueOnionSoftware.Bloget
{
    class XmlRpcStruct
    {
        readonly List<XmlRpcMember> members = new List<XmlRpcMember>();

        internal XmlRpcMember[] Members
        {
            get { return members.ToArray(); }
        }

        internal void Add(XmlRpcMember member)
        {
            members.Add(member);
        }

        internal void Serialize(XmlWriter writer)
        {
            Throw.IfNull(writer, "writer");
            writer.WriteStartElement("struct");

            foreach (XmlRpcMember member in members)
            {
                member.Serialize(writer);
            }

            writer.WriteEndElement();
        }
    }
}