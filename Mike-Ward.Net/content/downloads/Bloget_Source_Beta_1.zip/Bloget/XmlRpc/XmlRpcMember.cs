// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Xml;

namespace BlueOnionSoftware.Bloget
{
    class XmlRpcMember
    {
        string name;
        XmlRpcValue xmlRpcValue;

        internal XmlRpcMember()
        {
        }

        internal XmlRpcMember(string name, int intValue)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name");
            }

            this.name = name;
            xmlRpcValue = new XmlRpcValue(intValue);
        }

        internal XmlRpcMember(string name, string stringValue)
        {
            Throw.IfNullOrEmpty(name, "name");
            Throw.IfNull(stringValue, "stringValue"); // OK to be empty

            this.name = name;
            xmlRpcValue = new XmlRpcValue(stringValue);
        }

        internal XmlRpcMember(string name, DateTime dateTimeValue)
        {
            Throw.IfNullOrEmpty(name, "name");

            this.name = name;
            xmlRpcValue = new XmlRpcValue(dateTimeValue);
        }

        internal XmlRpcMember(string name, XmlRpcStruct xmlRpcStruct)
        {
            Throw.IfNullOrEmpty(name, "name");
            Throw.IfNull(xmlRpcStruct, "xmlRpcStruct");

            this.name = name;
            xmlRpcValue = new XmlRpcValue(xmlRpcStruct);
        }

        internal string Name
        {
            get { return name; }

            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("value");
                }

                name = value;
            }
        }

        internal XmlRpcValue Value
        {
            get { return xmlRpcValue; }

            set
            {
                Throw.IfNull(value, "value");
                xmlRpcValue = value;
            }
        }

        internal void Serialize(XmlWriter writer)
        {
            Throw.IfNull(writer, "writer");

            writer.WriteStartElement("member");
            writer.WriteElementString("name", name);
            xmlRpcValue.Serialize(writer);
            writer.WriteEndElement();
        }

        public override string ToString()
        {
            return name + ", " + xmlRpcValue;
        }
    }
}