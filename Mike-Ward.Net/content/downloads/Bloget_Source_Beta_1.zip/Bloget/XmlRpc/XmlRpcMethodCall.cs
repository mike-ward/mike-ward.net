// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

namespace BlueOnionSoftware.Bloget
{
    class XmlRpcMethodCall
    {
        string name;
        readonly List<XmlRpcValue> parameters = new List<XmlRpcValue>();

        internal string Name
        {
            get { return name; }
            set { name = value; }
        }

        internal XmlRpcValue[] Parameters
        {
            get { return parameters.ToArray(); }
        }

        internal void AddParam(XmlRpcValue param)
        {
            Throw.IfNull(param, "param");
            parameters.Add(param);
        }

        public override string ToString()
        {
            XmlWriterSettings xmlSettings = new XmlWriterSettings();
            xmlSettings.Encoding = new UTF8Encoding(false);

            using (MemoryStream stream = new MemoryStream())
            using (XmlWriter writer = XmlWriter.Create(stream, xmlSettings))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("methodCall");
                writer.WriteElementString("methodName", Name);

                foreach (XmlRpcValue value in parameters)
                {
                    value.Serialize(writer);
                }

                writer.WriteEndDocument();
                writer.Flush();
                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }
    }
}