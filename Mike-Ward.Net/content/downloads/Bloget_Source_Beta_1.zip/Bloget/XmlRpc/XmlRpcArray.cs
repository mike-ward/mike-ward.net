// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Xml;

namespace BlueOnionSoftware.Bloget
{
    class XmlRpcArray
    {
        readonly List<XmlRpcValue> values = new List<XmlRpcValue>();

        internal XmlRpcValue[] Values
        {
            get { return values.ToArray(); }
        }

        internal void Add(XmlRpcValue value)
        {
            values.Add(value);
        }

        internal void Serialize(XmlWriter writer)
        {
            Throw.IfNull(writer, "writer");

            writer.WriteStartElement("array");
            writer.WriteStartElement("data");

            foreach (XmlRpcValue value in values)
            {
                value.Serialize(writer);
            }

            writer.WriteEndElement();
            writer.WriteEndElement();
        }
    }
}