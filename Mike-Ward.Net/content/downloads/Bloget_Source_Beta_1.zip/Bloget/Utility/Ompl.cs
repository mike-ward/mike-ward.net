// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Xml;
using System.Diagnostics.CodeAnalysis;

namespace BlueOnionSoftware.Bloget
{
    internal class Opml
    {
        string title = string.Empty;
        DateTime dateCreated = DateTime.Now;
        DateTime dateModified = DateTime.Now;
        string ownerName = string.Empty;
        string ownerEmail = string.Empty;
        readonly OpmlOutlineCollection outlines = new OpmlOutlineCollection();

        internal string Title
        {
            get { return title; }
            set { title = value; }
        }

        internal DateTime DateCreated
        {
            get { return dateCreated; }
            set { dateCreated = value; }
        }

        internal DateTime DateModified
        {
            get { return dateModified; }
            set { dateModified = value; }
        }

        internal string OwnerName
        {
            get { return ownerName; }
            set { ownerName = value; }
        }

        internal string OwnerEmail
        {
            get { return ownerEmail; }
            set { ownerEmail = value; }
        }

        internal OpmlOutlineCollection Outlines
        {
            get { return outlines; }
        }

        internal void AddOutline(OpmlOutline item)
        {
            outlines.Add(item);
        }

        internal void AddOutline(string titleArg, string descriptionArg)
        {
            AddOutline(titleArg, descriptionArg, null, null, null);
        }

        internal void AddOutline(string titleArg, string descriptionArg, Uri htmlUrlArg, Uri xmlUrlArg,
                               OpmlOutlineCollection outlinesArg)
        {
            OpmlOutline item = new OpmlOutline();
            item.Title = titleArg;
            item.Description = descriptionArg;
            item.HtmlUrl = htmlUrlArg;
            item.XmlUrl = xmlUrlArg;
            item.AddOutlines(outlinesArg);
            outlines.Add(item);
        }

        internal void Save(Stream stream)
        {
            Throw.IfNull(stream, "stream");

            XmlDocument opmlDoc = new XmlDocument();
            XmlElement opml = opmlDoc.CreateElement("opml");
            opml.SetAttribute("version", "1.1");
            opmlDoc.AppendChild(opml);

            XmlElement headElement = opmlDoc.CreateElement("head");
            opml.AppendChild(headElement);

            XmlElement titleElement = opmlDoc.CreateElement("title");
            titleElement.InnerText = Title;
            headElement.AppendChild(titleElement);

            XmlElement dateCreatedElement = opmlDoc.CreateElement("dateCreated");
            dateCreatedElement.InnerText = DateCreated.ToString("r", CultureInfo.InvariantCulture);
            headElement.AppendChild(dateCreatedElement);

            XmlElement dateModifiedElement = opmlDoc.CreateElement("dateModified");
            dateModifiedElement.InnerText = DateModified.ToString("r", CultureInfo.InvariantCulture);
            headElement.AppendChild(dateModifiedElement);

            XmlElement ownerEmailElement = opmlDoc.CreateElement("ownerEmail");
            ownerEmailElement.InnerText = OwnerEmail;
            headElement.AppendChild(ownerEmailElement);

            XmlElement ownerNameElement = opmlDoc.CreateElement("ownerName");
            ownerNameElement.InnerText = OwnerName;
            headElement.AppendChild(ownerNameElement);

            XmlElement opmlBodyElement = opmlDoc.CreateElement("body");
            opml.AppendChild(opmlBodyElement);

            foreach (OpmlOutline outline in outlines)
            {
                opmlBodyElement.AppendChild(OutlineToXML(opmlDoc, outline));
            }

            opmlDoc.Save(stream);
        }

        static XmlElement OutlineToXML(XmlDocument opmlDoc, OpmlOutline outline)
        {
            XmlElement outlineNode = opmlDoc.CreateElement("outline");

            if (String.IsNullOrEmpty(outline.Title) == false)
            {
                outlineNode.SetAttribute("title", outline.Title);
            }

            if (String.IsNullOrEmpty(outline.Text) == false)
            {
                outlineNode.SetAttribute("text", outline.Text);
            }

            if (String.IsNullOrEmpty(outline.Description) == false)
            {
                outlineNode.SetAttribute("description", outline.Description);
            }

            if (String.IsNullOrEmpty(outline.Type) == false)
            {
                outlineNode.SetAttribute("type", outline.Type);
            }

            if (outline.HtmlUrl != null)
            {
                outlineNode.SetAttribute("htmlUrl", outline.HtmlUrl.ToString());
            }

            if (outline.XmlUrl != null)
            {
                outlineNode.SetAttribute("xmlUrl", outline.XmlUrl.ToString());
            }

            foreach (OpmlOutline childOutline in outline.Outlines)
            {
                outlineNode.AppendChild(OutlineToXML(opmlDoc, childOutline));
            }

            return outlineNode;
        }

        internal static Opml Parse(Stream stream)
        {
            Throw.IfNull(stream, "stream");

            XmlDocument opmlDoc = new XmlDocument();
            opmlDoc.Load(stream);

            // Parse headNode
            XmlNode headNode = opmlDoc.GetElementsByTagName("head")[0];
            XmlNode titleNode = headNode.SelectSingleNode("./title");
            XmlNode dateCreatedNode = headNode.SelectSingleNode("./dateCreated");
            XmlNode dateModifiedNode = headNode.SelectSingleNode("./dateModified");
            XmlNode ownerNameNode = headNode.SelectSingleNode("./ownerName");
            XmlNode ownerEmailNode = headNode.SelectSingleNode("./ownerEmail");

            Opml opml = new Opml();

            if (titleNode != null)
            {
                opml.Title = titleNode.InnerText;
            }

            if (dateCreatedNode != null)
            {
                DateTime created;

                if (DateTime.TryParse(dateCreatedNode.InnerText, out created))
                {
                    opml.DateCreated = created;
                }
            }

            if (dateModifiedNode != null)
            {
                DateTime modified;

                if (DateTime.TryParse(dateModifiedNode.InnerText, out modified))
                {
                    opml.DateModified = modified;
                }
            }

            if (ownerNameNode != null)
            {
                opml.OwnerName = ownerNameNode.InnerText;
            }

            if (ownerEmailNode != null)
            {
                opml.OwnerEmail = ownerEmailNode.InnerText;
            }

            // Parse body
            XmlNodeList nodeList = opmlDoc.GetElementsByTagName("body");

            if (nodeList != null && nodeList[0] != null)
            {
                XmlNode body = nodeList[0];
                XmlNodeList outlineList = body.SelectNodes("./outline");

                foreach (XmlElement outline in outlineList)
                {
                    opml.Outlines.Add(ParseContent(outline));
                }
            }

            return opml;
        }

        static OpmlOutline ParseContent(XmlElement xmlNode)
        {
            OpmlOutline outline = new OpmlOutline();

            outline.Title = xmlNode.GetAttribute("title");
            outline.Text = xmlNode.GetAttribute("text");
            outline.Description = xmlNode.GetAttribute("description");
            outline.Type = xmlNode.GetAttribute("type");

            Uri htmlUrl;
            if (Uri.TryCreate(xmlNode.GetAttribute("htmlUrl"), UriKind.RelativeOrAbsolute, out htmlUrl))
            {
                outline.HtmlUrl = htmlUrl;
            }

            Uri xmlUrl;
            if (Uri.TryCreate(xmlNode.GetAttribute("xmlUrl"), UriKind.RelativeOrAbsolute, out xmlUrl))
            {
                outline.XmlUrl = xmlUrl;
            }

            if (xmlNode.HasChildNodes)
            {
                foreach (XmlElement childNode in xmlNode.SelectNodes("./outline"))
                {
                    outline.AddOutline(ParseContent(childNode));
                }
            }

            return outline;
        }
    }

    internal class OpmlOutlineCollection : List<OpmlOutline>
    {
    }

    public class OpmlOutline
    {
        Uri htmlUrl;
        Uri xmlUrl;
        readonly OpmlOutlineCollection outlines = new OpmlOutlineCollection();
        string title = string.Empty;
        string description = string.Empty;
        string text = string.Empty;
        string type = string.Empty;

        internal string Description
        {
            get { return description; }
            set { description = value; }
        }

        internal string Title
        {
            get { return title; }
            set { title = value; }
        }

        internal string Type
        {
            get { return type; }
            set { type = value; }
        }

        internal string Text
        {
            get { return text; }
            set { text = value; }
        }

        internal Uri HtmlUrl
        {
            get { return htmlUrl; }
            set { htmlUrl = value; }
        }

        internal Uri XmlUrl
        {
            get { return xmlUrl; }
            set { xmlUrl = value; }
        }

        internal OpmlOutlineCollection Outlines
        {
            get { return outlines; }
        }

        internal void ClearOutlines()
        {
            outlines.Clear();
        }

        internal void AddOutline(OpmlOutline outline)
        {
            outlines.Add(outline);
        }

        internal void AddOutlines(OpmlOutlineCollection outlineCollection)
        {
            outlines.AddRange(outlineCollection);
        }
    }
}