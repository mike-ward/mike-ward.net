// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.IO;
using System.Collections.Generic;

namespace BlueOnionSoftware.Bloget
{
    class NonContiguousMemoryStream : Stream
    {
        readonly int bufferStoreSize = 8 * 1024;
        readonly List<byte[]> buffersStore = new List<byte[]>();
        long position;
        long length;
        bool disposed;

        public override bool CanRead
        {
            get
            {
                if (disposed)
                {
                    throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
                }

                return true;
            }
        }

        public override bool CanSeek
        {
            get
            {
                if (disposed)
                {
                    throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
                }

                return true;
            }
        }

        public override bool CanWrite
        {
            get
            {
                if (disposed)
                {
                    throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
                }

                return true;
            }
        }

        public override void Flush()
        {
        }

        public override long Length
        {
            get
            {
                if (disposed)
                {
                    throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
                }

                return length;
            }
        }

        public override long Position
        {
            get
            {
                if (disposed)
                {
                    throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
                }

                return position;
            }

            set
            {
                if (disposed)
                {
                    throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
                }

                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "position >= 0");
                }

                position = value;
            }
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            if (disposed)
            {
                throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
            }

            if (buffer == null)
            {
                throw new ArgumentNullException("buffer");
            }

            if (offset < 0 || offset > buffer.Length)
            {
                throw new ArgumentOutOfRangeException("offset", offset, "0 <= offset < buffer.Length");
            }

            if (count < 0 || count > buffer.Length)
            {
                throw new ArgumentOutOfRangeException("count", count, "0 <= count < buffer.Length");
            }

            int end = Math.Min(buffer.Length, offset + count);
            int startingOffset = offset;
            int buffersStoreIndex = (int)(position / bufferStoreSize);
            int bufferStoreOffset = (int)(position % bufferStoreSize);

            while ((offset < end) && (position < length))
            {
                byte[] bufferStore = buffersStore[buffersStoreIndex];
                int run = Math.Min(end - offset, bufferStoreSize - bufferStoreOffset);
                Buffer.BlockCopy(bufferStore, bufferStoreOffset, buffer, offset, run);
                offset += run;
                bufferStoreOffset += run;
                position += run;

                if (bufferStoreOffset == bufferStoreSize && position < length)
                {
                    buffersStoreIndex += 1;
                    bufferStoreOffset = 0;
                }
            }

            return (offset - startingOffset);
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            if (disposed)
            {
                throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
            }

            switch (origin)
            {
                case SeekOrigin.Begin:
                    position = offset;
                    break;

                case SeekOrigin.Current:
                    position += offset;
                    break;

                case SeekOrigin.End:
                    position = length - 1 + offset;
                    break;

                default:
                    throw new ArgumentException("Invalid SeekOrgin enumeration", "origin");
            }

            if (position < 0 || position >= length)
            {
                throw new ArgumentOutOfRangeException("0 <= (offset + orgin) < stream.Length");
            }

            return position;
        }

        public override void SetLength(long value)
        {
            throw new System.NotImplementedException();
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            if (disposed)
            {
                throw new ObjectDisposedException(typeof(NonContiguousMemoryStream).ToString());
            }

            if (buffer == null)
            {
                throw new ArgumentNullException("buffer");
            }

            if (offset < 0 || offset >= buffer.Length)
            {
                throw new ArgumentOutOfRangeException("offset", offset, "0 <= offset < buffer.Length");
            }

            if (count < 0 || count > buffer.Length)
            {
                throw new ArgumentOutOfRangeException("count", count, "0 <= count < buffer.Length");
            }

            if ((offset + count) > buffer.Length)
            {
                throw new ArgumentOutOfRangeException("offset + count", (offset + count), "(offset + count) <= buffer.Length");
            }

            while ((position + count) > (buffersStore.Count * bufferStoreSize))
            {
                buffersStore.Add(new byte[bufferStoreSize]);
            }

            int end = offset + count;
            int buffersStoreIndex = (int)(position / bufferStoreSize);
            int bufferStoreOffset = (int)(position % bufferStoreSize);

            while (offset < end)
            {
                byte[] bufferStore = buffersStore[buffersStoreIndex];
                int run = Math.Min(end - offset, bufferStoreSize - bufferStoreOffset);
                Buffer.BlockCopy(buffer, offset, bufferStore, bufferStoreOffset, run);
                offset += run;
                bufferStoreOffset += run;

                if (bufferStoreOffset == bufferStoreSize && offset < end)
                {
                    buffersStoreIndex += 1;
                    bufferStoreOffset = 0;
                }
            }

            position += count;

            if (position > length)
            {
                length = position;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                disposed = true;
                base.Dispose(disposing);
            }
        }
    }
}
