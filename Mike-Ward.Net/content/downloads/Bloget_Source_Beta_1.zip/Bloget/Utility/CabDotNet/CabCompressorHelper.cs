﻿// Copyright (C) 2008 Blue Onion Software
// All rights reserved

using Mischel.CabDotNet;
using System;
using System.IO;

namespace BlueOnionSoftware.Bloget
{
    class CabCompressorHelper : IDisposable
    {
        bool disposed;
        CabCompressor compressor = new CabCompressor();

        internal CabCompressorHelper()
        {
            InitializeCabParameters();
        }

        void InitializeCabParameters()
        {
            compressor.CabInfo.MaxCabinetSize = int.MaxValue;
            compressor.CabInfo.MaxFolderSize = int.MaxValue;

            // Don't reserve space for any extensions
            compressor.CabInfo.HeaderReserve = 0;
            compressor.CabInfo.FolderReserve = 0;
            compressor.CabInfo.DataReserve = 0;

            // We use this to create the cabinet name
            compressor.CabInfo.CabinetNumber = 1;

            // store name of first CAB file
            compressor.CabInfo.CabName = ".CAB";

            // If you want to use disk names, use this to count disks
            compressor.CabInfo.DiskNumber = 0;

            // Choose your own SetId
            compressor.CabInfo.SetId = 10293;

            // Only important if CABs are spanning multiple disks,
            // in which case you will want to use a real disk name.
            //
            // Can be left as an empty string.
            compressor.CabInfo.DiskName = string.Empty;

            // where to store the created CAB files
            compressor.CabInfo.CabPath = "Bloget";

            ClientState cs = new ClientState();
            cs.totalCompressedSize = 0;
            cs.totalUncompressedSize = 0;
            compressor.UserData = cs;
        }

        internal void AddFile(string name)
        {
            Throw.IfNullOrEmpty(name, "name");
            compressor.AddFile(Path.GetFullPath(name), Path.GetFileName(name), false, FciCompression.MsZip);
        }

        public void Dispose()
        {
            if (disposed == false)
            {
                disposed = true;
                compressor.FlushCabinet();
                compressor.Dispose();
            }
        }

        internal class ClientState
        {
            internal int totalCompressedSize;   /* total compressed size so far */
            internal int totalUncompressedSize; /* total uncompressed size so far */
        }
    }
}
