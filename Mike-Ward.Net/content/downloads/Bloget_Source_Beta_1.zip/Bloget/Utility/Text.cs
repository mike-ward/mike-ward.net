// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.Globalization;

namespace BlueOnionSoftware.Bloget
{
    static class Text
    {
        internal static string ButtonPadding(string text)
        {
            // spaces around text makes buttons look nicer in some browsers
            return string.Format(CultureInfo.CurrentCulture, "  {0}  ", text ?? "null value");
        }
    }
}