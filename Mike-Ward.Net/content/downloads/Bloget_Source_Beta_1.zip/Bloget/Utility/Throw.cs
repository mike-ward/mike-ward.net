﻿// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;

namespace BlueOnionSoftware.Bloget
{
    sealed class Throw
    {
        const string notSpecified = "not specified";

        static internal void IfNull(object arg, string name)
        {
            if (arg == null)
            {
                throw new ArgumentNullException(name ?? notSpecified);
            }
        }

        static internal void IfNullOrEmpty(string arg, string name)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw (arg == null)
                    ? new ArgumentNullException(name ?? notSpecified)
                    : new ArgumentException("empty", name ?? notSpecified);
            }
        }

        static internal void IfEmpty(Guid guid, string name)
        {
            if (guid == Guid.Empty)
            {
                throw new ArgumentException("empty", name ?? notSpecified);
            }
        }
    }
}
