// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Web.Configuration;
using System.Web.Hosting;

namespace BlueOnionSoftware.Bloget
{
    enum LogCategory
    {
        None,
        Error = 100,
        Authorization = 200,
        Administration = 201,
        EditUserSetting = 202,
        RpcRequest = 300,
        PingBack = 301,
        RpcRequestAccepted = 302,
        RpcRequestRejected = 303,
        Posting = 400,
        Ping = 401
    }

    static class Log
    {
        static readonly ThreadSafeQueue queue;
        static readonly AutoResetEvent spoolEvent;
        static readonly string virtualLogFolder;

        static Log()
        {
            queue = new ThreadSafeQueue();
            spoolEvent = new AutoResetEvent(false);
            virtualLogFolder = VirtualLogFolderSetting();
            ThreadPool.RegisterWaitForSingleObject(spoolEvent, spoolerProc, null, -1, false);
        }

        internal static string VirtualLogFolder
        {
            get { return virtualLogFolder; }
        }

        internal static string LogFilePattern
        {
            get { return "????-??-??.bloget.log"; }
        }

        internal static void NewPost(Bloget bloget, Guid postId, string title)
        {
            Add(LogCategory.Posting, bloget, "New post - {0} ({1})", title, postId);
        }

        internal static void EditPost(Bloget bloget, Guid postId, string title)
        {
            Add(LogCategory.Posting, bloget, "Edit post - {0} ({1})", title, postId);
        }

        internal static void RemovePost(Bloget bloget, Guid postId)
        {
            Add(LogCategory.Posting, bloget, "Remove post - {0}", postId);
        }

        internal static void GetPost(Bloget bloget, Guid postId)
        {
            Add(LogCategory.Posting, bloget, "Get post - {0}", postId);
        }

        internal static void NewComment(Bloget bloget, string postTitle, Guid commentId)
        {
            Add(LogCategory.Posting, bloget, "New comment - {0}({1})", postTitle, commentId);
        }

        internal static void RejectComment(Bloget bloget, string postTitle, string comment)
        {
            Add(LogCategory.Posting, bloget, "Reject comment - {0}({1})", postTitle,
                comment.Substring(0, Math.Min(256, comment.Length)));
        }

        internal static void RemoveComment(Bloget bloget, string postTitle, Guid commentId)
        {
            Add(LogCategory.Posting, bloget, "Remove comment - {0}({1})", postTitle, commentId);
        }

        internal static void EmailSent(Bloget bloget, string from, string to, string subject)
        {
            Add(LogCategory.Posting, bloget, "Email sent - From:{0} To:{1} Subject:{2}", from, to, subject);
        }

        internal static void Login(Bloget bloget)
        {
            Add(LogCategory.Authorization, bloget, "Login");
        }

        internal static void Logout(Bloget bloget)
        {
            Add(LogCategory.Authorization, bloget, "Logout");
        }

        internal static void LoginFail(Bloget bloget)
        {
            Add(LogCategory.Error, bloget, "Login attempt failed");
        }

        internal static void LicenseAgreementAccepted(Bloget bloget)
        {
            Add(LogCategory.Authorization, bloget, "License agreement accepted");
        }

        internal static void PingFailed(Bloget bloget, string link, string error)
        {
            Add(LogCategory.Error, bloget, "Ping failed ({1}) {0}", link, error);
        }

        internal static void PingSucceeded(Bloget bloget, string link, string message)
        {
            Add(LogCategory.Ping, bloget, "Ping succeeded ({1}) {0}", link, message);
        }

        internal static void PingBackReceived(Bloget bloget, string source, string target)
        {
            Add(LogCategory.PingBack, bloget, "Pingback received {0}, {1}", source, target);
        }

        internal static void PingBackFailed(Bloget bloget, string source, string target, string reason)
        {
            Add(LogCategory.RpcRequestRejected, bloget, "Pingback rejected ({2}) {0}, {1}", source, target, reason);
        }

        internal static void RemovePingBack(Bloget bloget, Guid postId, Guid pingBackId)
        {
            Add(LogCategory.PingBack, bloget, "Remove pingback - {0}({1})", postId, pingBackId);
        }

        internal static void RpcRequest(Bloget bloget, string methodCall)
        {
            Add(LogCategory.RpcRequest, bloget, "Received RPC Request: {0}", methodCall);
        }

        internal static void RpcRequestAccepted(Bloget bloget, string methodCall)
        {
            Add(LogCategory.RpcRequestAccepted, bloget, "RPC Request: {0} accepted", methodCall);
        }

        internal static void RpcRequestRejected(Bloget bloget, string methodCall, string reason)
        {
            Add(LogCategory.RpcRequestRejected, bloget, "RPC Request: {0} rejected : {1}", methodCall, reason);
        }

        internal static void Administration(Bloget bloget, string setting, string oldValue, string newValue)
        {
            Add(LogCategory.Administration, bloget, "Admin: {0} = {2} ({1})", setting, oldValue, newValue);
        }

        internal static void EditUser(Bloget bloget, string user, string action)
        {
            Add(LogCategory.EditUserSetting, bloget, "EditUser: {0}, Action: {2}", user, action);
        }

        internal static void Exception(Bloget bloget, string where, Exception ex)
        {
            Add(LogCategory.Error, bloget, "Exception in {0} - {1}", where, ex.Message);
        }

        internal static void ExceptionStackTrace(Bloget bloget, string where, Exception ex)
        {
            Add(LogCategory.Error, bloget, "Exception in {0} - {1}", where, ex.ToString());
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        static void Add(LogCategory logCategory, Bloget bloget, string format, params object[] args)
        {
            try
            {
                // Copy the strings so a reference to the control is not held
                string id = string.Copy(bloget.ID ?? "no-id");
                string referrer;

                try
                {
                    // Accessing Request cross thread (like in pingbacks) can raise exceptions
                    referrer = string.Copy((bloget.Page.Request.UrlReferrer != null)
                                               ? bloget.Page.Request.UrlReferrer.AbsoluteUri
                                               : bloget.Page.Request.ServerVariables["REMOTE_ADDR"]);
                }

                catch (Exception)
                {
                    referrer = "no-referrer";
                }

                string message = string.Format(CultureInfo.InvariantCulture, format, args);
                LogDataItem logDataItem = new LogDataItem(logCategory, DateTime.UtcNow, id, referrer, message);
                queue.Enqueue(logDataItem.ToString());
                spoolEvent.Set();
            }

            catch (Exception ex)
            {
                Debug.Assert(false, ex.Message, ex.ToString());
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        static void spoolerProc(object state, bool timeout)
        {
            try
            {
                string virtualLogPath = string.Format(CultureInfo.InvariantCulture,
                                                      "{0}{1}.bloget.log", virtualLogFolder,
                                                      DateTime.UtcNow.ToString("yyyy-MM-dd",
                                                                               CultureInfo.InvariantCulture));

                string physicalLogPath = HostingEnvironment.MapPath(virtualLogPath);

                using (FileStream logStream = FileUtilities.OpenAppend(physicalLogPath))
                using (StreamWriter logWriter = new StreamWriter(logStream))
                {
                    string message;

                    while ((message = queue.Dequeue()) != null)
                    {
                        logWriter.WriteLine(message);
                    }
                }
            }

            catch (Exception ex)
            {
                Debug.Assert(false, ex.Message, ex.ToString());
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        static string VirtualLogFolderSetting()
        {
            string result = "~/App_Data/";

            try
            {
                // Assumption: web.config is in the root path of the web application

                string folder = WebConfigurationManager.AppSettings["BlogetLogFolder"];

                if (string.IsNullOrEmpty(folder) == false)
                {
                    folder = folder.Trim();

                    if (folder.StartsWith("~", StringComparison.Ordinal))
                    {
                        if (folder.EndsWith("/", StringComparison.Ordinal) == false)
                        {
                            folder += "/";
                        }

                        result = folder;
                    }
                }
            }

            catch (Exception ex)
            {
                Debug.Assert(false, ex.Message, ex.ToString());
            }

            return result;
        }
    }

    class ThreadSafeQueue
    {
        readonly object synchronize = new object();
        readonly Queue<string> queue = new Queue<string>();

        internal void Enqueue(string message)
        {
            lock (synchronize)
            {
                if (queue.Count >= 1000)
                {
                    queue.Dequeue();
                }

                queue.Enqueue(message);
            }
        }

        internal string Dequeue()
        {
            lock (synchronize)
            {
                return (queue.Count > 0) ? queue.Dequeue() : null;
            }
        }
    }

    class LogDataItem
    {
        readonly LogCategory logCategory;
        readonly DateTime time;
        string message;
        readonly string referrer;
        readonly string controlID;

        internal LogDataItem(LogCategory logCategory, DateTime time, string controlID, string referrer, string message)
        {
            this.logCategory = logCategory;
            this.time = time;
            this.referrer = referrer ?? string.Empty;
            this.message = message ?? string.Empty;
            this.controlID = controlID ?? string.Empty;
        }

        public override string ToString()
        {
            message = message.Replace('\r', ' ');
            message = message.Replace('\n', ' ');

            return string.Format(CultureInfo.InvariantCulture,
                                 "{0} {1:s} {2,-15} {3,-15} {4}", Enum.Format(typeof (LogCategory), logCategory, "d"),
                                 time, controlID, referrer, message);
        }
    }
}