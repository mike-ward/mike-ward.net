// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.Collections;
using System.Globalization;

namespace BlueOnionSoftware.Bloget
{
    class ReverseCompare : IComparer
    {
        int IComparer.Compare(object left, object right)
        {
            return ((new CaseInsensitiveComparer(CultureInfo.CurrentCulture)).Compare(right, left));
        }
    }
}