// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Caching;
using System.Web.Hosting;
using BlueOnionSoftware.Bloget.Properties;

namespace BlueOnionSoftware.Bloget
{
    static class Search
    {
        const string searchCache = "searchCache";

        // remove all whitespace
        static readonly Regex regexWhitespace = new Regex(@"\s+", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        // Remove all html tags
        static readonly Regex regexAll = new Regex("<(.|\n)*?>", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        // Stopwords (will give a cleaner result)
        static readonly Collection<string> stopWords = GetStopWords();

        // don't search while building
        static bool buildingConcordance;

        class Concordance : KeyedCollection<string, ConcordanceItem>
        {
            protected override string GetKeyForItem(ConcordanceItem item)
            {
                return item.Word;
            }
        }

        class ConcordanceItem
        {
            string word;
            readonly Collection<Post> posts = new Collection<Post>();

            public string Word
            {
                get { return word; }
                set { word = value; }
            }

            public Collection<Post> Posts
            {
                get { return posts; }
            }
        }

        class Match
        {
            int rank;
            Post post;

            public int Rank
            {
                get { return rank; }
                set { rank = value; }
            }

            public Post Post
            {
                get { return post; }
                set { post = value; }
            }
        }

        class MatchCollection : KeyedCollection<Post, Match>
        {
            protected override Post GetKeyForItem(Match item)
            {
                return item.Post;
            }
        }

        static int CompareByRank(Match x, Match y)
        {
            int compare = y.Rank.CompareTo(x.Rank); // reverse order

            if (compare == 0)
            {
                compare = y.Post.Created.CompareTo(x.Post.Created);
            }

            return compare;
        }

        /// <summary>
        /// Returns a array of maxPosts that match the search terms. Posts are ordered from most relevant
        /// to least relevant.
        /// </summary>
        /// <param name="bloget">reference to the hosting bloget control</param>
        /// <param name="query">each word (seperarated by whitespace) is queried (and)</param>
        /// <returns></returns>
        internal static Post[] Find(Bloget bloget, string query)
        {
            string findCache = "find_" + query;

            Post[] posts = HostingEnvironment.Cache[findCache] as Post[];

            if (posts != null)
            {
                return posts;
            }

            Concordance concordance = HostingEnvironment.Cache[searchCache] as Concordance;

            if (concordance == null && buildingConcordance == false)
            {
                buildingConcordance = true;
                ThreadPool.QueueUserWorkItem(BuildConcordance, bloget);
            }

            if (concordance == null || buildingConcordance == true)
            {
                return new Post[0];
            }

            Match[] matches = FindMatchingPosts(query, concordance);
            posts = new Post[matches.Length];

            for (int i = posts.Length - 1; i >= 0; --i)
            {
                posts[i] = matches[i].Post;
            }

            HostingEnvironment.Cache.Add(findCache, posts, null, Cache.NoAbsoluteExpiration,
                                         new TimeSpan(0, 1, 0), CacheItemPriority.Default, null);

            return posts;
        }

        static Match[] FindMatchingPosts(string query, IEnumerable<ConcordanceItem> concordance)
        {
            MatchCollection matchCollection = new MatchCollection();
            string[] searchWords = query.ToUpperInvariant().Split();

            foreach (string word in searchWords)
            {
                foreach (ConcordanceItem ci in concordance)
                {
                    if (ci.Word.Contains(word))
                    {
                        foreach (Post post in ci.Posts)
                        {
                            if (matchCollection.Contains(post))
                            {
                                matchCollection[post].Rank += 1;
                            }

                            else
                            {
                                Match match = new Match();
                                match.Post = post;
                                matchCollection.Add(match);
                            }
                        }
                    }
                }
            }

            Match[] matches = new Match[matchCollection.Count];

            for (int i = 0; i < matches.Length; ++i)
            {
                matches[i] = matchCollection[i];
            }

            Array.Sort(matches, CompareByRank);
            return matches;
        }

        static void BuildConcordance(object stateInfo)
        {
            const string space = " ";
            const int titleWeightingFactor = 15;
            const int categoryWeightingFactor = 20;
            Bloget bloget = (Bloget)stateInfo;
            Concordance concordance = new Concordance();

            // Build the index by reading every post
            foreach (Post post in bloget.Blog.Posts)
            {
                // Add searchable items
                StringBuilder buildContent = new StringBuilder();
                string title = post.Title.ToUpperInvariant() + space;

                for (int i = 0; i < titleWeightingFactor; i++)
                {
                    buildContent.Append(title);
                }

                foreach (int tag in post.Tags)
                {
                    if (bloget.Blog.Categories.Contains(tag))
                    {
                        string category = bloget.Blog.Categories[tag].Name.ToUpperInvariant() + space;

                        for (int i = 0; i < categoryWeightingFactor; i++)
                        {
                            buildContent.Append(category);
                        }
                    }
                }

                Content content = bloget.Blog.LoadContent(post.Id);
                buildContent.Append(content.Text);
                string tempContent = buildContent.ToString();

                // 1. remove all HTML - TODO: remove javascript here...
                tempContent = regexAll.Replace(tempContent, string.Empty);

                // 2. compress all whitespace to one space
                tempContent = regexWhitespace.Replace(tempContent, space);

                // 3. ensure no space
                tempContent = tempContent.Trim().ToUpperInvariant();

                // split every wordArg
                string[] words = tempContent.Split();

                foreach (string word in words)
                {
                    if (stopWords.Contains(word) == false)
                    {
                        if (concordance.Contains(word))
                        {
                            if (concordance[word].Posts.Contains(post) == false)
                            {
                                concordance[word].Posts.Add(post);
                            }
                        }

                        else
                        {
                            ConcordanceItem concordanceItem = new ConcordanceItem();
                            concordanceItem.Word = word;
                            concordanceItem.Posts.Add(post);
                            concordance.Add(concordanceItem);
                        }
                    }
                }
            }

            using (CacheDependency cd = new CacheDependency(HostingEnvironment.MapPath(bloget.DataContext)))
            {
                HostingEnvironment.Cache.Insert(searchCache, concordance, cd);
            }

            buildingConcordance = false;
        }

        static Collection<string> GetStopWords()
        {
            string[] words = Resources.StopWords.Split();
            Collection<string> stopWordsCollection = new Collection<string>();

            foreach (string word in words)
            {
                stopWordsCollection.Add(word);
            }

            return stopWordsCollection;
        }
    }
}