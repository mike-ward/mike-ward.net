// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;

namespace BlueOnionSoftware.Bloget
{
    public class ArchiveDate : IComparable<ArchiveDate>
    {
        DateTime date;
        int count;

        public ArchiveDate(DateTime dateArg, int countArg)
        {
            date = dateArg;
            count = countArg;
        }

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public int CompareTo(ArchiveDate other)
        {
            if (!(other is ArchiveDate))
            {
                throw new ArgumentException("other is not an ArchiveDate");
            }

            return DateTime.Compare(date, other.date);
        }

        public override int GetHashCode()
        {
            return date.GetHashCode();
        }

        [SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
        public override bool Equals(object obj)
        {
            if (!(obj is ArchiveDate))
            {
                return false;
            }

            return (CompareTo((ArchiveDate)obj) == 0);
        }

        public static bool operator ==(ArchiveDate left, ArchiveDate right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(ArchiveDate left, ArchiveDate right)
        {
            return !(left == right);
        }

        public static bool operator >(ArchiveDate left, ArchiveDate right)
        {
            return left.CompareTo(right) > 0;
        }

        public static bool operator <(ArchiveDate left, ArchiveDate right)
        {
            return left.CompareTo(right) < 0;
        }
    }

    public class ArchiveDateCollection : KeyedCollection<DateTime, ArchiveDate>
    {
        protected override DateTime GetKeyForItem(ArchiveDate item)
        {
            return item.Date;
        }

        internal ArchiveDate[] ToArray()
        {
            ArchiveDate[] dates = new ArchiveDate[Count];

            for (int i = 0; i < Count; ++i)
            {
                dates[i] = this[i];
            }

            return dates;
        }
    }
}