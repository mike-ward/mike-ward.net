// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Web;
using System.IO.Compression;
using System.Diagnostics.CodeAnalysis;

namespace BlueOnionSoftware.Bloget
{
    // Original source:
    // http://www.madskristensen.dk/blog/PermaLink,guid,60533e14-789d-41a1-92d2-43efddce7d8e.aspx

    public sealed class HttpCompressionModule : IHttpModule
    {
        const string GZIP = "gzip";
        const string DEFLATE = "deflate";
        static readonly string[] exceptions = { "=RSS", "=RPC", ".AXD" };

        void IHttpModule.Init(HttpApplication context)
        {
            context.BeginRequest += BeginRequest;
        }

        static void BeginRequest(object sender, EventArgs e)
        {
            if (RequestContains(exceptions) == false)
            {
                HttpApplication app = sender as HttpApplication;

                if (app != null)
                {
                    if (EncodingAccepted(DEFLATE))
                    {
                        app.Response.Filter = new DeflateStream(app.Response.Filter, CompressionMode.Compress);
                        SetEncoding(DEFLATE);
                    }

                    else if (EncodingAccepted(GZIP))
                    {
                        app.Response.Filter = new GZipStream(app.Response.Filter, CompressionMode.Compress);
                        SetEncoding(GZIP);
                    }
                }
            }
        }

        static bool RequestContains(IEnumerable<string> values)
        {
            string request = HttpContext.Current.Request.Url.AbsoluteUri.ToUpperInvariant();
            
            foreach (string value in values)
            {
                if (request.Contains(value))
                {
                    return true;
                }
            }

            return false;
        }

        static bool EncodingAccepted(string encoding)
        {
            string acceptEncoding = HttpContext.Current.Request.Headers["Accept-encoding"] ?? string.Empty;
            return acceptEncoding.Contains(encoding);
        }

        static void SetEncoding(string encoding)
        {
            HttpContext.Current.Response.AppendHeader("Content-encoding", encoding);
        }

        void IHttpModule.Dispose()
        {
        }
    }
}
