// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget
{
    [XmlRoot("attachment")]
    public class Attachment
    {
        string url = string.Empty;
        string mimeType = string.Empty;
        string attachmentType = string.Empty;
        long length;

        public Attachment()
        {
        }

        internal Attachment(Attachment attachment)
        {
            url = attachment.url;
            mimeType = attachment.mimeType;
            attachmentType = attachment.attachmentType;
            length = attachment.length;
        }

        internal string Name
        {
            get
            {
                int last = url.LastIndexOf('/');
                return (last == -1) ? url : url.Substring(last + 1);
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings"), XmlElement("url")]
        public string Url
        {
            get { return url; }
            set { url = value; }
        }

        [XmlElement("mime_type")]
        public string MimeType
        {
            get { return mimeType; }
            set { mimeType = value; }
        }

        [XmlElement("attachment_type")]
        public string AttachmentType
        {
            get { return attachmentType; }
            set { attachmentType = value; }
        }

        [XmlElement("length")]
        public long Length
        {
            get { return length; }
            set { length = value; }
        }

        public override string ToString()
        {
            const int kiloByte = 1024;
            const int megaByte = kiloByte*kiloByte;

            return string.Format(CultureInfo.CurrentCulture, "{0} ({1:#.##}) {2}", Name,
                                 (length > megaByte) ? (((double) length)/megaByte) : (((double) length)/kiloByte),
                                 (length > megaByte) ? "MB" : "KB");
        }
    }

    public class AttachmentCollection : Collection<Attachment>
    {
        public AttachmentCollection()
        {
        }

        internal AttachmentCollection(IEnumerable<Attachment> attachmentCollection)
        {
            foreach (Attachment attachment in attachmentCollection)
            {
                Add(new Attachment(attachment));
            }
        }
    }
}