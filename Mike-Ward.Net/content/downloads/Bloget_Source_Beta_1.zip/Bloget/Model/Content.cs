// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget
{
    [XmlRoot(ElementName = "Content")]
    public class Content
    {
        string text = string.Empty;
        DateTime lastUpdate = DateTime.UtcNow;
        string sourceTitle = string.Empty;
        string sourceLink = string.Empty;
        CommentCollection comments = new CommentCollection();
        ReferenceCollection references = new ReferenceCollection();
        AttachmentCollection attachments = new AttachmentCollection();

        public Content()
        {
        }

        internal Content(Content content)
        {
            text = content.text;
            lastUpdate = content.lastUpdate;
            sourceTitle = content.sourceTitle;
            sourceLink = content.sourceLink;
            comments = new CommentCollection(content.comments);
            references = new ReferenceCollection(content.references);
            attachments = new AttachmentCollection(content.attachments);
        }

        [XmlElement("text")]
        public string Text
        {
            get { return text; }
            set { text = value; }
        }

        [XmlElement("last_update")]
        public DateTime LastUpdate
        {
            get { return lastUpdate; }
            set { lastUpdate = value; }
        }

        [XmlElement("source_title")]
        public string SourceTitle
        {
            get { return sourceTitle; }
            set { sourceTitle = value; }
        }

        [XmlElement("source_link")]
        public string SourceLink
        {
            get { return sourceLink; }
            set { sourceLink = value; }
        }

        [XmlArray("comments")]
        [XmlArrayItem("comment", typeof (Comment))]
        public CommentCollection Comments
        {
            get { return comments; }
        }

        [XmlArray("references")]
        [XmlArrayItem("reference", typeof (Reference))]
        public ReferenceCollection References
        {
            get { return references; }
        }

        [XmlArray("attachments")]
        [XmlArrayItem("attachment", typeof (Attachment))]
        public AttachmentCollection Attachments
        {
            get { return attachments; }
        }
    }
}