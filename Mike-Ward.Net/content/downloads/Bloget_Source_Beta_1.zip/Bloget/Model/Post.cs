// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;

namespace BlueOnionSoftware.Bloget
{
    public class Post
    {
        Guid id = Guid.NewGuid();
        string title;
        string author;
        bool draft;
        bool syndicate = true;
        bool enableComments = true;
        DateTime created = DateTime.UtcNow;
        readonly List<int> tags = new List<int>();

        public Post()
        {
        }

        internal Post(Post post)
        {
            id = post.id;
            title = post.title;
            author = post.author;
            draft = post.draft;
            syndicate = post.syndicate;
            enableComments = post.enableComments;
            created = post.created;
            tags.AddRange(post.tags);
        }

        [XmlElement("id")]
        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        [XmlElement("title")]
        public string Title
        {
            get { return title ?? string.Empty; }
            set { title = value; }
        }

        [XmlElement("author")]
        public string Author
        {
            get { return author ?? string.Empty; }
            set { author = value; }
        }

        [XmlElement("draft")]
        public bool Draft
        {
            get 
            { 
                return draft; 
            }

            set 
            {
                if (draft != value)
                {
                    created = DateTime.UtcNow;
                    draft = value;
                }
            }
        }

        [XmlElement("syndicate")]
        public bool Syndicate
        {
            get { return syndicate; }
            set { syndicate = value; }
        }

        [XmlElement("comments")]
        public bool EnableComments
        {
            get { return enableComments; }
            set { enableComments = value; }
        }

        [XmlElement("created")]
        public DateTime Created
        {
            get { return created; }
            set { created = value; }
        }

        [SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays"), XmlArray("tags")]
        [XmlArrayItem("tag", typeof(int))]
        public int[] Tags
        {
            get
            {
                return tags.ToArray();
            }

            set
            {
                tags.Clear();

                if (value != null)
                {
                    tags.AddRange(value);
                }
            }
        }

        internal bool HasCategory(Category category)
        {
            return tags.Contains(category.Id);
        }

        internal void AddCategory(Category category)
        {
            if (HasCategory(category) == false)
            {
                tags.Add(category.Id);
            }
        }

        internal void RemoveCategory(Category category)
        {
            int index = tags.IndexOf(category.Id);

            if (index != -1)
            {
                tags.Remove(category.Id);
            }
        }

        internal void ClearCategories()
        {
            tags.Clear();
        }

        public override string ToString()
        {
            return Title;
        }
    }

    public class PostCollection : KeyedCollection<Guid, Post>
    {
        public PostCollection()
        {
        }

        internal PostCollection(IEnumerable<Post> postCollection)
        {
            foreach (Post post in postCollection)
            {
                Add(new Post(post));
            }
        }

        protected override Guid GetKeyForItem(Post item)
        {
            return item.Id;
        }

        internal Post Previous(Guid id)
        {
            if (Contains(id))
            {
                int i = IndexOf(this[id]);

                while (--i >= 0)
                {
                    if (this[i].Draft == false)
                    {
                        return this[i];
                    }
                }
            }

            return null;
        }

        internal Post Next(Guid id)
        {
            if (Contains(id))
            {
                int i = IndexOf(this[id]);

                while (++i < Count)
                {
                    if (this[i].Draft == false)
                    {
                        return this[i];
                    }
                }
            }

            return null;
        }

        internal void InsertByDate(Post post)
        {
            // Assumes the blog is already sorted.
            for (int i = 0; i < Count; ++i)
            {
                if (post.Created > this[i].Created)
                {
                    Insert(i, post);
                    return;
                }
            }

            Add(post);
        }
    }
}
