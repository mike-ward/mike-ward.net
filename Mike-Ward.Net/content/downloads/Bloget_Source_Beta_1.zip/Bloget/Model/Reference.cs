// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml.Serialization;
using System.Globalization;

namespace BlueOnionSoftware.Bloget
{
    public class Reference
    {
        Guid id = Guid.NewGuid();
        readonly string title = string.Empty;
        string link = string.Empty;
        DateTime date = DateTime.UtcNow;

        public Reference()
        {
        }

        internal Reference(Reference reference)
        {
            id = reference.id;
            title = reference.title;
            link = reference.link;
            date = reference.date;
        }

        [XmlElement("id")]
        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        [XmlElement("link")]
        public string Link
        {
            get { return link; }
            set { link = value; }
        }

        [XmlElement("date")]
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        public override string ToString()
        {
            return string.Format(CultureInfo.CurrentCulture, "{0} ({1})", 
                date.ToString("u", CultureInfo.CurrentCulture), link);
        }
    }

    public class ReferenceCollection : KeyedCollection<Guid, Reference>
    {
        public ReferenceCollection()
        {
        }

        internal ReferenceCollection(IEnumerable<Reference> referenceCollection)
        {
            foreach (Reference reference in referenceCollection)
            {
                Add(new Reference(reference));
            }
        }

        protected override Guid GetKeyForItem(Reference item)
        {
            return item.Id;
        }

        internal bool ContainsUrl(string url)
        {
            foreach (Reference reference in this)
            {
                if (string.Compare(reference.Link, url, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
