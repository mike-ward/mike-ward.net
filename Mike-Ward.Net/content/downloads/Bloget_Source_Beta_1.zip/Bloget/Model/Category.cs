// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget
{
    public class Category : IEquatable<Category>
    {
        int id;
        string name;
        int count;
        bool deleted;

        public Category()
        {
        }

        internal Category(Category category)
        {
            id = category.id;
            name = category.name;
            count = category.count;
        }

        [XmlElement("id")]
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        [XmlElement("name")]
        public string Name
        {
            get { return name ?? string.Empty; }
            set { name = Normalize(value); }
        }

        [XmlElement("deleted")]
        public bool Deleted
        {
            get { return deleted; }
            set { deleted = value; }
        }

        [XmlIgnore]
        internal int Count
        {
            get { return count; }
            set { count = value; }
        }

        internal static string Normalize(string str)
        {
            Throw.IfNullOrEmpty(str, "str");
            string norm = str.Trim();
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(norm);
        }

        public override string ToString()
        {
            return Name;
        }

        public bool Equals(Category other)
        {
            return (string.Compare(Name, other.Name, StringComparison.CurrentCultureIgnoreCase) == 0);
        }
    }

    public class CategoryCollection : KeyedCollection<int, Category>
    {
        SortedList<string, Category> sortedCategories;

        public CategoryCollection()
        {
        }

        internal CategoryCollection(IEnumerable<Category> categoryCollection)
        {
            Throw.IfNull(categoryCollection, "categoryCollection");

            foreach (Category category in categoryCollection)
            {
                Add(new Category(category));
            }
        }

        protected override int GetKeyForItem(Category item)
        {
            Throw.IfNull(item, "item");
            return item.Id;
        }

        /// <summary>
        /// Public callers should use CreateCategory
        /// </summary>
        /// <param name="item">The object to be added to the end of the <see cref="T:System.Collections.ObjectModel.Collection`1"></see>. The value can be null for reference types.</param>
        protected new void Add(Category item)
        {
            Throw.IfNull(item, "item");
            base.Add(item);
        }

        internal Category CreateCategory(string name)
        {
            Throw.IfNullOrEmpty(name, "name");
            name = Category.Normalize(name);

            foreach (Category category in this)
            {
                if (category.Name == name)
                {
                    category.Deleted = false;
                    return category;
                }
            }

            Category newCategory = new Category();
            newCategory.Name = name;
            newCategory.Id = Count;
            Add(newCategory);
            sortedCategories = null;
            return newCategory;
        }

        internal IEnumerable<Category> Sorted()
        {
            if (sortedCategories == null)
            {
                sortedCategories = new SortedList<string, Category>();

                foreach (Category category in this)
                {
                    sortedCategories.Add(category.Name, category);
                }
            }

            foreach (KeyValuePair<string, Category> kvp in sortedCategories)
            {
                if (kvp.Value.Deleted == false)
                {
                    yield return kvp.Value;
                }
            }
        }

        internal void ClearCounts()
        {
            foreach (Category category in this)
            {
                category.Count = 0;
            }
        }

        internal Category GetCategoryByName(string name)
        {
            Throw.IfNullOrEmpty(name, "name");

            foreach (Category category in this)
            {
                if (category.Name == name)
                {
                    return category;
                }
            }

            return null;
        }

        internal void Merge(Blog blog, Category to, Category from)
        {
            Throw.IfNull(to, "to");
            Throw.IfNull(from, "from");

            foreach (Post post in blog.Posts)
            {
                int[] tags = post.Tags;
                List<int> merge = new List<int>();

                foreach (int tag in tags)
                {
                    int newTag = (tag == from.Id) ? to.Id : tag;

                    if (merge.Contains(newTag) == false)
                    {
                        merge.Add(newTag);
                    }
                }

                post.Tags = merge.ToArray();
            }

            Remove(from);
        }
    }
}