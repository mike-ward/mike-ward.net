// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Web.Caching;
using System.Web.Hosting;
using System.Xml.Serialization;
using BlueOnionSoftware.Bloget.Properties;
using BlueOnionSoftware.Bloget.Providers;

namespace BlueOnionSoftware.Bloget
{
    [XmlRoot(ElementName = "Blog")]
    public class Blog
    {
        // Basic Info
        bool licenseAgreement;
        string title = Resources.BlogetTitle;
        string description = Resources.BlogDescription;
        string link = Resources.BlogLink;

        // Syndication
        string language = Resources.BlogLanguage;
        string copyright = Resources.BlogCopyright;
        string webmaster = Resources.BlogWebmaster;
        string rssChannelImage = string.Empty;

        string rssFooter = Resources.BlogRssFooter;

        int rssEntriesPerFeed = 10;

        // Comment related
        bool allowComments = true;
        int expireComments = 20;
        int maximumCommentsPerPost = 20;

        // Appearance
        int postsPerPage = 10;
        int timeZone;
        int editorWidth = 500;
        int editorHeight = 400;

        // Email related
        bool emailComments;
        bool emailPingbacks;
        string emailTo = string.Empty;

        // Services related
        bool enableMetaWeblogApi;
        bool enableRealSimpleDiscovery;

        // Pingback related
        bool enableAutoPingBack;
        bool enablePingBackService;
        int expirePingBacks = 20;
        int maximumPingsBacksPerPost = 20;

        // Images
        string imageFolder = "~/images/";
        string imageUrl = string.Empty;

        // State Information (not serialized)
        string dataContext; // physical data path
        int allPostsCount; // not including drafts

        PostCollection posts = new PostCollection();
        CategoryCollection categories = new CategoryCollection();

        public Blog()
        {
        }

        internal Blog(Blog blog)
        {
            licenseAgreement = blog.licenseAgreement;
            title = blog.title;
            description = blog.description;
            link = blog.link;
            language = blog.language;
            copyright = blog.copyright;
            webmaster = blog.webmaster;
            RssChannelImage = blog.RssChannelImage;
            RssFooter = blog.RssFooter;
            RssEntriesPerFeed = blog.RssEntriesPerFeed;
            allowComments = blog.allowComments;
            expireComments = blog.expireComments;
            postsPerPage = blog.postsPerPage;
            timeZone = blog.timeZone;
            editorWidth = blog.editorWidth;
            editorHeight = blog.editorHeight;
            maximumCommentsPerPost = blog.maximumCommentsPerPost;
            emailComments = blog.emailComments;
            emailPingbacks = blog.emailPingbacks;
            emailTo = blog.emailTo;
            enableRealSimpleDiscovery = blog.enableRealSimpleDiscovery;
            enableMetaWeblogApi = blog.enableMetaWeblogApi;
            enableAutoPingBack = blog.enableAutoPingBack;
            enablePingBackService = blog.EnablePingBackService;
            expirePingBacks = blog.expirePingBacks;
            maximumPingsBacksPerPost = blog.maximumPingsBacksPerPost;
            imageFolder = blog.imageFolder;
            imageUrl = blog.imageUrl;
            dataContext = blog.dataContext;
            posts = new PostCollection(blog.posts);
            categories = new CategoryCollection(blog.categories);
            allPostsCount = blog.allPostsCount;
            // don't include search in copy
        }

        internal string DataContext
        {
            get { return dataContext; }
            set { dataContext = value; }
        }

        [XmlElement("accepted_license")]
        [Description("Value indicating if license agreement has been accepted")]
        public bool LicenseAgreement
        {
            get { return licenseAgreement; }
            set { licenseAgreement = value; }
        }

        [XmlElement("title")]
        [Description("Title of the blog")]
        public string Title
        {
            get { return title ?? string.Empty; }
            set { title = (value ?? string.Empty).Trim(); }
        }

        [XmlElement("description")]
        [Description("Phrase or sentence describing the blog")]
        [SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")]
        public string Description
        {
            get { return description; }
            set { description = (value ?? string.Empty).Trim(); }
        }

        [XmlElement("link")]
        [Description("The URL to the HTML website")]
        public string Link
        {
            get { return link ?? string.Empty; }
            set { link = (value ?? string.Empty).Trim(); }
        }

        [XmlElement("language")]
        [Description("The language of the blog")]
        public string Language
        {
            get { return language ?? string.Empty; }
            set { language = (value ?? string.Empty).Trim(); }
        }

        [XmlElement("copyright")]
        [Description("Copyright notice")]
        public string Copyright
        {
            get { return copyright ?? string.Empty; }
            set { copyright = (value ?? string.Empty).Trim(); }
        }

        [XmlElement("webmaster")]
        [Description("Email address of the webmaster")]
        [SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")]
        public string Webmaster
        {
            get { return webmaster ?? string.Empty; }
            set { webmaster = (value ?? string.Empty).Trim(); }
        }

        [XmlElement("rss_image")]
        [Description("Channel image for rss feeds")]
        public string RssChannelImage
        {
            get { return rssChannelImage ?? string.Empty; }
            set { rssChannelImage = value ?? string.Empty; }
        }

        [XmlElement("rss_footer")]
        [Description("Footer to append to rss entries")]
        public string RssFooter
        {
            get { return rssFooter ?? string.Empty; }
            set { rssFooter = value ?? string.Empty; }
        }

        [XmlElement("rss_entries_per_feed")]
        [Description("Maximum number of entries to post per feed")]
        public int RssEntriesPerFeed
        {
            get { return rssEntriesPerFeed; }
            set { rssEntriesPerFeed = value; }
        }

        [XmlElement("posts_per_page")]
        [Description("Number of postings to display on a blog page")]
        public int PostsPerPage
        {
            get { return postsPerPage; }
            set { postsPerPage = value; }
        }

        [XmlElement("timezone")]
        [Description("Time zone index of blog")]
        public int TimeZone
        {
            get { return timeZone; }
            set { timeZone = value; }
        }

        [XmlElement("editor_width")]
        [Description("Width in pixels of the blog editor control")]
        public int EditorWidth
        {
            get { return editorWidth; }
            set { editorWidth = value; }
        }

        [XmlElement("editor_height")]
        [Description("Height in pixels of the blog editor control")]
        public int EditorHeight
        {
            get { return editorHeight; }
            set { editorHeight = value; }
        }

        [XmlElement("allow_comments")]
        [Description("Enable comments on blog entries")]
        public bool AllowComments
        {
            get { return allowComments; }
            set { allowComments = value; }
        }

        [XmlElement("max_comments_per_post")]
        [Description("Maximum number of comments to allow per post")]
        public int MaximumCommentsPerPost
        {
            get { return maximumCommentsPerPost; }
            set { maximumCommentsPerPost = value; }
        }

        [XmlElement("expire_comments")]
        [Description("Number of days to allow comments on a posting. Useful for limiting comment spam")]
        public int ExpireComments
        {
            get { return expireComments; }
            set { expireComments = value; }
        }

        [XmlElement("email_comments")]
        [Description("Send email notifications of new comments")]
        public bool EmailComments
        {
            get { return emailComments; }
            set { emailComments = value; }
        }

        [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Pingbacks"), XmlElement("email_pingbacks")]
        [Description("Send email notifications of new pingbacks")]
        public bool EmailPingbacks
        {
            get { return emailPingbacks; }
            set { emailPingbacks = value; }
        }

        [XmlElement("email_to")]
        [Description("Email address to send notifications to")]
        [SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")]
        public string EmailTo
        {
            get { return emailTo ?? string.Empty; }
            set { emailTo = (value ?? string.Empty).Trim(); }
        }

        [XmlElement("image_folder")]
        [Description("Folder name where images are uploaded (actual location on your server, example: '~/Images')")]
        public string ImageFolder
        {
            get { return imageFolder ?? string.Empty; }
            set { imageFolder = (value ?? string.Empty).Trim(); }
        }

        [Description("http address of images folder")]
        [SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings"), XmlElement("image_url")]
        public string ImageUrl
        {
            get { return imageUrl ?? string.Empty; }

            set
            {
                imageUrl = (value ?? string.Empty).Trim();

                if (string.IsNullOrEmpty(imageUrl) == false && imageUrl.EndsWith("/", StringComparison.Ordinal) == false)
                {
                    imageUrl += "/";
                }
            }
        }

        [XmlElement("enable_megaweblogapi")]
        [Description("MetaWeblogApi is a programming interface that allows external programs to get and set the text and attributes of weblog posts")]
        public bool EnableMetaWeblogApi
        {
            get { return enableMetaWeblogApi; }
            set { enableMetaWeblogApi = value; }
        }

        [XmlElement("enable_rsd")]
        [Description("Enable Real Simple Discovery protocol")]
        public bool EnableRealSimpleDiscovery
        {
            get { return enableRealSimpleDiscovery; }
            set { enableRealSimpleDiscovery = value; }
        }

        [XmlElement("enable_auto_pingback")]
        [Description("Automatically send pingbacks to all entry links when published")]
        public bool EnableAutoPingBack
        {
            get { return enableAutoPingBack; }
            set { enableAutoPingBack = value; }
        }

        [XmlElement("enable_pingback_service")]
        [Description("Accept pingbacks from others")]
        public bool EnablePingBackService
        {
            get { return enablePingBackService; }
            set { enablePingBackService = value; }
        }

        [XmlElement("expire_pingbacks")]
        [Description("Number of days to allow pingbacks on a posting. Useful for limiting pingback spam")]
        public int ExpirePingBacks
        {
            get { return expirePingBacks; }
            set { expirePingBacks = value; }
        }

        [XmlElement("maximum_pingbacks_per_post")]
        [Description("Maximum number of pingbacks for a single posting. Useful for limiting pingback spam")]
        public int MaximumPingsBacksPerPost
        {
            get { return maximumPingsBacksPerPost; }
            set { maximumPingsBacksPerPost = value; }
        }

        [XmlArrayItem("category", typeof(Category))]
        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), XmlArray("categories")]
        public CategoryCollection Categories
        {
            get { return categories; }
            set { categories = value; }
        }

        [XmlArrayItem("post", typeof(Post))]
        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly"), XmlArray("posts")]
        public PostCollection Posts
        {
            get { return posts; }
            set { posts = value; }
        }

        [XmlIgnore]
        public int AllPostsCount
        {
            get { return allPostsCount; }
        }

        internal static Blog Load(string path)
        {
            Throw.IfNullOrEmpty(path, "path");
            Blog blog = null;

            try
            {
                blog = BlogProvider.DefaultProvider.Load(path);
            }

            catch (FileNotFoundException)
            {
                return null; 
            }

            if (blog.allPostsCount == 0)
            {
                blog.dataContext = path;
                blog.allPostsCount = 0;

                foreach (Post post in blog.Posts)
                {
                    if (post.Draft == false)
                    {
                        blog.allPostsCount += 1;

                        foreach (int tag in post.Tags)
                        {
                            if (blog.Categories.Contains(tag))
                            {
                                blog.Categories[tag].Count += 1;
                            }
                        }
                    }
                }
            }

            return blog;
        }

        internal void Save()
        {
            BlogProvider.DefaultProvider.Save(this, dataContext);
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        internal Content LoadContent(Guid id)
        {
            Throw.IfEmpty(id, "id");
            string contentPath = null;
            Content content = null;

            try
            {
                content = BlogProvider.DefaultProvider.LoadContent(id, dataContext);
            }

            catch (Exception ex)
            {
                content = new Content();
                content.Text = "Content \"" + contentPath + "\" " + ex.Message;
            }

            return content;
        }

        internal void SaveContent(Guid id, Content content)
        {
            Throw.IfEmpty(id, "id");
            Throw.IfNull(content, "content");

            content.LastUpdate = DateTime.UtcNow;
            BlogProvider.DefaultProvider.SaveContent(id, content, dataContext);
        }

        /// <summary>
        /// Enumerates starting from 'start' to 'count' by category
        /// </summary>
        /// <param name="start">starting index</param>
        /// <param name="length">The length.</param>
        /// <param name="category">null means match any category</param>
        /// <param name="draft">true=return draft maxPosts, false=return published maxPosts</param>
        /// <param name="syndicateOnly">return only maxPosts marked as syndicate</param>
        internal IEnumerable<Post> EnumeratePosts(int start, int length, Category category, bool draft, bool syndicateOnly)
        {
            if (start < 0 || start > length)
            {
                throw new ArgumentOutOfRangeException("start", start, "0 < start < length");
            }

            if (length <= 0)
            {
                throw new ArgumentOutOfRangeException("length", length, "length > 0");
            }

            int count = 0;
            int match = 0;

            foreach (Post post in posts)
            {
                if (syndicateOnly && post.Syndicate == false)
                {
                    continue;
                }

                if (post.Draft == draft && (category == null || post.HasCategory(category)))
                {
                    if (count++ >= start)
                    {
                        yield return post;

                        if (++match >= length)
                        {
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Enumerates maxPosts for the given year/month
        /// </summary>
        /// <param name="start">The start.</param>
        /// <param name="length">The length.</param>
        /// <param name="monthYear">Only the year/month are used for comparison</param>
        internal IEnumerable<Post> EnumeratePostsByMonth(int start, int length, DateTime monthYear)
        {
            if (start < 0 || start > length)
            {
                throw new ArgumentOutOfRangeException("start", start, "0 < start < length");
            }

            if (length <= 0)
            {
                throw new ArgumentOutOfRangeException("length", length, "length > 0");
            }

            int year = monthYear.Year;
            int month = monthYear.Month;

            int count = 0;
            int match = 0;

            foreach (Post post in posts)
            {
                if (post.Draft == false && post.Created.Year == year && post.Created.Month == month)
                {
                    if (count++ >= start)
                    {
                        yield return post;

                        if (++match >= length)
                        {
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Returns an array of month/year dates contained in the blog. Useful for making "Monthly" 
        /// archive listings
        /// </summary>
        internal ArchiveDate[] ArchiveDates()
        {
            const string cacheKey = "bloget_archive_dates";
            ArchiveDate[] dates = (ArchiveDate[])HostingEnvironment.Cache[cacheKey];

            if (dates != null)
            {
                return dates;
            }

            ArchiveDateCollection archiveDates = new ArchiveDateCollection();

            foreach (Post post in posts)
            {
                DateTime monthYear = new DateTime(post.Created.Year, post.Created.Month, 1);

                if (archiveDates.Contains(monthYear) == false)
                {
                    archiveDates.Add(new ArchiveDate(monthYear, 1));
                }

                else
                {
                    archiveDates[monthYear].Count += 1;
                }
            }

            dates = archiveDates.ToArray();
            Array.Sort(dates);
            Array.Reverse(dates);

            using (CacheDependency cd = new CacheDependency(dataContext))
            {
                HostingEnvironment.Cache.Insert(cacheKey, dates, cd);
            }

            return dates;
        }

        internal static bool RenameCategory(Category category, string name)
        {
            Throw.IfNull(category, "category");
            Throw.IfNullOrEmpty(name, "name");
            return true;
        }
    }
}