// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Xml.Serialization;

namespace BlueOnionSoftware.Bloget
{
    public class Comment
    {
        Guid id = Guid.NewGuid();
        string title = string.Empty;
        string text = string.Empty;
        string author = string.Empty;
        string email = string.Empty;
        DateTime date = DateTime.UtcNow;

        public Comment()
        {
        }

        internal Comment(Comment comment)
        {
            id = comment.id;
            title = comment.title;
            date = comment.date;
            author = comment.author;
            email = comment.email;
            text = comment.text;
        }

        [XmlElement("id")]
        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        [XmlElement("title")]
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        [XmlElement("date")]
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        [XmlElement("author")]
        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        [XmlElement("email")]
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        [XmlElement("text")]
        public string Text
        {
            get { return text ?? string.Empty; }
            set { text = value; }
        }

        public override string ToString()
        {
            return string.Format(CultureInfo.CurrentCulture, "Title: {0}{4}Author: {1}{4}Email: {2}{4}{4}{3}",
                                 Title, Author, Email, Text, Environment.NewLine);
        }

        public bool VerifyComment()
        {
            return (Text.Contains("href=") == false);
        }
    }

    public class CommentCollection : KeyedCollection<Guid, Comment>
    {
        public CommentCollection()
        {
        }

        internal CommentCollection(CommentCollection commentCollection)
        {
            foreach (Comment comment in commentCollection)
            {
                Add(new Comment(comment));
            }
        }

        protected override Guid GetKeyForItem(Comment item)
        {
            return item.Id;
        }
    }
}