// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web.Security;

namespace BlueOnionSoftware.Bloget
{
    static class MetaWebLog
    {
        internal const string MethodNewPost = "metaWeblog.newPost";
        internal const string MethodEditPost = "metaWeblog.editPost";
        internal const string MethodGetPost = "metaWeblog.getPost";
        internal const string MethodGetRecentPosts = "metaWeblog.getRecentPosts";
        internal const string MethodGetCategories = "metaWeblog.getCategories";
        internal const string MethodNewMediaObject = "metaWeblog.newMediaObject";

        const string invalidNamePassword = "Invalid username or password";

        [SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        internal static XmlRpcMethodResponse Post(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodNewPost && methodCall.Name != MethodEditPost)
            {
                throw new ArgumentException("MetaWebLog.Post - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false)
            {
                return MetaWebLogNotEnabled();
            }

            bool isNewPost = (methodCall.Name == MethodNewPost);
            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 5)
            {
                response.FaultString = methodCall.Name + " requires 5 parameters";
                return response;
            }

            string postId = parameters[0].Value as string;
            string userName = parameters[1].Value as string;
            string password = DecodePasswordParameter(parameters[2].Value);
            XmlRpcStruct posting = parameters[3].Value as XmlRpcStruct;

            if (posting == null)
            {
                throw new InvalidCastException();
            }

            bool publish = (bool) parameters[4].Value;

            if (IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = invalidNamePassword;
                return response;
            }

            Blog blog = new Blog(bloget.Blog); // copy to protect readers
            Post post = new Post();
            Content content = new Content();

            if (isNewPost == false)
            {
                Guid id = new Guid(postId);

                if (blog.Posts.Contains(id) == false)
                {
                    response.FaultString = "Post ID not found";
                    return response;
                }

                post = blog.Posts[id];
                content = blog.LoadContent(id);
                content = new Content(content); // Clone to protect readers
            }

            post.Draft = !publish;

            foreach (XmlRpcMember member in posting.Members)
            {
                switch (member.Name)
                {
                    case "title":
                        post.Title = bloget.Page.Server.HtmlDecode(member.Value.Value.ToString());
                        break;

                    case "description":
                        content.Text = bloget.Page.Server.HtmlDecode(member.Value.Value.ToString());
                        break;

                    case "categories":
                        XmlRpcArray categories = member.Value.Value as XmlRpcArray;

                        if (categories != null)
                        {
                            foreach (XmlRpcValue categoryValue in categories.Values)
                            {
                                Category category = blog.Categories.GetCategoryByName(categoryValue.Value.ToString());

                                if (category != null)
                                {
                                    post.AddCategory(category);
                                }
                            }
                        }
                        break;

                    case "dateCreated":
                        post.Created = (DateTime) member.Value.Value;
                        break;

                    case "source":
                        ReadSourceStruct(member.Value.Value as XmlRpcStruct, content);
                        break;

                    case "enclosure":
                        Attachment attachment = ReadEnclosureStruct(member.Value.Value as XmlRpcStruct);
                        content.Attachments.Clear();

                        if (string.IsNullOrEmpty(attachment.Url) == false &&
                            string.IsNullOrEmpty(attachment.MimeType) == false &&
                            attachment.Length != 0)
                        {
                            content.Attachments.Add(attachment);
                        }
                        break;

                    default:
                        // ignore everything else
                        break;
                }
            }

            if (string.IsNullOrEmpty(post.Title) || string.IsNullOrEmpty(content.Text))
            {
                response.FaultString = "Posting requires a title and description";
                return response;
            }

            blog.SaveContent(post.Id, content);

            if (isNewPost)
            {
                blog.Posts.InsertByDate(post);
                Log.NewPost(bloget, post.Id, post.Title);
            }

            else
            {
                Log.EditPost(bloget, post.Id, post.Title);
            }

            blog.Save();

            if (blog.EnableAutoPingBack == true && post.Draft == false)
            {
                PingBackClient.PingLinks(bloget, bloget.PermaLink(post), content.Text);
            }

            XmlRpcValue success = new XmlRpcValue(post.Id.ToString());
            response.AddParam(success);
            return response;
        }

        internal static XmlRpcMethodResponse GetPost(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodGetPost)
            {
                throw new ArgumentException("MetaWebLog.GetPost - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false)
            {
                return MetaWebLogNotEnabled();
            }

            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 3)
            {
                response.FaultString = "metaWeblog.getPost requires 3 parameters";
                return response;
            }

            string postId = parameters[0].Value as string;
            string userName = parameters[1].Value as string;
            string password = DecodePasswordParameter(parameters[2].Value);

            if (IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = invalidNamePassword;
                return response;
            }

            Guid id = new Guid(postId);

            if (bloget.Blog.Posts.Contains(id) == false)
            {
                response.FaultString = "Posting ID not found";
                return response;
            }

            Post post = bloget.Blog.Posts[id];
            Content content = bloget.Blog.LoadContent(id);
            response.AddParam(new XmlRpcValue(PostStruct(bloget, post, content)));
            Log.GetPost(bloget, id);
            return response;
        }

        internal static XmlRpcMethodResponse GetRecentPosts(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodGetRecentPosts)
            {
                throw new ArgumentException("MetaWebLog.GetRecentPosts - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false)
            {
                return MetaWebLogNotEnabled();
            }

            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 4)
            {
                response.FaultString = "metaWeblog.GetRecentPosts requires 4 parameters";
                return response;
            }

            string userName = parameters[1].Value as string;
            string password = DecodePasswordParameter(parameters[2].Value);
            int numberOfPosts = (int) parameters[3].Value;

            if (IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = invalidNamePassword;
                return response;
            }

            XmlRpcArray array = new XmlRpcArray();
            numberOfPosts = Math.Min(numberOfPosts, bloget.Blog.Posts.Count);

            for (int i = 0; i < numberOfPosts; ++i)
            {
                Post post = bloget.Blog.Posts[i];
                Content content = bloget.Blog.LoadContent(post.Id);
                array.Add(new XmlRpcValue(PostStruct(bloget, post, content)));
            }

            response.AddParam(new XmlRpcValue(array));
            return response;
        }

        internal static XmlRpcMethodResponse GetCategories(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodGetCategories)
            {
                throw new ArgumentException("MetaWebLog.GetCategories - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false)
            {
                return MetaWebLogNotEnabled();
            }

            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 3)
            {
                response.FaultString = "metaWeblog.getCategories requires 3 parameters";
                return response;
            }

            // blogId not used
            string userName = parameters[1].Value as string;
            string password = DecodePasswordParameter(parameters[2].Value);

            if (IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = invalidNamePassword;
                return response;
            }

            XmlRpcArray array = new XmlRpcArray();

            foreach (Category category in bloget.Blog.Categories)
            {
                XmlRpcStruct categoryStruct = new XmlRpcStruct();
                categoryStruct.Add(new XmlRpcMember("title", category.Name));
                categoryStruct.Add(new XmlRpcMember("categoryid", category.Id.ToString(CultureInfo.CurrentCulture)));
                categoryStruct.Add(new XmlRpcMember("description", category.Name));
                array.Add(new XmlRpcValue(categoryStruct));
            }

            response.AddParam(new XmlRpcValue(array));
            return response;
        }

        internal static XmlRpcMethodResponse NewMediaObject(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodNewMediaObject)
            {
                throw new ArgumentException("MetaWebLog.NewMediaObject - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false || string.IsNullOrEmpty(bloget.Blog.ImageFolder))
            {
                return MetaWebLogNotEnabled();
            }

            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 4)
            {
                response.FaultString = "metaWeblog.newMediaObject requires 4 parameters";
                return response;
            }

            // blogId not used
            string userName = parameters[1].Value as string;
            string password = DecodePasswordParameter(parameters[2].Value);
            XmlRpcStruct media = parameters[3].Value as XmlRpcStruct;

            if (media == null)
            {
                throw new InvalidCastException();
            }

            if (IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = invalidNamePassword;
                return response;
            }

            string name = null;
            string type = null;
            byte[] bits = null;

            foreach (XmlRpcMember member in media.Members)
            {
                switch (member.Name)
                {
                    case "name":
                        name = member.Value.ToString();
                        break;

                    case "type":
                        type = member.Value.ToString();
                        break;

                    case "bits":
                        bits = member.Value.Value as byte[];
                        break;

                    default:
                        // ignore everything else
                        break;
                }
            }

            if (name == null || bits == null) // some editors (like RocketPost) don't send the type
            {
                response.FaultString = "media type must contain a name and bits";
                return response;
            }

            if (name.StartsWith("/", StringComparison.Ordinal))
            {
                name = name.Substring(1);
            }

            string folder = bloget.Page.Request.MapPath(bloget.Blog.ImageFolder);
            string path = Path.Combine(folder, name);
            string directoryName = Path.GetDirectoryName(path);

            if (Directory.Exists(directoryName) == false)
            {
                Directory.CreateDirectory(directoryName);
            }

            File.WriteAllBytes(path, bits);

            string url = bloget.Blog.ImageUrl + name;

            string logMessage =
                string.Format(CultureInfo.InvariantCulture, "{0} (name={1}, type={2}, url={3})", MethodNewMediaObject,
                              name, type, url);
            
            Log.RpcRequest(bloget, logMessage);

            XmlRpcStruct structUrl = new XmlRpcStruct();
            structUrl.Add(new XmlRpcMember("url", url));
            response.AddParam(new XmlRpcValue(structUrl));

            return response;
        }

        internal static XmlRpcMethodResponse MetaWebLogNotEnabled()
        {
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();
            response.FaultString = "MetaWeblog Api not enabled";
            return response;
        }

        internal static bool IsValidUserPassword(string username, string password, Blog blog)
        {
            bool valid = Membership.ValidateUser(username, password);

            if (valid)
            {
                MembershipUser user = Membership.GetUser(username);
                valid = Bloget.IsUserAdministrator(user) || Bloget.IsUserAuthor(user);
            }

            return valid;
        }

        static void ReadSourceStruct(XmlRpcStruct sourceStruct, Content content)
        {
            Throw.IfNull(sourceStruct, "sourceStruct");
            Throw.IfNull(content, "content");

            foreach (XmlRpcMember sourceMember in sourceStruct.Members)
            {
                switch (sourceMember.Name)
                {
                    case "url":
                        content.SourceLink = (string) sourceMember.Value.Value;
                        break;

                    case "name":
                        content.SourceTitle = (string) sourceMember.Value.Value;
                        break;

                    default:
                        break;
                }
            }

            return;
        }

        static Attachment ReadEnclosureStruct(XmlRpcStruct enclosureStruct)
        {
            Throw.IfNull(enclosureStruct, "enclosureStruct");
            Attachment attachment = new Attachment();

            foreach (XmlRpcMember enclosureMember in enclosureStruct.Members)
            {
                switch (enclosureMember.Name)
                {
                    case "url":
                        attachment.Url = enclosureMember.Value.Value as string;
                        break;

                    case "type":
                        attachment.MimeType = enclosureMember.Value.Value as string;
                        break;

                    case "length":
                        attachment.Length = (int) enclosureMember.Value.Value;
                        break;

                    default:
                        break;
                }
            }

            return attachment;
        }

        static XmlRpcStruct PostStruct(Bloget bloget, Post post, Content content)
        {
            XmlRpcStruct postStruct = new XmlRpcStruct();
            postStruct.Add(new XmlRpcMember("title", post.Title));
            postStruct.Add(new XmlRpcMember("description", content.Text));
            postStruct.Add(new XmlRpcMember("dateCreated", post.Created));
            postStruct.Add(new XmlRpcMember("link", bloget.PermaLink(post)));
            postStruct.Add(new XmlRpcMember("postid", post.Id.ToString()));

            if (string.IsNullOrEmpty(content.SourceTitle) == false && string.IsNullOrEmpty(content.SourceLink) == false)
            {
                XmlRpcStruct sourceStruct = new XmlRpcStruct();
                sourceStruct.Add(new XmlRpcMember("url", content.SourceLink));
                sourceStruct.Add(new XmlRpcMember("name", content.SourceTitle));
                postStruct.Add(new XmlRpcMember("source", sourceStruct));
            }

            return postStruct;
        }

        internal static string DecodePasswordParameter(object value)
        {
            // Some systems send passwords as base64 string

            string password = value as string;

            if (password == null)
            {
                byte[] buffer = value as byte[];

                if (buffer != null)
                {
                    password = Encoding.UTF8.GetString(buffer);
                }
            }

            return password;
        }
    }
}