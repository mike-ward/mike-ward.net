// Copyright (C) 2007 Blue Onion Software
// All rights reserved

using System;
using System.Diagnostics.CodeAnalysis;

namespace BlueOnionSoftware.Bloget
{
    static class Blogger
    {
        internal const string MethodGetUsersBlogs = "blogger.getUsersBlogs";
        internal const string MethodDeletePost = "blogger.deletePost";
        internal const string MethodGetUserInfo = "blogger.getUserInfo";

        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static XmlRpcMethodResponse GetUsersBlogs(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodGetUsersBlogs)
            {
                throw new ArgumentException("Blogger.GetUsersBlogs - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false)
            {
                return MetaWebLog.MetaWebLogNotEnabled();
            }

            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 3)
            {
                response.FaultString = "blogger.getUsersBlogs requires 3 parameters";
                return response;
            }

            // appKey not used
            string userName = parameters[1].Value as string;
            string password = MetaWebLog.DecodePasswordParameter(parameters[2].Value);

            if (MetaWebLog.IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = "Invalid username or password";
                return response;
            }

            XmlRpcStruct structure = new XmlRpcStruct();
            structure.Add(new XmlRpcMember("url", bloget.Blog.Link));
            structure.Add(new XmlRpcMember("blogid", "1"));
            structure.Add(new XmlRpcMember("blogName", bloget.Blog.Title));

            XmlRpcArray array = new XmlRpcArray();
            array.Add(new XmlRpcValue(structure));

            response.AddParam(new XmlRpcValue(array));
            return response;
        }

        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static XmlRpcMethodResponse DeletePost(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodDeletePost)
            {
                throw new ArgumentException("Blogger.DeletePost - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false)
            {
                return MetaWebLog.MetaWebLogNotEnabled();
            }

            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 5)
            {
                response.FaultString = "blogger.deletePost requires 5 parameters";
                return response;
            }

            // appKey not used
            string postId = parameters[1].Value as string;
            string userName = parameters[2].Value as string;
            string password = MetaWebLog.DecodePasswordParameter(parameters[3].Value);
            // publish flag not used

            if (MetaWebLog.IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = "Invalid username or password";
                return response;
            }

            Guid id = new Guid(postId);

            if (bloget.Blog.Posts.Contains(id))
            {
                Blog blog = new Blog(bloget.Blog); // copy to protect readers
                blog.Posts.Remove(id);
                blog.Save();
                Log.RemovePost(bloget, id);
            }

            response.AddParam(new XmlRpcValue(true));
            return response;
        }

        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters",
            MessageId = "System.ArgumentException.#ctor(System.String)")]
        internal static XmlRpcMethodResponse GetUserInfo(XmlRpcMethodCall methodCall, Bloget bloget)
        {
            Throw.IfNull(methodCall, "methodCall");
            Throw.IfNull(bloget, "bloget");

            if (methodCall.Name != MethodGetUserInfo)
            {
                throw new ArgumentException("Blogger.GetUserInfo - method call is " + methodCall.Name);
            }

            if (bloget.Blog.EnableMetaWeblogApi == false)
            {
                return MetaWebLog.MetaWebLogNotEnabled();
            }

            XmlRpcValue[] parameters = methodCall.Parameters;
            XmlRpcMethodResponse response = new XmlRpcMethodResponse();

            if (parameters.Length != 3)
            {
                response.FaultString = "blogger.getUserInfo requires 3 parameters";
                return response;
            }

            // appKey not used
            string userName = parameters[1].Value as string;
            string password = MetaWebLog.DecodePasswordParameter(parameters[2].Value);

            if (MetaWebLog.IsValidUserPassword(userName, password, bloget.Blog) == false)
            {
                response.FaultString = "Invalid username or password";
                return response;
            }

            XmlRpcStruct info = new XmlRpcStruct();
            info.Add(new XmlRpcMember("firstName", string.Empty));
            info.Add(new XmlRpcMember("lastName", string.Empty));
            info.Add(new XmlRpcMember("email", bloget.Blog.Webmaster));
            info.Add(new XmlRpcMember("url", bloget.Blog.Link));

            response.AddParam(new XmlRpcValue(info));
            return response;
        }
    }
}